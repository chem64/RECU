package cmarsoft.recu;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class xchart extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "cmarsoft.recu.xchart");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", cmarsoft.recu.xchart.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _vvvvvvvvvvvvvvvvvvvvvvvvvvv3 = null;
public String _vvvvvvvvvvvvvvvvvvvvvvvvvvv4 = "";
public Object _vvvvvvvvvvvvvvvvvvvvvvvvvvv5 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _vvvvvvvvvvvvvvvvvvvvvvvvvvv6 = null;
public anywheresoftware.b4a.objects.B4XCanvas _vvvvvvvvvvvvvvvvvvvvvvvvvvv7 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _vvvvvvvvvvvvvvvvvvvvvvvvvvv0 = null;
public anywheresoftware.b4a.objects.B4XCanvas _vvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _vvvvvvvvvvvvvvvvvvvvvvvvvvvv2 = null;
public anywheresoftware.b4a.objects.B4XCanvas _vvvvvvvvvvvvvvvvvvvvvvvvvvvv3 = null;
public anywheresoftware.b4a.objects.B4XCanvas.B4XPath _vvvvvvvvvvvvvvvvvvvvvvvvvvvv4 = null;
public cmarsoft.recu.xchart._scaledata[] _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = null;
public int _vvvvvvvvvvvvvvvvvvvvvvvvvvvv6 = 0;
public int _vvvvvvvvvvvvvvvvvvvvvvvvvvvv7 = 0;
public anywheresoftware.b4a.objects.collections.List _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0 = null;
public anywheresoftware.b4a.objects.collections.List _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = null;
public cmarsoft.recu.xchart._graphdata _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2 = null;
public cmarsoft.recu.xchart._textdata _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3 = null;
public cmarsoft.recu.xchart._legenddata _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4 = null;
public cmarsoft.recu.xchart._valuesdata _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = null;
public double[] _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6 = null;
public cmarsoft.recu.xchart._numberformats _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7 = null;
public boolean _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv0 = false;
public boolean _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = false;
public cmarsoft.recu.main _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2 = null;
public cmarsoft.recu.starter _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3 = null;
public cmarsoft.recu.utility _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4 = null;
public cmarsoft.recu.chart _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = null;
public cmarsoft.recu.setup _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv6 = null;
public static class _graphdata{
public boolean IsInitialized;
public String Title;
public String Subtitle;
public String XAxisName;
public String YAxisName;
public int Left;
public int Right;
public int Top;
public int Bottom;
public int Width;
public int Height;
public anywheresoftware.b4a.objects.B4XCanvas.B4XRect Rect;
public int YInterval;
public int XInterval;
public int XOffset;
public int BarWidth;
public String ChartType;
public int BarSubWidth;
public boolean IncludeBarMeanLine;
public boolean IncludeValues;
public int ChartBackgroundColor;
public int GridFrameColor;
public int GridColor;
public String XScaleTextOrientation;
public int PieGapDegrees;
public boolean PieAddPerentage;
public boolean GradientColors;
public int GradientColorsAlpha;
public double Rotation;
public boolean DrawOuterFrame;
public boolean IncludeMinLine;
public boolean IncludeMaxLine;
public int MinLineColor;
public int MaxLineColor;
public boolean IncludeMeanLine;
public int MeanLineColor;
public String BarValueOrientation;
public void Initialize() {
IsInitialized = true;
Title = "";
Subtitle = "";
XAxisName = "";
YAxisName = "";
Left = 0;
Right = 0;
Top = 0;
Bottom = 0;
Width = 0;
Height = 0;
Rect = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
YInterval = 0;
XInterval = 0;
XOffset = 0;
BarWidth = 0;
ChartType = "";
BarSubWidth = 0;
IncludeBarMeanLine = false;
IncludeValues = false;
ChartBackgroundColor = 0;
GridFrameColor = 0;
GridColor = 0;
XScaleTextOrientation = "";
PieGapDegrees = 0;
PieAddPerentage = false;
GradientColors = false;
GradientColorsAlpha = 0;
Rotation = 0;
DrawOuterFrame = false;
IncludeMinLine = false;
IncludeMaxLine = false;
MinLineColor = 0;
MaxLineColor = 0;
IncludeMeanLine = false;
MeanLineColor = 0;
BarValueOrientation = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _pointdata{
public boolean IsInitialized;
public String X;
public double[] XArray;
public double[] YArray;
public boolean ShowTick;
public void Initialize() {
IsInitialized = true;
X = "";
XArray = new double[0];
;
YArray = new double[0];
;
ShowTick = false;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _itemdata{
public boolean IsInitialized;
public String Name;
public int Color;
public float Value;
public int StrokeWidth;
public boolean DrawLine;
public String PointType;
public boolean Filled;
public int PointColor;
public anywheresoftware.b4a.objects.collections.List YXArray;
public void Initialize() {
IsInitialized = true;
Name = "";
Color = 0;
Value = 0f;
StrokeWidth = 0;
DrawLine = false;
PointType = "";
Filled = false;
PointColor = 0;
YXArray = new anywheresoftware.b4a.objects.collections.List();
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _scaledata{
public boolean IsInitialized;
public double Scale;
public double MinVal;
public double MaxVal;
public double MinManu;
public double MaxManu;
public double IntervalManu;
public double MinAuto;
public double MaxAuto;
public double IntervalAuto;
public double Interval;
public int NbIntervals;
public boolean Automatic;
public double Exp;
public boolean YZeroAxis;
public String ScaleValues;
public void Initialize() {
IsInitialized = true;
Scale = 0;
MinVal = 0;
MaxVal = 0;
MinManu = 0;
MaxManu = 0;
IntervalManu = 0;
MinAuto = 0;
MaxAuto = 0;
IntervalAuto = 0;
Interval = 0;
NbIntervals = 0;
Automatic = false;
Exp = 0;
YZeroAxis = false;
ScaleValues = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _textdata{
public boolean IsInitialized;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont TitleFont;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont SubtitleFont;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont AxisFont;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont ScaleFont;
public boolean AutomaticTextSizes;
public float TitleTextSize;
public float SubtitleTextSize;
public int TitleTextColor;
public int SubtitleTextColor;
public float AxisTextSize;
public float ScaleTextSize;
public int ScaleTextColor;
public int TitleTextHeight;
public int SubtitleTextHeight;
public int AxisTextHeight;
public int ScaleTextHeight;
public void Initialize() {
IsInitialized = true;
TitleFont = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
SubtitleFont = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
AxisFont = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
ScaleFont = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
AutomaticTextSizes = false;
TitleTextSize = 0f;
SubtitleTextSize = 0f;
TitleTextColor = 0;
SubtitleTextColor = 0;
AxisTextSize = 0f;
ScaleTextSize = 0f;
ScaleTextColor = 0;
TitleTextHeight = 0;
SubtitleTextHeight = 0;
AxisTextHeight = 0;
ScaleTextHeight = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _legenddata{
public boolean IsInitialized;
public String IncludeLegend;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont TextFont;
public float TextSize;
public int TextHeight;
public int Height;
public int LineNumber;
public anywheresoftware.b4a.objects.collections.List LineNumbers;
public anywheresoftware.b4a.objects.collections.List LineChange;
public void Initialize() {
IsInitialized = true;
IncludeLegend = "";
TextFont = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
TextSize = 0f;
TextHeight = 0;
Height = 0;
LineNumber = 0;
LineNumbers = new anywheresoftware.b4a.objects.collections.List();
LineChange = new anywheresoftware.b4a.objects.collections.List();
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _valuesdata{
public boolean IsInitialized;
public boolean Show;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont TextFont;
public float TextSize;
public int TextColor;
public int TextHeight;
public int Left;
public int Top;
public int Width;
public int Height;
public int MidPont;
public anywheresoftware.b4a.objects.B4XCanvas.B4XRect rectRight;
public anywheresoftware.b4a.objects.B4XCanvas.B4XRect rectCursor;
public int MaxDigits;
public void Initialize() {
IsInitialized = true;
Show = false;
TextFont = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
TextSize = 0f;
TextColor = 0;
TextHeight = 0;
Left = 0;
Top = 0;
Width = 0;
Height = 0;
MidPont = 0;
rectRight = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
rectCursor = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
MaxDigits = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _numberformats{
public boolean IsInitialized;
public int MinimumIntegers;
public int MaximumFractions;
public int MinimumFractions;
public boolean GroupingUsed;
public void Initialize() {
IsInitialized = true;
MinimumIntegers = 0;
MaximumFractions = 0;
MinimumFractions = 0;
GroupingUsed = false;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _vvvv4(String _name,int _barcolor) throws Exception{
cmarsoft.recu.xchart._itemdata _id = null;
 //BA.debugLineNum = 504;BA.debugLine="Public Sub AddBar(Name As String, BarColor As Int)";
 //BA.debugLineNum = 505;BA.debugLine="If Items.IsInitialized = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.IsInitialized()==__c.False) { 
 //BA.debugLineNum = 506;BA.debugLine="Items.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Initialize();
 };
 //BA.debugLineNum = 509;BA.debugLine="Private ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 510;BA.debugLine="ID.Initialize";
_id.Initialize();
 //BA.debugLineNum = 511;BA.debugLine="ID.Name = Name";
_id.Name = _name;
 //BA.debugLineNum = 512;BA.debugLine="ID.Color = BarColor";
_id.Color = _barcolor;
 //BA.debugLineNum = 513;BA.debugLine="Items.Add(ID)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Add((Object)(_id));
 //BA.debugLineNum = 514;BA.debugLine="End Sub";
return "";
}
public String  _vvvv5(String _x,double[] _yarray) throws Exception{
cmarsoft.recu.xchart._pointdata _pd = null;
 //BA.debugLineNum = 518;BA.debugLine="Public Sub AddBarMultiplePoint (X As String, YArra";
 //BA.debugLineNum = 519;BA.debugLine="If Points.IsInitialized = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.IsInitialized()==__c.False) { 
 //BA.debugLineNum = 520;BA.debugLine="Points.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Initialize();
 };
 //BA.debugLineNum = 522;BA.debugLine="Dim PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 523;BA.debugLine="PD.Initialize";
_pd.Initialize();
 //BA.debugLineNum = 524;BA.debugLine="PD.X = X";
_pd.X = _x;
 //BA.debugLineNum = 525;BA.debugLine="PD.YArray = YArray";
_pd.YArray = _yarray;
 //BA.debugLineNum = 526;BA.debugLine="PD.ShowTick = True";
_pd.ShowTick = __c.True;
 //BA.debugLineNum = 527;BA.debugLine="Points.Add(PD)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Add((Object)(_pd));
 //BA.debugLineNum = 528;BA.debugLine="End Sub";
return "";
}
public String  _vvvv6(String _x,double _y) throws Exception{
cmarsoft.recu.xchart._pointdata _pd = null;
double[] _yarray = null;
 //BA.debugLineNum = 532;BA.debugLine="Public Sub AddBarPointData (X As String, Y As Doub";
 //BA.debugLineNum = 533;BA.debugLine="If Points.IsInitialized = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.IsInitialized()==__c.False) { 
 //BA.debugLineNum = 534;BA.debugLine="Points.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Initialize();
 };
 //BA.debugLineNum = 536;BA.debugLine="Dim PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 537;BA.debugLine="PD.Initialize";
_pd.Initialize();
 //BA.debugLineNum = 538;BA.debugLine="PD.X = X";
_pd.X = _x;
 //BA.debugLineNum = 539;BA.debugLine="Private YArray(1) As Double";
_yarray = new double[(int) (1)];
;
 //BA.debugLineNum = 540;BA.debugLine="YArray(0) = Y";
_yarray[(int) (0)] = _y;
 //BA.debugLineNum = 541;BA.debugLine="PD.YArray = YArray";
_pd.YArray = _yarray;
 //BA.debugLineNum = 542;BA.debugLine="PD.ShowTick = True";
_pd.ShowTick = __c.True;
 //BA.debugLineNum = 543;BA.debugLine="Points.Add(PD)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Add((Object)(_pd));
 //BA.debugLineNum = 544;BA.debugLine="End Sub";
return "";
}
public String  _vvvv7(String _name,int _linecolor) throws Exception{
cmarsoft.recu.xchart._itemdata _id = null;
 //BA.debugLineNum = 548;BA.debugLine="Public Sub AddLine(Name As String, LineColor As In";
 //BA.debugLineNum = 549;BA.debugLine="If Items.IsInitialized = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.IsInitialized()==__c.False) { 
 //BA.debugLineNum = 550;BA.debugLine="Items.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Initialize();
 };
 //BA.debugLineNum = 552;BA.debugLine="If LineColor = 0 Then LineColor = xui.Color_RGB(R";
if (_linecolor==0) { 
_linecolor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_RGB(__c.Rnd((int) (0),(int) (255)),__c.Rnd((int) (0),(int) (255)),__c.Rnd((int) (0),(int) (255)));};
 //BA.debugLineNum = 554;BA.debugLine="Dim ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 555;BA.debugLine="ID.Initialize";
_id.Initialize();
 //BA.debugLineNum = 556;BA.debugLine="ID.Name = Name";
_id.Name = _name;
 //BA.debugLineNum = 557;BA.debugLine="ID.Color = LineColor";
_id.Color = _linecolor;
 //BA.debugLineNum = 558;BA.debugLine="ID.StrokeWidth = 2dip";
_id.StrokeWidth = __c.DipToCurrent((int) (2));
 //BA.debugLineNum = 559;BA.debugLine="ID.PointType = \"NONE\"";
_id.PointType = "NONE";
 //BA.debugLineNum = 560;BA.debugLine="ID.Filled = False";
_id.Filled = __c.False;
 //BA.debugLineNum = 561;BA.debugLine="Items.Add(ID)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Add((Object)(_id));
 //BA.debugLineNum = 562;BA.debugLine="End Sub";
return "";
}
public String  _vvvv0(String _name,int _linecolor,int _strokewidth,String _pointtype,boolean _filled,int _pointcolor) throws Exception{
cmarsoft.recu.xchart._itemdata _id = null;
 //BA.debugLineNum = 568;BA.debugLine="Public Sub AddLine2(Name As String, LineColor As I";
 //BA.debugLineNum = 569;BA.debugLine="If Items.IsInitialized = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.IsInitialized()==__c.False) { 
 //BA.debugLineNum = 570;BA.debugLine="Items.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Initialize();
 };
 //BA.debugLineNum = 572;BA.debugLine="If LineColor = 0 Then LineColor = xui.Color_RGB(R";
if (_linecolor==0) { 
_linecolor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_RGB(__c.Rnd((int) (0),(int) (255)),__c.Rnd((int) (0),(int) (255)),__c.Rnd((int) (0),(int) (255)));};
 //BA.debugLineNum = 574;BA.debugLine="Dim ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 575;BA.debugLine="ID.Initialize";
_id.Initialize();
 //BA.debugLineNum = 576;BA.debugLine="ID.Name = Name";
_id.Name = _name;
 //BA.debugLineNum = 577;BA.debugLine="ID.Color = LineColor";
_id.Color = _linecolor;
 //BA.debugLineNum = 578;BA.debugLine="ID.StrokeWidth = StrokeWidth";
_id.StrokeWidth = _strokewidth;
 //BA.debugLineNum = 579;BA.debugLine="ID.PointType = PointType";
_id.PointType = _pointtype;
 //BA.debugLineNum = 580;BA.debugLine="ID.Filled = Filled";
_id.Filled = _filled;
 //BA.debugLineNum = 581;BA.debugLine="ID.PointColor = PointColor";
_id.PointColor = _pointcolor;
 //BA.debugLineNum = 582;BA.debugLine="Items.Add(ID)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Add((Object)(_id));
 //BA.debugLineNum = 583;BA.debugLine="End Sub";
return "";
}
public String  _vvvvv1(String _x,double[] _yarray,boolean _showtick) throws Exception{
cmarsoft.recu.xchart._pointdata _pd = null;
 //BA.debugLineNum = 588;BA.debugLine="Public Sub AddLineMultiplePoints(X As String, YArr";
 //BA.debugLineNum = 589;BA.debugLine="If Points.IsInitialized = False Then Points.Initi";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.IsInitialized()==__c.False) { 
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Initialize();};
 //BA.debugLineNum = 590;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 591;BA.debugLine="PD.Initialize";
_pd.Initialize();
 //BA.debugLineNum = 592;BA.debugLine="PD.X = X";
_pd.X = _x;
 //BA.debugLineNum = 593;BA.debugLine="PD.YArray = YArray";
_pd.YArray = _yarray;
 //BA.debugLineNum = 594;BA.debugLine="PD.ShowTick = ShowTick";
_pd.ShowTick = _showtick;
 //BA.debugLineNum = 595;BA.debugLine="Points.Add(PD)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Add((Object)(_pd));
 //BA.debugLineNum = 596;BA.debugLine="If xpnlValues.Visible = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.getVisible()==__c.True) { 
 //BA.debugLineNum = 597;BA.debugLine="xpnlValues.Visible = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.setVisible(__c.False);
 //BA.debugLineNum = 598;BA.debugLine="xcvsCursor.ClearRect(Values.rectCursor)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ClearRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.rectCursor);
 //BA.debugLineNum = 599;BA.debugLine="xcvsCursor.Invalidate";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.Invalidate();
 };
 //BA.debugLineNum = 601;BA.debugLine="End Sub";
return "";
}
public String  _vvvvv2(String _x,double _y,boolean _showtick) throws Exception{
cmarsoft.recu.xchart._pointdata _pd = null;
double[] _yarray = null;
 //BA.debugLineNum = 606;BA.debugLine="Public Sub AddLinePointData (X As String, Y As Dou";
 //BA.debugLineNum = 607;BA.debugLine="If Points.IsInitialized = False Then Points.Initi";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.IsInitialized()==__c.False) { 
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Initialize();};
 //BA.debugLineNum = 608;BA.debugLine="Dim PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 609;BA.debugLine="PD.Initialize";
_pd.Initialize();
 //BA.debugLineNum = 610;BA.debugLine="PD.X = X";
_pd.X = _x;
 //BA.debugLineNum = 611;BA.debugLine="Private YArray(1) As Double";
_yarray = new double[(int) (1)];
;
 //BA.debugLineNum = 612;BA.debugLine="YArray(0) = Y";
_yarray[(int) (0)] = _y;
 //BA.debugLineNum = 613;BA.debugLine="PD.YArray = YArray";
_pd.YArray = _yarray;
 //BA.debugLineNum = 614;BA.debugLine="PD.ShowTick = ShowTick";
_pd.ShowTick = _showtick;
 //BA.debugLineNum = 615;BA.debugLine="Points.Add(PD)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Add((Object)(_pd));
 //BA.debugLineNum = 616;BA.debugLine="If xpnlValues.Visible = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.getVisible()==__c.True) { 
 //BA.debugLineNum = 617;BA.debugLine="xpnlValues.Visible = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.setVisible(__c.False);
 //BA.debugLineNum = 618;BA.debugLine="xcvsCursor.ClearRect(Values.rectCursor)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ClearRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.rectCursor);
 //BA.debugLineNum = 619;BA.debugLine="xcvsCursor.Invalidate";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.Invalidate();
 };
 //BA.debugLineNum = 621;BA.debugLine="End Sub";
return "";
}
public String  _vvvvv3(String _name,float _value,int _color) throws Exception{
cmarsoft.recu.xchart._itemdata _id = null;
 //BA.debugLineNum = 626;BA.debugLine="Public Sub AddPie(Name As String, Value As Float,";
 //BA.debugLineNum = 627;BA.debugLine="If Items.IsInitialized = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.IsInitialized()==__c.False) { 
 //BA.debugLineNum = 628;BA.debugLine="Items.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Initialize();
 };
 //BA.debugLineNum = 630;BA.debugLine="If Color = 0 Then Color = xui.Color_RGB(Rnd(0, 25";
if (_color==0) { 
_color = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_RGB(__c.Rnd((int) (0),(int) (255)),__c.Rnd((int) (0),(int) (255)),__c.Rnd((int) (0),(int) (255)));};
 //BA.debugLineNum = 631;BA.debugLine="Dim ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 632;BA.debugLine="ID.Initialize";
_id.Initialize();
 //BA.debugLineNum = 633;BA.debugLine="ID.Name = Name";
_id.Name = _name;
 //BA.debugLineNum = 634;BA.debugLine="ID.Value = Value";
_id.Value = _value;
 //BA.debugLineNum = 635;BA.debugLine="ID.Color = Color";
_id.Color = _color;
 //BA.debugLineNum = 636;BA.debugLine="Items.Add(ID)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Add((Object)(_id));
 //BA.debugLineNum = 637;BA.debugLine="End Sub";
return "";
}
public String  _vvvvv4(String _name,int _linecolor,int _strokewidth) throws Exception{
cmarsoft.recu.xchart._itemdata _id = null;
 //BA.debugLineNum = 641;BA.debugLine="Public Sub AddYXLine(Name As String, LineColor As";
 //BA.debugLineNum = 642;BA.debugLine="If Items.IsInitialized = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.IsInitialized()==__c.False) { 
 //BA.debugLineNum = 643;BA.debugLine="Items.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Initialize();
 };
 //BA.debugLineNum = 645;BA.debugLine="If LineColor = 0 Then LineColor = xui.Color_RGB(R";
if (_linecolor==0) { 
_linecolor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_RGB(__c.Rnd((int) (0),(int) (255)),__c.Rnd((int) (0),(int) (255)),__c.Rnd((int) (0),(int) (255)));};
 //BA.debugLineNum = 647;BA.debugLine="Dim ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 648;BA.debugLine="ID.Initialize";
_id.Initialize();
 //BA.debugLineNum = 649;BA.debugLine="ID.Name = Name";
_id.Name = _name;
 //BA.debugLineNum = 650;BA.debugLine="ID.Color = LineColor";
_id.Color = _linecolor;
 //BA.debugLineNum = 651;BA.debugLine="ID.StrokeWidth = StrokeWidth";
_id.StrokeWidth = _strokewidth;
 //BA.debugLineNum = 652;BA.debugLine="ID.DrawLine = True";
_id.DrawLine = __c.True;
 //BA.debugLineNum = 653;BA.debugLine="ID.PointType = \"NONE\"";
_id.PointType = "NONE";
 //BA.debugLineNum = 654;BA.debugLine="ID.Filled = False";
_id.Filled = __c.False;
 //BA.debugLineNum = 655;BA.debugLine="ID.YXArray.Initialize";
_id.YXArray.Initialize();
 //BA.debugLineNum = 656;BA.debugLine="Items.Add(ID)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Add((Object)(_id));
 //BA.debugLineNum = 657;BA.debugLine="End Sub";
return "";
}
public String  _vvvvv5(String _name,int _linecolor,int _strokewidth,boolean _drawline,String _pointtype,boolean _filled,int _pointcolor) throws Exception{
cmarsoft.recu.xchart._itemdata _id = null;
 //BA.debugLineNum = 664;BA.debugLine="Public Sub AddYXLine2(Name As String, LineColor As";
 //BA.debugLineNum = 665;BA.debugLine="If Items.IsInitialized = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.IsInitialized()==__c.False) { 
 //BA.debugLineNum = 666;BA.debugLine="Items.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Initialize();
 };
 //BA.debugLineNum = 668;BA.debugLine="If LineColor = 0 Then LineColor = xui.Color_RGB(R";
if (_linecolor==0) { 
_linecolor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_RGB(__c.Rnd((int) (0),(int) (255)),__c.Rnd((int) (0),(int) (255)),__c.Rnd((int) (0),(int) (255)));};
 //BA.debugLineNum = 670;BA.debugLine="Dim ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 671;BA.debugLine="ID.Initialize";
_id.Initialize();
 //BA.debugLineNum = 672;BA.debugLine="ID.Name = Name";
_id.Name = _name;
 //BA.debugLineNum = 673;BA.debugLine="ID.Color = LineColor";
_id.Color = _linecolor;
 //BA.debugLineNum = 674;BA.debugLine="ID.StrokeWidth = StrokeWidth";
_id.StrokeWidth = _strokewidth;
 //BA.debugLineNum = 675;BA.debugLine="ID.DrawLine = DrawLine";
_id.DrawLine = _drawline;
 //BA.debugLineNum = 676;BA.debugLine="ID.PointType = PointType";
_id.PointType = _pointtype;
 //BA.debugLineNum = 677;BA.debugLine="ID.Filled = Filled";
_id.Filled = _filled;
 //BA.debugLineNum = 678;BA.debugLine="ID.PointColor = PointColor";
_id.PointColor = _pointcolor;
 //BA.debugLineNum = 679;BA.debugLine="ID.YXArray.Initialize";
_id.YXArray.Initialize();
 //BA.debugLineNum = 680;BA.debugLine="If DrawLine = False Then";
if (_drawline==__c.False) { 
 //BA.debugLineNum = 681;BA.debugLine="ID.Color = ID.PointColor";
_id.Color = _id.PointColor;
 };
 //BA.debugLineNum = 683;BA.debugLine="Items.Add(ID)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Add((Object)(_id));
 //BA.debugLineNum = 684;BA.debugLine="End Sub";
return "";
}
public String  _vvvvv6(int _lineindex,double _x,double _y) throws Exception{
cmarsoft.recu.xchart._itemdata _id = null;
double[] _yx = null;
 //BA.debugLineNum = 687;BA.debugLine="Public Sub AddYXPoint(LineIndex As Int, X As Doubl";
 //BA.debugLineNum = 688;BA.debugLine="If LineIndex < 0 Or LineIndex > Items.Size Then";
if (_lineindex<0 || _lineindex>_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()) { 
 //BA.debugLineNum = 689;BA.debugLine="Log(\"Index out of range\")";
__c.LogImpl("92686978","Index out of range",0);
 //BA.debugLineNum = 690;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 693;BA.debugLine="Private ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 694;BA.debugLine="Private YX(2) As Double";
_yx = new double[(int) (2)];
;
 //BA.debugLineNum = 695;BA.debugLine="YX(0) = X";
_yx[(int) (0)] = _x;
 //BA.debugLineNum = 696;BA.debugLine="YX(1) = Y";
_yx[(int) (1)] = _y;
 //BA.debugLineNum = 697;BA.debugLine="ID = Items.Get(LineIndex)";
_id = (cmarsoft.recu.xchart._itemdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Get(_lineindex));
 //BA.debugLineNum = 698;BA.debugLine="If ID.YXArray.IsInitialized = False Then";
if (_id.YXArray.IsInitialized()==__c.False) { 
 //BA.debugLineNum = 699;BA.debugLine="ID.YXArray.Initialize";
_id.YXArray.Initialize();
 };
 //BA.debugLineNum = 701;BA.debugLine="ID.YXArray.Add(YX)";
_id.YXArray.Add((Object)(_yx));
 //BA.debugLineNum = 702;BA.debugLine="End Sub";
return "";
}
public void  _base_resize(double _width,double _height) throws Exception{
ResumableSub_Base_Resize rsub = new ResumableSub_Base_Resize(this,_width,_height);
rsub.resume(ba, null);
}
public static class ResumableSub_Base_Resize extends BA.ResumableSub {
public ResumableSub_Base_Resize(cmarsoft.recu.xchart parent,double _width,double _height) {
this.parent = parent;
this._width = _width;
this._height = _height;
}
cmarsoft.recu.xchart parent;
double _width;
double _height;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 299;BA.debugLine="xcvsGraph.Resize(Width, Height)";
parent._vvvvvvvvvvvvvvvvvvvvvvvvvvv7.Resize((float) (_width),(float) (_height));
 //BA.debugLineNum = 300;BA.debugLine="xpnlCursor.Width = Width";
parent._vvvvvvvvvvvvvvvvvvvvvvvvvvvv2.setWidth((int) (_width));
 //BA.debugLineNum = 301;BA.debugLine="xpnlCursor.Height = Height";
parent._vvvvvvvvvvvvvvvvvvvvvvvvvvvv2.setHeight((int) (_height));
 //BA.debugLineNum = 302;BA.debugLine="xcvsCursor.Resize(Width, Height)";
parent._vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.Resize((float) (_width),(float) (_height));
 //BA.debugLineNum = 303;BA.debugLine="Sleep(0)";
parent.__c.Sleep(ba,this,(int) (0));
this.state = 5;
return;
case 5:
//C
this.state = 1;
;
 //BA.debugLineNum = 304;BA.debugLine="If Points.Size > 0 Or Graph.ChartType = \"PIE\" Or";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()>0 || (parent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("PIE") || (parent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("YX_CHART")) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 305;BA.debugLine="DrawChart";
parent._vvvvvv5();
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 307;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _vvvvv7(int _axis) throws Exception{
double _scalelog = 0;
double _scalemant = 0;
double _scaledelta = 0;
double _valdiff = 0;
double _scalemin = 0;
double _scalemax = 0;
double _valmax = 0;
int _nbmin = 0;
int _nbusedintervals = 0;
int _nbusedintervalstop = 0;
int _nbusedintervalsbottom = 0;
int _nbintervalstomove = 0;
double[] _valminmax = null;
boolean _scaleok = false;
 //BA.debugLineNum = 875;BA.debugLine="Private Sub CalcScaleAuto(Axis As Int)";
 //BA.debugLineNum = 876;BA.debugLine="Private ScaleLog, ScaleMant, ScaleDelta, ValDiff,";
_scalelog = 0;
_scalemant = 0;
_scaledelta = 0;
_valdiff = 0;
_scalemin = 0;
_scalemax = 0;
_valmax = 0;
 //BA.debugLineNum = 878;BA.debugLine="Private nbMin, NbUsedIntervals, NbUsedIntervalsTo";
_nbmin = 0;
_nbusedintervals = 0;
_nbusedintervalstop = 0;
_nbusedintervalsbottom = 0;
_nbintervalstomove = 0;
 //BA.debugLineNum = 879;BA.debugLine="Private ValMinMax(3) As Double";
_valminmax = new double[(int) (3)];
;
 //BA.debugLineNum = 881;BA.debugLine="Select Graph.ChartType";
switch (BA.switchObjectToInt(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType,"LINE","YX_CHART")) {
case 0: 
case 1: {
 //BA.debugLineNum = 883;BA.debugLine="ValMinMax = GetLinePointsMinMaxMeanValues(Axis)";
_valminmax = _vvvvvvvvvv4(_axis);
 //BA.debugLineNum = 884;BA.debugLine="If Scale(Axis).YZeroAxis = True And ValMinMax(0";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].YZeroAxis==__c.True && _valminmax[(int) (0)]>=0 && _valminmax[(int) (1)]>0) { 
 //BA.debugLineNum = 885;BA.debugLine="ValMinMax(0) = 0";
_valminmax[(int) (0)] = 0;
 };
 //BA.debugLineNum = 887;BA.debugLine="If Scale(Axis).YZeroAxis = True And ValMinMax(0";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].YZeroAxis==__c.True && _valminmax[(int) (0)]<0 && _valminmax[(int) (1)]<=0) { 
 //BA.debugLineNum = 888;BA.debugLine="ValMinMax(1) = 0";
_valminmax[(int) (1)] = 0;
 };
 break; }
default: {
 //BA.debugLineNum = 891;BA.debugLine="ValMinMax = GetBarPointsMinMaxValues";
_valminmax = _vvvvvvvv2();
 break; }
}
;
 //BA.debugLineNum = 895;BA.debugLine="If ValMinMax(0) = ValMinMax(1) Then";
if (_valminmax[(int) (0)]==_valminmax[(int) (1)]) { 
 //BA.debugLineNum = 896;BA.debugLine="If ValMinMax(0) = 0 Then";
if (_valminmax[(int) (0)]==0) { 
 //BA.debugLineNum = 897;BA.debugLine="Scale(Axis).MinAuto = 0";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto = 0;
 //BA.debugLineNum = 898;BA.debugLine="Scale(Axis).MaxAuto = 1";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxAuto = 1;
 //BA.debugLineNum = 899;BA.debugLine="Scale(Axis).IntervalAuto = 1 / Scale(sY).NbInte";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto = 1/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].NbIntervals;
 //BA.debugLineNum = 900;BA.debugLine="Scale(Axis).MinVal = Scale(Axis).MinAuto";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinVal = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto;
 //BA.debugLineNum = 901;BA.debugLine="Scale(Axis).MaxVal = Scale(Axis).MaxAuto";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxVal = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxAuto;
 //BA.debugLineNum = 902;BA.debugLine="Scale(Axis).Interval = Scale(Axis).IntervalAuto";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Interval = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto;
 //BA.debugLineNum = 903;BA.debugLine="Return";
if (true) return "";
 }else {
 //BA.debugLineNum = 905;BA.debugLine="Scale(Axis).IntervalAuto = 1";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto = 1;
 //BA.debugLineNum = 906;BA.debugLine="Scale(Axis).MinAuto = Floor(ValMinMax(0)) - Sca";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto = __c.Floor(_valminmax[(int) (0)])-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals/(double)2;
 //BA.debugLineNum = 907;BA.debugLine="Scale(Axis).MaxAuto = Scale(Axis).MinAuto + Sca";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxAuto = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals;
 //BA.debugLineNum = 908;BA.debugLine="Scale(Axis).MinVal = Scale(Axis).MinAuto";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinVal = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto;
 //BA.debugLineNum = 909;BA.debugLine="Scale(Axis).MaxVal = Scale(Axis).MaxAuto";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxVal = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxAuto;
 //BA.debugLineNum = 910;BA.debugLine="Scale(Axis).Interval = Scale(Axis).IntervalAuto";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Interval = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto;
 //BA.debugLineNum = 911;BA.debugLine="If Axis = 0 Then";
if (_axis==0) { 
 //BA.debugLineNum = 912;BA.debugLine="Scale(Axis).Scale = Graph.Height / (Scale(Axis";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Scale = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height/(double)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinVal);
 }else {
 //BA.debugLineNum = 914;BA.debugLine="Scale(Axis).Scale = Graph.Width / (Scale(Axis)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Scale = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width/(double)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinVal);
 };
 };
 };
 //BA.debugLineNum = 919;BA.debugLine="Private ScaleOK As Boolean = False";
_scaleok = __c.False;
 //BA.debugLineNum = 920;BA.debugLine="ValMax = ValMinMax(1)";
_valmax = _valminmax[(int) (1)];
 //BA.debugLineNum = 921;BA.debugLine="Do Until ScaleOK = True";
while (!(_scaleok==__c.True)) {
 //BA.debugLineNum = 922;BA.debugLine="ValDiff = ValMax - ValMinMax(0)";
_valdiff = _valmax-_valminmax[(int) (0)];
 //BA.debugLineNum = 923;BA.debugLine="ScaleDelta = ValDiff / Scale(Axis).NbIntervals";
_scaledelta = _valdiff/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals;
 //BA.debugLineNum = 925;BA.debugLine="ScaleLog = Logarithm(ScaleDelta, 10)";
_scalelog = __c.Logarithm(_scaledelta,10);
 //BA.debugLineNum = 926;BA.debugLine="Scale(Axis).Exp = Floor(ScaleLog)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Exp = __c.Floor(_scalelog);
 //BA.debugLineNum = 927;BA.debugLine="If ValDiff >= 1 Then";
if (_valdiff>=1) { 
 //BA.debugLineNum = 928;BA.debugLine="ScaleMant = ScaleLog - Scale(Axis).Exp";
_scalemant = _scalelog-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Exp;
 }else {
 //BA.debugLineNum = 930;BA.debugLine="ScaleMant = Abs(Scale(Axis).Exp) + ScaleLog";
_scalemant = __c.Abs(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Exp)+_scalelog;
 };
 //BA.debugLineNum = 933;BA.debugLine="ScaleMant = GetScaleMant(ScaleMant)";
_scalemant = _vvvvvvvvvvv1(_scalemant);
 //BA.debugLineNum = 935;BA.debugLine="Scale(Axis).IntervalAuto = Power(10, Scale(Axis)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto = __c.Power(10,_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Exp+_scalemant);
 //BA.debugLineNum = 937;BA.debugLine="ScaleMin = Floor(ValMinMax(0) / Scale(Axis).Inte";
_scalemin = __c.Floor(_valminmax[(int) (0)]/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto+0.00000000000001)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto;
 //BA.debugLineNum = 938;BA.debugLine="ScaleMax = ScaleMin + Scale(Axis).IntervalAuto *";
_scalemax = _scalemin+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals;
 //BA.debugLineNum = 941;BA.debugLine="If ScaleMax < ValMinMax(1) Then";
if (_scalemax<_valminmax[(int) (1)]) { 
 //BA.debugLineNum = 942;BA.debugLine="ValMax = ValMax + Scale(Axis).IntervalAuto";
_valmax = _valmax+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto;
 }else {
 //BA.debugLineNum = 944;BA.debugLine="ScaleOK = True";
_scaleok = __c.True;
 };
 }
;
 //BA.debugLineNum = 949;BA.debugLine="If ValMinMax(0) < 0 And ValMinMax(1) > 0 Then";
if (_valminmax[(int) (0)]<0 && _valminmax[(int) (1)]>0) { 
 //BA.debugLineNum = 950;BA.debugLine="NbUsedIntervalsTop = Ceil(ValMinMax(1) / Scale(A";
_nbusedintervalstop = (int) (__c.Ceil(_valminmax[(int) (1)]/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto-0.00000000000001));
 //BA.debugLineNum = 951;BA.debugLine="NbUsedIntervalsBottom = Ceil(Abs(ValMinMax(0)) /";
_nbusedintervalsbottom = (int) (__c.Ceil(__c.Abs(_valminmax[(int) (0)])/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto-0.00000000000001));
 //BA.debugLineNum = 953;BA.debugLine="If NbUsedIntervalsTop + NbUsedIntervalsBottom >";
if (_nbusedintervalstop+_nbusedintervalsbottom>_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals) { 
 //BA.debugLineNum = 955;BA.debugLine="ScaleMant = GetScaleMant(ScaleMant)";
_scalemant = _vvvvvvvvvvv1(_scalemant);
 //BA.debugLineNum = 957;BA.debugLine="Scale(Axis).IntervalAuto = Power(10, Scale(Axis";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto = __c.Power(10,_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Exp+_scalemant);
 };
 };
 //BA.debugLineNum = 962;BA.debugLine="nbMin = Floor(ValMinMax(0) / Scale(Axis).Interval";
_nbmin = (int) (__c.Floor(_valminmax[(int) (0)]/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto));
 //BA.debugLineNum = 963;BA.debugLine="If Abs(ValMinMax(0)) <= 0.0000000000001 Then";
if (__c.Abs(_valminmax[(int) (0)])<=0.0000000000001) { 
 //BA.debugLineNum = 964;BA.debugLine="Scale(Axis).MinAuto = 0";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto = 0;
 }else if(_valminmax[(int) (0)]>=0) { 
 //BA.debugLineNum = 966;BA.debugLine="Scale(Axis).MinAuto = nbMin * Scale(Axis).Interv";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto = _nbmin*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto;
 }else if(_valminmax[(int) (0)]<0 && _valminmax[(int) (1)]>0) { 
 //BA.debugLineNum = 968;BA.debugLine="Scale(Axis).MinAuto = Floor(ValMinMax(0) / Scale";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto = __c.Floor(_valminmax[(int) (0)]/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto+0.00000000000001)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto;
 }else {
 //BA.debugLineNum = 970;BA.debugLine="Scale(Axis).MinAuto = Floor(ValMinMax(0) / Scale";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto = __c.Floor(_valminmax[(int) (0)]/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto+0.00000000000001)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto;
 };
 //BA.debugLineNum = 977;BA.debugLine="If Abs(Scale(Axis).MinAuto) >= 0 And Scale(Axis).";
if (__c.Abs(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto)>=0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].YZeroAxis==__c.False || _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto<=0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxAuto>=0) { 
 //BA.debugLineNum = 978;BA.debugLine="If ValMinMax(0) < 0 And ValMinMax(1) > 0 Then";
if (_valminmax[(int) (0)]<0 && _valminmax[(int) (1)]>0) { 
 //BA.debugLineNum = 979;BA.debugLine="NbUsedIntervalsTop = Ceil(ValMinMax(1) / Scale(";
_nbusedintervalstop = (int) (__c.Ceil(_valminmax[(int) (1)]/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto-0.00000000000001));
 //BA.debugLineNum = 980;BA.debugLine="NbUsedIntervalsBottom = Ceil(Abs(ValMinMax(0))";
_nbusedintervalsbottom = (int) (__c.Ceil(__c.Abs(_valminmax[(int) (0)])/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto-0.00000000000001));
 //BA.debugLineNum = 981;BA.debugLine="NbUsedIntervals = NbUsedIntervalsTop + NbUsedIn";
_nbusedintervals = (int) (_nbusedintervalstop+_nbusedintervalsbottom);
 //BA.debugLineNum = 982;BA.debugLine="If NbUsedIntervalsTop - NbUsedIntervalsBottom =";
if (_nbusedintervalstop-_nbusedintervalsbottom==1) { 
 //BA.debugLineNum = 983;BA.debugLine="NbIntervalsToMove = Scale(Axis).NbIntervals /";
_nbintervalstomove = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals/(double)2-_nbusedintervalsbottom);
 }else {
 //BA.debugLineNum = 985;BA.debugLine="NbIntervalsToMove = (Scale(Axis).NbIntervals -";
_nbintervalstomove = (int) ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals-_nbusedintervals)/(double)2);
 };
 }else {
 //BA.debugLineNum = 988;BA.debugLine="NbUsedIntervals = Ceil(ValDiff / Scale(Axis).In";
_nbusedintervals = (int) (__c.Ceil(_valdiff/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto-0.00000000000001));
 //BA.debugLineNum = 989;BA.debugLine="NbIntervalsToMove = (Scale(Axis).NbIntervals -";
_nbintervalstomove = (int) ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals-_nbusedintervals)/(double)2);
 };
 //BA.debugLineNum = 991;BA.debugLine="Scale(Axis).MinAuto = Scale(Axis).MinAuto - Scal";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto*_nbintervalstomove;
 };
 //BA.debugLineNum = 994;BA.debugLine="If Graph.ChartType = \"BAR\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("BAR")) { 
 //BA.debugLineNum = 996;BA.debugLine="If 	ValMinMax(0) = 0 And ValMinMax(1) > 0 And Sc";
if (_valminmax[(int) (0)]==0 && _valminmax[(int) (1)]>0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto<0) { 
 //BA.debugLineNum = 997;BA.debugLine="Scale(Axis).MinAuto = 0";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto = 0;
 };
 //BA.debugLineNum = 1001;BA.debugLine="If 	ValMinMax(0) < 0 And ValMinMax(1) = 0 And Sc";
if (_valminmax[(int) (0)]<0 && _valminmax[(int) (1)]==0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals>0) { 
 //BA.debugLineNum = 1002;BA.debugLine="Scale(Axis).MinAuto = - Scale(Axis).IntervalAut";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto = -_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals;
 };
 };
 //BA.debugLineNum = 1007;BA.debugLine="Scale(Axis).MaxAuto = Scale(Axis).MinAuto + Scale";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxAuto = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].NbIntervals;
 //BA.debugLineNum = 1009;BA.debugLine="Scale(Axis).MinVal = Scale(Axis).MinAuto";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinVal = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinAuto;
 //BA.debugLineNum = 1010;BA.debugLine="Scale(Axis).MaxVal = Scale(Axis).MaxAuto";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxVal = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxAuto;
 //BA.debugLineNum = 1011;BA.debugLine="Scale(Axis).Interval = Scale(Axis).IntervalAuto";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Interval = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].IntervalAuto;
 //BA.debugLineNum = 1012;BA.debugLine="If Axis = 0 Then";
if (_axis==0) { 
 //BA.debugLineNum = 1013;BA.debugLine="Scale(Axis).Scale = Graph.Height / (Scale(Axis).";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Scale = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height/(double)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinVal);
 }else {
 //BA.debugLineNum = 1015;BA.debugLine="Scale(Axis).Scale = Graph.Width / (Scale(Axis).M";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].Scale = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width/(double)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_axis].MinVal);
 };
 //BA.debugLineNum = 1017;BA.debugLine="End Sub";
return "";
}
public String  _vvvvv0(int _index) throws Exception{
double[] _valminmax = null;
 //BA.debugLineNum = 846;BA.debugLine="Private Sub CalcScaleManu(Index As Int)";
 //BA.debugLineNum = 847;BA.debugLine="Private ValMinMax(3) As Double";
_valminmax = new double[(int) (3)];
;
 //BA.debugLineNum = 849;BA.debugLine="Select Graph.ChartType";
switch (BA.switchObjectToInt(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType,"LINE","YX_CHART")) {
case 0: 
case 1: {
 //BA.debugLineNum = 851;BA.debugLine="ValMinMax = GetLinePointsMinMaxMeanValues(sY)";
_valminmax = _vvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6);
 //BA.debugLineNum = 852;BA.debugLine="If Scale(sY).YZeroAxis = True And ValMinMax(0)";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].YZeroAxis==__c.True && _valminmax[(int) (0)]>=0 && _valminmax[(int) (1)]>0) { 
 //BA.debugLineNum = 853;BA.debugLine="ValMinMax(0) = 0";
_valminmax[(int) (0)] = 0;
 };
 //BA.debugLineNum = 855;BA.debugLine="If Scale(sY).YZeroAxis = True And ValMinMax(0)";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].YZeroAxis==__c.True && _valminmax[(int) (0)]<0 && _valminmax[(int) (1)]<=0) { 
 //BA.debugLineNum = 856;BA.debugLine="ValMinMax(1) = 0";
_valminmax[(int) (1)] = 0;
 };
 break; }
default: {
 //BA.debugLineNum = 859;BA.debugLine="ValMinMax = GetBarPointsMinMaxValues";
_valminmax = _vvvvvvvv2();
 break; }
}
;
 //BA.debugLineNum = 862;BA.debugLine="Scale(Index).MaxVal = Scale(Index).MaxManu";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MaxVal = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MaxManu;
 //BA.debugLineNum = 863;BA.debugLine="Scale(Index).MinVal = Scale(Index).MinManu";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MinVal = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MinManu;
 //BA.debugLineNum = 864;BA.debugLine="Scale(Index).IntervalManu = (Scale(Index).MaxVal";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].IntervalManu = (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MinVal)/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].NbIntervals;
 //BA.debugLineNum = 865;BA.debugLine="Scale(Index).Interval = Scale(Index).IntervalManu";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].Interval = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].IntervalManu;
 //BA.debugLineNum = 866;BA.debugLine="Scale(Index).Exp = Floor(Logarithm((Scale(Index).";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].Exp = __c.Floor(__c.Logarithm((_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MinVal)/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].NbIntervals,10));
 //BA.debugLineNum = 867;BA.debugLine="If Index = sY Then";
if (_index==_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6) { 
 //BA.debugLineNum = 868;BA.debugLine="Scale(Index).Scale = Graph.Height / (Scale(Index";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].Scale = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height/(double)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MinVal);
 }else {
 //BA.debugLineNum = 870;BA.debugLine="Scale(Index).Scale = Graph.Width / (Scale(Index)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].Scale = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width/(double)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_index].MinVal);
 };
 //BA.debugLineNum = 872;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 171;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 172;BA.debugLine="Type GraphData (Title As String, Subtitle As Stri";
;
 //BA.debugLineNum = 173;BA.debugLine="Type PointData (X As String, XArray() As Double,";
;
 //BA.debugLineNum = 174;BA.debugLine="Type ItemData (Name As String, Color As Int, Valu";
;
 //BA.debugLineNum = 175;BA.debugLine="Type ScaleData (Scale As Double, MinVal As Double";
;
 //BA.debugLineNum = 176;BA.debugLine="Type TextData (TitleFont As B4XFont, SubtitleFont";
;
 //BA.debugLineNum = 177;BA.debugLine="Type LegendData (IncludeLegend As String, TextFon";
;
 //BA.debugLineNum = 178;BA.debugLine="Type ValuesData (Show As Boolean, TextFont As B4X";
;
 //BA.debugLineNum = 179;BA.debugLine="Type NumberFormats(MinimumIntegers As Int, Maximu";
;
 //BA.debugLineNum = 181;BA.debugLine="Private xui As XUI";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv3 = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 183;BA.debugLine="Private mEventName As String 'ignore";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv4 = "";
 //BA.debugLineNum = 184;BA.debugLine="Private mCallBack As Object 'ignore";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv5 = new Object();
 //BA.debugLineNum = 186;BA.debugLine="Public xBase As B4XView";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv6 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 188;BA.debugLine="Private xcvsGraph As B4XCanvas";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7 = new anywheresoftware.b4a.objects.B4XCanvas();
 //BA.debugLineNum = 189;BA.debugLine="Private xpnlValues As B4XView";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 190;BA.debugLine="Private xcvsValues As B4XCanvas";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = new anywheresoftware.b4a.objects.B4XCanvas();
 //BA.debugLineNum = 191;BA.debugLine="Private xpnlCursor As B4XView";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 192;BA.debugLine="Private xcvsCursor As B4XCanvas";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3 = new anywheresoftware.b4a.objects.B4XCanvas();
 //BA.debugLineNum = 193;BA.debugLine="Private pthGrid As B4XPath";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv4 = new anywheresoftware.b4a.objects.B4XCanvas.B4XPath();
 //BA.debugLineNum = 195;BA.debugLine="Private Scale(2) As ScaleData";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = new cmarsoft.recu.xchart._scaledata[(int) (2)];
{
int d0 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5.length;
for (int i0 = 0;i0 < d0;i0++) {
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[i0] = new cmarsoft.recu.xchart._scaledata();
}
}
;
 //BA.debugLineNum = 196;BA.debugLine="Private sY = 0, sX = 1 As Int";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6 = (int) (0);
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7 = (int) (1);
 //BA.debugLineNum = 197;BA.debugLine="Private Items As List";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 198;BA.debugLine="Private Points As List";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 199;BA.debugLine="Private Graph As GraphData";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2 = new cmarsoft.recu.xchart._graphdata();
 //BA.debugLineNum = 200;BA.debugLine="Private Texts As TextData";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3 = new cmarsoft.recu.xchart._textdata();
 //BA.debugLineNum = 201;BA.debugLine="Private Legend As LegendData";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4 = new cmarsoft.recu.xchart._legenddata();
 //BA.debugLineNum = 202;BA.debugLine="Private Values As ValuesData";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = new cmarsoft.recu.xchart._valuesdata();
 //BA.debugLineNum = 203;BA.debugLine="Private MinMaxMeanValues(3) As Double";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6 = new double[(int) (3)];
;
 //BA.debugLineNum = 204;BA.debugLine="Private BMVNF As NumberFormats		' Bar Meann Value";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7 = new cmarsoft.recu.xchart._numberformats();
 //BA.debugLineNum = 205;BA.debugLine="Private BMVNFUsed As Boolean			' True if a custom";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv0 = false;
 //BA.debugLineNum = 206;BA.debugLine="Private BarWidth0 = False As Boolean";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = __c.False;
 //BA.debugLineNum = 207;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvv1() throws Exception{
 //BA.debugLineNum = 2075;BA.debugLine="Public Sub ClearData";
 //BA.debugLineNum = 2076;BA.debugLine="Items.Clear";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Clear();
 //BA.debugLineNum = 2077;BA.debugLine="Points.Clear";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Clear();
 //BA.debugLineNum = 2078;BA.debugLine="End Sub";
return "";
}
public String  _designercreateview(Object _base,anywheresoftware.b4a.objects.LabelWrapper _lbl,anywheresoftware.b4a.objects.collections.Map _props) throws Exception{
 //BA.debugLineNum = 214;BA.debugLine="Public Sub DesignerCreateView (Base As Object, Lbl";
 //BA.debugLineNum = 215;BA.debugLine="xBase = Base";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.setObject((java.lang.Object)(_base));
 //BA.debugLineNum = 217;BA.debugLine="xcvsGraph.Initialize(xBase)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.Initialize(_vvvvvvvvvvvvvvvvvvvvvvvvvvv6);
 //BA.debugLineNum = 219;BA.debugLine="Scale(sY).Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Initialize();
 //BA.debugLineNum = 220;BA.debugLine="Scale(sX).Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Initialize();
 //BA.debugLineNum = 221;BA.debugLine="Items.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Initialize();
 //BA.debugLineNum = 222;BA.debugLine="Points.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Initialize();
 //BA.debugLineNum = 223;BA.debugLine="Graph.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Initialize();
 //BA.debugLineNum = 224;BA.debugLine="Texts.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.Initialize();
 //BA.debugLineNum = 225;BA.debugLine="Legend.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.Initialize();
 //BA.debugLineNum = 226;BA.debugLine="Values.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Initialize();
 //BA.debugLineNum = 227;BA.debugLine="BMVNF.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.Initialize();
 //BA.debugLineNum = 229;BA.debugLine="Legend.LineNumbers.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumbers.Initialize();
 //BA.debugLineNum = 230;BA.debugLine="Legend.LineChange.Initialize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineChange.Initialize();
 //BA.debugLineNum = 232;BA.debugLine="Graph.Title = Props.Get(\"Title\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Title = BA.ObjectToString(_props.Get((Object)("Title")));
 //BA.debugLineNum = 233;BA.debugLine="Graph.Subtitle = Props.Get(\"Subtitle\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Subtitle = BA.ObjectToString(_props.Get((Object)("Subtitle")));
 //BA.debugLineNum = 234;BA.debugLine="Graph.XAxisName = Props.Get(\"XAxisName\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XAxisName = BA.ObjectToString(_props.Get((Object)("XAxisName")));
 //BA.debugLineNum = 235;BA.debugLine="Graph.YAxisName = Props.Get(\"YAxisName\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.YAxisName = BA.ObjectToString(_props.Get((Object)("YAxisName")));
 //BA.debugLineNum = 236;BA.debugLine="Scale(sY).MaxManu = Props.Get(\"YMaxValue\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxManu = (double)(BA.ObjectToNumber(_props.Get((Object)("YMaxValue"))));
 //BA.debugLineNum = 237;BA.debugLine="Scale(sY).MinManu = Props.Get(\"YMinValue\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinManu = (double)(BA.ObjectToNumber(_props.Get((Object)("YMinValue"))));
 //BA.debugLineNum = 238;BA.debugLine="Scale(sY).NbIntervals = Props.Get(\"NbYIntervals\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].NbIntervals = (int)(BA.ObjectToNumber(_props.Get((Object)("NbYIntervals"))));
 //BA.debugLineNum = 239;BA.debugLine="Scale(sY).YZeroAxis = Props.Get(\"YZeroAxis\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].YZeroAxis = BA.ObjectToBoolean(_props.Get((Object)("YZeroAxis")));
 //BA.debugLineNum = 241;BA.debugLine="Scale(sX).MaxManu = Props.Get(\"XMaxValue\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MaxManu = (double)(BA.ObjectToNumber(_props.Get((Object)("XMaxValue"))));
 //BA.debugLineNum = 242;BA.debugLine="Scale(sX).MinManu = Props.Get(\"XMinValue\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinManu = (double)(BA.ObjectToNumber(_props.Get((Object)("XMinValue"))));
 //BA.debugLineNum = 243;BA.debugLine="Scale(sX).NbIntervals = Props.Get(\"NbXIntervals\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].NbIntervals = (int)(BA.ObjectToNumber(_props.Get((Object)("NbXIntervals"))));
 //BA.debugLineNum = 245;BA.debugLine="Graph.ChartType = Props.Get(\"ChartType\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType = BA.ObjectToString(_props.Get((Object)("ChartType")));
 //BA.debugLineNum = 246;BA.debugLine="Graph.ChartBackgroundColor = xui.PaintOrColorToCo";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.PaintOrColorToColor(_props.Get((Object)("ChartBackgroundColor")));
 //BA.debugLineNum = 247;BA.debugLine="If Graph.ChartBackgroundColor = 16777215 Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor==16777215) { 
 //BA.debugLineNum = 248;BA.debugLine="Graph.ChartBackgroundColor = xui.Color_Transpare";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Transparent;
 };
 //BA.debugLineNum = 250;BA.debugLine="Graph.GridFrameColor = xui.PaintOrColorToColor(Pr";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.PaintOrColorToColor(_props.Get((Object)("GridFrameColor")));
 //BA.debugLineNum = 251;BA.debugLine="Graph.GridColor = xui.PaintOrColorToColor(Props.G";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.PaintOrColorToColor(_props.Get((Object)("GridColor")));
 //BA.debugLineNum = 252;BA.debugLine="Graph.GradientColors = Props.Get(\"GradientColors\"";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColors = BA.ObjectToBoolean(_props.Get((Object)("GradientColors")));
 //BA.debugLineNum = 253;BA.debugLine="Graph.GradientColorsAlpha = Props.Get(\"GradientCo";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColorsAlpha = (int)(BA.ObjectToNumber(_props.Get((Object)("GradientColorsAlpha"))));
 //BA.debugLineNum = 254;BA.debugLine="Texts.TitleTextColor = xui.PaintOrColorToColor(Pr";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.PaintOrColorToColor(_props.Get((Object)("TitleTextColor")));
 //BA.debugLineNum = 255;BA.debugLine="Texts.SubtitleTextColor = xui.PaintOrColorToColor";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.PaintOrColorToColor(_props.Get((Object)("SubtitleTextColor")));
 //BA.debugLineNum = 256;BA.debugLine="Texts.ScaleTextColor = xui.PaintOrColorToColor(Pr";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.PaintOrColorToColor(_props.Get((Object)("ScaleTextColor")));
 //BA.debugLineNum = 257;BA.debugLine="Texts.TitleTextSize = Props.Get(\"TitleTextSize\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextSize = (float)(BA.ObjectToNumber(_props.Get((Object)("TitleTextSize"))));
 //BA.debugLineNum = 258;BA.debugLine="Texts.SubtitleTextSize = Props.Get(\"SubtitleTextS";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextSize = (float)(BA.ObjectToNumber(_props.Get((Object)("SubtitleTextSize"))));
 //BA.debugLineNum = 259;BA.debugLine="Texts.AxisTextSize = Props.Get(\"AxisTextSize\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextSize = (float)(BA.ObjectToNumber(_props.Get((Object)("AxisTextSize"))));
 //BA.debugLineNum = 260;BA.debugLine="Texts.ScaleTextSize = Props.Get(\"ScaleTextSize\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextSize = (float)(BA.ObjectToNumber(_props.Get((Object)("ScaleTextSize"))));
 //BA.debugLineNum = 261;BA.debugLine="Legend.TextSize = Props.Get(\"LegendTextSize\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextSize = (float)(BA.ObjectToNumber(_props.Get((Object)("LegendTextSize"))));
 //BA.debugLineNum = 262;BA.debugLine="Texts.AutomaticTextSizes = Props.Get(\"AutomaticTe";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AutomaticTextSizes = BA.ObjectToBoolean(_props.Get((Object)("AutomaticTextSizes")));
 //BA.debugLineNum = 263;BA.debugLine="Scale(sY).Automatic = Props.Get(\"AutomaticScale\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Automatic = BA.ObjectToBoolean(_props.Get((Object)("AutomaticScale")));
 //BA.debugLineNum = 264;BA.debugLine="Scale(sY).ScaleValues = Props.Get(\"ScaleValues\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].ScaleValues = BA.ObjectToString(_props.Get((Object)("ScaleValues")));
 //BA.debugLineNum = 265;BA.debugLine="Graph.XScaleTextOrientation = Props.Get(\"XScaleTe";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XScaleTextOrientation = BA.ObjectToString(_props.Get((Object)("XScaleTextOrientation")));
 //BA.debugLineNum = 266;BA.debugLine="Legend.IncludeLegend = Props.Get(\"IncludeLegend\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend = BA.ObjectToString(_props.Get((Object)("IncludeLegend")));
 //BA.debugLineNum = 267;BA.debugLine="Graph.IncludeValues = Props.Get(\"IncludeValues\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeValues = BA.ObjectToBoolean(_props.Get((Object)("IncludeValues")));
 //BA.debugLineNum = 268;BA.debugLine="Graph.BarValueOrientation = Props.Get(\"BarValueOr";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarValueOrientation = BA.ObjectToString(_props.Get((Object)("BarValueOrientation")));
 //BA.debugLineNum = 269;BA.debugLine="Graph.PieAddPerentage = Props.Get(\"PieAddPerentag";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.PieAddPerentage = BA.ObjectToBoolean(_props.Get((Object)("PieAddPerentage")));
 //BA.debugLineNum = 270;BA.debugLine="Graph.PieGapDegrees = Props.Get(\"PieGapDegrees\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.PieGapDegrees = (int)(BA.ObjectToNumber(_props.Get((Object)("PieGapDegrees"))));
 //BA.debugLineNum = 271;BA.debugLine="Values.Show = Props.Get(\"ValuesShow\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Show = BA.ObjectToBoolean(_props.Get((Object)("ValuesShow")));
 //BA.debugLineNum = 272;BA.debugLine="Values.TextSize = Props.Get(\"ValuesTextSize\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextSize = (float)(BA.ObjectToNumber(_props.Get((Object)("ValuesTextSize"))));
 //BA.debugLineNum = 273;BA.debugLine="Values.TextColor = xui.PaintOrColorToColor(Props.";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.PaintOrColorToColor(_props.Get((Object)("ValuesTextColor")));
 //BA.debugLineNum = 274;BA.debugLine="Graph.IncludeBarMeanLine = Props.Get(\"IncludeBarM";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeBarMeanLine = BA.ObjectToBoolean(_props.Get((Object)("IncludeBarMeanLine")));
 //BA.debugLineNum = 275;BA.debugLine="Graph.IncludeMinLine = Props.Get(\"IncludeMinLine\"";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMinLine = BA.ObjectToBoolean(_props.Get((Object)("IncludeMinLine")));
 //BA.debugLineNum = 276;BA.debugLine="Graph.IncludeMaxLine = Props.Get(\"IncludeMaxLine\"";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMaxLine = BA.ObjectToBoolean(_props.Get((Object)("IncludeMaxLine")));
 //BA.debugLineNum = 277;BA.debugLine="Graph.IncludeMeanLine = Props.Get(\"IncludeMeanLin";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMeanLine = BA.ObjectToBoolean(_props.Get((Object)("IncludeMeanLine")));
 //BA.debugLineNum = 278;BA.debugLine="Graph.MinLineColor = xui.PaintOrColorToColor(Prop";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MinLineColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.PaintOrColorToColor(_props.Get((Object)("MinLineColor")));
 //BA.debugLineNum = 279;BA.debugLine="Graph.MaxLineColor = xui.PaintOrColorToColor(Prop";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MaxLineColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.PaintOrColorToColor(_props.Get((Object)("MaxLineColor")));
 //BA.debugLineNum = 280;BA.debugLine="Graph.MeanLineColor = xui.PaintOrColorToColor(Pro";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MeanLineColor = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.PaintOrColorToColor(_props.Get((Object)("MeanLineColor")));
 //BA.debugLineNum = 281;BA.debugLine="Graph.DrawOuterFrame = Props.Get(\"DrawOuterFrame\"";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.DrawOuterFrame = BA.ObjectToBoolean(_props.Get((Object)("DrawOuterFrame")));
 //BA.debugLineNum = 282;BA.debugLine="xpnlCursor = xui.CreatePanel(\"xpnlCursor\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv2 = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreatePanel(ba,"xpnlCursor");
 //BA.debugLineNum = 283;BA.debugLine="xBase.AddView(xpnlCursor, 0, 0, xBase.Width, xBas";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.AddView((android.view.View)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv2.getObject()),(int) (0),(int) (0),_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.getWidth(),_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.getHeight());
 //BA.debugLineNum = 284;BA.debugLine="xcvsCursor.Initialize(xpnlCursor)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.Initialize(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv2);
 //BA.debugLineNum = 286;BA.debugLine="xpnlValues = xui.CreatePanel(\"xpnlValues\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0 = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreatePanel(ba,"xpnlValues");
 //BA.debugLineNum = 287;BA.debugLine="xBase.AddView(xpnlValues, 0, 0, 100dip, 100dip)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.AddView((android.view.View)(_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.getObject()),(int) (0),(int) (0),__c.DipToCurrent((int) (100)),__c.DipToCurrent((int) (100)));
 //BA.debugLineNum = 288;BA.debugLine="xpnlValues.Visible = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.setVisible(__c.False);
 //BA.debugLineNum = 289;BA.debugLine="xcvsValues.Initialize(xpnlValues)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Initialize(_vvvvvvvvvvvvvvvvvvvvvvvvvvv0);
 //BA.debugLineNum = 291;BA.debugLine="BMVNFUsed = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv0 = __c.False;
 //BA.debugLineNum = 292;BA.debugLine="BMVNF.MinimumIntegers = 1";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.MinimumIntegers = (int) (1);
 //BA.debugLineNum = 293;BA.debugLine="BMVNF.MaximumFractions = 0";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.MaximumFractions = (int) (0);
 //BA.debugLineNum = 294;BA.debugLine="BMVNF.MinimumFractions = 2";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.MinimumFractions = (int) (2);
 //BA.debugLineNum = 295;BA.debugLine="BMVNF.GroupingUsed = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.GroupingUsed = __c.False;
 //BA.debugLineNum = 296;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvv2() throws Exception{
cmarsoft.recu.xchart._pointdata _pd = null;
int _i = 0;
int _smean = 0;
int _smean0 = 0;
int _h = 0;
int _x0 = 0;
int _y0 = 0;
int _yt = 0;
double _total = 0;
double _mean = 0;
String _txt = "";
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _rcttext = null;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _rctmean = null;
double _txtw = 0;
double _txth = 0;
 //BA.debugLineNum = 1712;BA.debugLine="Private Sub DrawBarMeanLine";
 //BA.debugLineNum = 1713;BA.debugLine="If MinMaxMeanValues(0) = 0 And MinMaxMeanValues(1";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)]==0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)]==0) { 
if (true) return "";};
 //BA.debugLineNum = 1715;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1716;BA.debugLine="PD = Points.Get(0)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get((int) (0)));
 //BA.debugLineNum = 1718;BA.debugLine="If PD.YArray.Length > 1 Then Return";
if (_pd.YArray.length>1) { 
if (true) return "";};
 //BA.debugLineNum = 1720;BA.debugLine="Private i, sMean, sMean0, h, x0, y0, yt As Int";
_i = 0;
_smean = 0;
_smean0 = 0;
_h = 0;
_x0 = 0;
_y0 = 0;
_yt = 0;
 //BA.debugLineNum = 1721;BA.debugLine="Private Total, Mean As Double";
_total = 0;
_mean = 0;
 //BA.debugLineNum = 1722;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step7 = 1;
final int limit7 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit7 ;_i = _i + step7 ) {
 //BA.debugLineNum = 1723;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1724;BA.debugLine="Total = Total + PD.YArray(0)";
_total = _total+_pd.YArray[(int) (0)];
 }
};
 //BA.debugLineNum = 1726;BA.debugLine="Mean = Total / Points.Size";
_mean = _total/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize();
 //BA.debugLineNum = 1727;BA.debugLine="sMean0 = Mean * Scale(sY).Scale";
_smean0 = (int) (_mean*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1728;BA.debugLine="sMean = Graph.Bottom - (Mean - Scale(sY).MinVal)";
_smean = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-(_mean-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1733;BA.debugLine="xcvsGraph.DrawLine(Graph.Left, sMean, Graph.Right";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_smean),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_smean),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MeanLineColor,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1735;BA.debugLine="If Scale(sY).MinVal = 0 And Scale(sY).MaxVal > 0";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal==0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal>0) { 
 //BA.debugLineNum = 1736;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step16 = 1;
final int limit16 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit16 ;_i = _i + step16 ) {
 //BA.debugLineNum = 1737;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1738;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1739;BA.debugLine="h = PD.YArray(0) * Scale(sY).Scale";
_h = (int) (_pd.YArray[(int) (0)]*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1740;BA.debugLine="If sMean0 > h + 0.5 * Texts.ScaleTextHeight The";
if (_smean0>_h+0.5*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight) { 
 //BA.debugLineNum = 1741;BA.debugLine="x0 = Graph.Left + Graph.XOffset + (i  + 0.5) *";
_x0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset+(_i+0.5)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval);
 //BA.debugLineNum = 1742;BA.debugLine="y0 = sMean - 0.9 * Texts.ScaleTextHeight";
_y0 = (int) (_smean-0.9*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 1743;BA.debugLine="yt = sMean - 0.2 * Texts.ScaleTextHeight";
_yt = (int) (_smean-0.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 1744;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 }else if(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal<0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal<=0) { 
 //BA.debugLineNum = 1748;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step28 = 1;
final int limit28 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit28 ;_i = _i + step28 ) {
 //BA.debugLineNum = 1749;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1750;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1751;BA.debugLine="h = -PD.YArray(0) * Scale(sY).Scale";
_h = (int) (-_pd.YArray[(int) (0)]*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1752;BA.debugLine="If -sMean0 > h + 0.2 * Texts.ScaleTextHeight Th";
if (-_smean0>_h+0.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight) { 
 //BA.debugLineNum = 1753;BA.debugLine="x0 = Graph.Left + Graph.XOffset + (i  + 0.5) *";
_x0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset+(_i+0.5)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval);
 //BA.debugLineNum = 1754;BA.debugLine="y0 = sMean + 0.2 * Texts.ScaleTextHeight";
_y0 = (int) (_smean+0.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 1755;BA.debugLine="yt = sMean + 0.8 * Texts.ScaleTextHeight";
_yt = (int) (_smean+0.8*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 1756;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 }else {
 //BA.debugLineNum = 1760;BA.debugLine="If Mean >= 0 Then";
if (_mean>=0) { 
 //BA.debugLineNum = 1761;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step41 = 1;
final int limit41 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit41 ;_i = _i + step41 ) {
 //BA.debugLineNum = 1762;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1763;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1764;BA.debugLine="h = PD.YArray(0) * Scale(sY).Scale";
_h = (int) (_pd.YArray[(int) (0)]*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1765;BA.debugLine="If Mean >= 0 And sMean0 > h + 0.5 * Texts.Scal";
if (_mean>=0 && _smean0>_h+0.5*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight) { 
 //BA.debugLineNum = 1766;BA.debugLine="x0 = Graph.Left + Graph.XOffset + (i  + 0.5)";
_x0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset+(_i+0.5)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval);
 //BA.debugLineNum = 1767;BA.debugLine="y0 = sMean - 0.9 * Texts.ScaleTextHeight";
_y0 = (int) (_smean-0.9*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 1768;BA.debugLine="yt = sMean - 0.2 * Texts.ScaleTextHeight";
_yt = (int) (_smean-0.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 1769;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 }else {
 //BA.debugLineNum = 1773;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step53 = 1;
final int limit53 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit53 ;_i = _i + step53 ) {
 //BA.debugLineNum = 1774;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1775;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1776;BA.debugLine="h = -PD.YArray(0) * Scale(sY).Scale";
_h = (int) (-_pd.YArray[(int) (0)]*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1777;BA.debugLine="If Mean < 0 And -sMean0 > h + 0.2 * Texts.Scal";
if (_mean<0 && -_smean0>_h+0.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight) { 
 //BA.debugLineNum = 1778;BA.debugLine="x0 = Graph.Left + Graph.XOffset + (i  + 0.5)";
_x0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset+(_i+0.5)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval);
 //BA.debugLineNum = 1779;BA.debugLine="y0 = sMean + 0.2 * Texts.ScaleTextHeight";
_y0 = (int) (_smean+0.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 1780;BA.debugLine="yt = sMean + 0.8 * Texts.ScaleTextHeight";
_yt = (int) (_smean+0.8*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 1781;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 };
 };
 //BA.debugLineNum = 1787;BA.debugLine="Private txt As String";
_txt = "";
 //BA.debugLineNum = 1788;BA.debugLine="Private rctText, rctMean As B4XRect";
_rcttext = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
_rctmean = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 1789;BA.debugLine="Private txtW, txtH As Double";
_txtw = 0;
_txth = 0;
 //BA.debugLineNum = 1790;BA.debugLine="If BMVNFUsed = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv0==__c.False) { 
 //BA.debugLineNum = 1791;BA.debugLine="txt = NumberFormat3(Mean, 6)";
_txt = _vvvvvvvvvvvvvv4(_mean,(int) (6));
 }else {
 //BA.debugLineNum = 1793;BA.debugLine="txt = NumberFormat2(Mean, BMVNF.MinimumIntegers,";
_txt = __c.NumberFormat2(_mean,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.MinimumIntegers,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.MaximumFractions,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.MinimumFractions,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.GroupingUsed);
 };
 //BA.debugLineNum = 1795;BA.debugLine="rctText = xcvsGraph.MeasureText(txt, Texts.ScaleF";
_rcttext = _vvvvvvvvvvvvvvvvvvvvvvvvvvv7.MeasureText(_txt,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont);
 //BA.debugLineNum = 1796;BA.debugLine="txtW = 4dip + rctText.Width";
_txtw = __c.DipToCurrent((int) (4))+_rcttext.getWidth();
 //BA.debugLineNum = 1797;BA.debugLine="txtH = 1.2 * rctText.Height";
_txth = 1.2*_rcttext.getHeight();
 //BA.debugLineNum = 1798;BA.debugLine="rctMean.Initialize(x0 - txtW / 2, y0, x0 + txtW /";
_rctmean.Initialize((float) (_x0-_txtw/(double)2),(float) (_y0),(float) (_x0+_txtw/(double)2),(float) (_y0+_txth));
 //BA.debugLineNum = 1799;BA.debugLine="xcvsGraph.DrawRect(rctMean, Graph.ChartBackground";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_rctmean,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor,__c.True,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1800;BA.debugLine="xcvsGraph.DrawText(txt, x0, yt, Texts.ScaleFont,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_txt,(float) (_x0),(float) (_yt),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MeanLineColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 //BA.debugLineNum = 1802;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvv3() throws Exception{
int _i = 0;
int _j = 0;
int _x0 = 0;
int _x = 0;
int _h = 0;
int _y = 0;
int[] _cols = null;
int[] _acols = null;
String[] _names = null;
cmarsoft.recu.xchart._itemdata _id = null;
b4a.example.bitmapcreator._argbcolor _argb = null;
b4a.example.bitmapcreator _bmpcreate = null;
int _myaxis0 = 0;
cmarsoft.recu.xchart._pointdata _pd = null;
double[] _py = null;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _r = null;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _rb = null;
b4a.example.bitmapcreator _bmc1 = null;
 //BA.debugLineNum = 1613;BA.debugLine="Private Sub DrawBars";
 //BA.debugLineNum = 1614;BA.debugLine="Private i, j, x0, x, h, y As Int";
_i = 0;
_j = 0;
_x0 = 0;
_x = 0;
_h = 0;
_y = 0;
 //BA.debugLineNum = 1615;BA.debugLine="Private Cols(Items.Size), ACols(Items.Size) As In";
_cols = new int[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()];
;
_acols = new int[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()];
;
 //BA.debugLineNum = 1616;BA.debugLine="Private Names(Items.Size) As String";
_names = new String[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()];
java.util.Arrays.fill(_names,"");
 //BA.debugLineNum = 1618;BA.debugLine="For i = 0 To Items.Size - 1";
{
final int step4 = 1;
final int limit4 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit4 ;_i = _i + step4 ) {
 //BA.debugLineNum = 1619;BA.debugLine="Private ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 1620;BA.debugLine="ID = Items.Get(i)";
_id = (cmarsoft.recu.xchart._itemdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Get(_i));
 //BA.debugLineNum = 1621;BA.debugLine="Cols(i) = ID.Color";
_cols[_i] = _id.Color;
 //BA.debugLineNum = 1622;BA.debugLine="Private ARGB As ARGBColor";
_argb = new b4a.example.bitmapcreator._argbcolor();
 //BA.debugLineNum = 1623;BA.debugLine="Private BmpCreate As BitmapCreator";
_bmpcreate = new b4a.example.bitmapcreator();
 //BA.debugLineNum = 1624;BA.debugLine="BmpCreate.Initialize(10, 10)";
_bmpcreate._initialize(ba,(int) (10),(int) (10));
 //BA.debugLineNum = 1625;BA.debugLine="BmpCreate.ColorToARGB(Cols(i), ARGB)";
_bmpcreate._colortoargb(_cols[_i],_argb);
 //BA.debugLineNum = 1626;BA.debugLine="ACols(i) = xui.Color_ARGB(Graph.GradientColorsAl";
_acols[_i] = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_ARGB(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColorsAlpha,_argb.r,_argb.g,_argb.b);
 //BA.debugLineNum = 1627;BA.debugLine="Names(i) = ID.Name";
_names[_i] = _id.Name;
 }
};
 //BA.debugLineNum = 1630;BA.debugLine="If Graph.ChartType = \"BAR\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("BAR")) { 
 //BA.debugLineNum = 1631;BA.debugLine="Private mYAxis0 = Graph.Bottom + Scale(sY).MinVa";
_myaxis0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1633;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step17 = 1;
final int limit17 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit17 ;_i = _i + step17 ) {
 //BA.debugLineNum = 1634;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1635;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1636;BA.debugLine="Private py(PD.YArray.Length) As Double";
_py = new double[_pd.YArray.length];
;
 //BA.debugLineNum = 1637;BA.debugLine="x0 = Graph.Left + Graph.XOffset + (i  + 0.5) *";
_x0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset+(_i+0.5)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarWidth/(double)2);
 //BA.debugLineNum = 1638;BA.debugLine="py = PD.YArray";
_py = _pd.YArray;
 //BA.debugLineNum = 1640;BA.debugLine="For j = 0 To PD.YArray.Length - 1";
{
final int step23 = 1;
final int limit23 = (int) (_pd.YArray.length-1);
_j = (int) (0) ;
for (;_j <= limit23 ;_j = _j + step23 ) {
 //BA.debugLineNum = 1641;BA.debugLine="Private r, rb As B4XRect";
_r = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
_rb = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 1642;BA.debugLine="x = x0 + j * Graph.BarSubWidth";
_x = (int) (_x0+_j*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarSubWidth);
 //BA.debugLineNum = 1643;BA.debugLine="h = py(j) * Scale(sY).Scale";
_h = (int) (_py[_j]*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1645;BA.debugLine="If h > 0 Then";
if (_h>0) { 
 //BA.debugLineNum = 1646;BA.debugLine="r.Initialize(x, mYAxis0 - h, x + Graph.BarSub";
_r.Initialize((float) (_x),(float) (_myaxis0-_h),(float) (_x+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarSubWidth),(float) (_myaxis0));
 }else {
 //BA.debugLineNum = 1648;BA.debugLine="r.Initialize(x, mYAxis0, x + Graph.BarSubWidt";
_r.Initialize((float) (_x),(float) (_myaxis0),(float) (_x+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarSubWidth),(float) (_myaxis0-_h));
 };
 //BA.debugLineNum = 1650;BA.debugLine="If Graph.GradientColors = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColors==__c.False) { 
 //BA.debugLineNum = 1651;BA.debugLine="xcvsGraph.DrawRect(r, Cols(j), True, 1dip)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_cols[_j],__c.True,(float) (__c.DipToCurrent((int) (1))));
 }else {
 //BA.debugLineNum = 1653;BA.debugLine="Private bmc1 As BitmapCreator";
_bmc1 = new b4a.example.bitmapcreator();
 //BA.debugLineNum = 1654;BA.debugLine="rb.Initialize(0, 0, Graph.BarSubWidth, Max(1,";
_rb.Initialize((float) (0),(float) (0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarSubWidth),(float) (__c.Max(1,__c.Abs(_h))));
 //BA.debugLineNum = 1655;BA.debugLine="bmc1.Initialize(Graph.BarSubWidth, Max(1, Abs";
_bmc1._initialize(ba,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarSubWidth,(int) (__c.Max(1,__c.Abs(_h))));
 //BA.debugLineNum = 1656;BA.debugLine="If h > 0 Then";
if (_h>0) { 
 //BA.debugLineNum = 1657;BA.debugLine="bmc1.FillGradient(Array As Int(Cols(j), ACol";
_bmc1._fillgradient(new int[]{_cols[_j],_acols[_j]},_rb,"TOP_BOTTOM");
 }else {
 //BA.debugLineNum = 1659;BA.debugLine="bmc1.FillGradient(Array As Int(Cols(j), ACol";
_bmc1._fillgradient(new int[]{_cols[_j],_acols[_j]},_rb,"BOTTOM_TOP");
 };
 //BA.debugLineNum = 1661;BA.debugLine="xcvsGraph.DrawBitmap(bmc1.Bitmap, r)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawBitmap((android.graphics.Bitmap)(_bmc1._getbitmap().getObject()),_r);
 };
 }
};
 }
};
 //BA.debugLineNum = 1665;BA.debugLine="xcvsGraph.DrawLine(Graph.Left, mYAxis0, Graph.Ri";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_myaxis0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_myaxis0),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1667;BA.debugLine="If Graph.IncludeValues = True And PD.YArray.Leng";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeValues==__c.True && _pd.YArray.length==1) { 
 //BA.debugLineNum = 1668;BA.debugLine="DrawBarValues";
_vvvvvv4();
 };
 //BA.debugLineNum = 1671;BA.debugLine="If Graph.IncludeBarMeanLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeBarMeanLine==__c.True) { 
 //BA.debugLineNum = 1672;BA.debugLine="DrawBarMeanLine";
_vvvvvv2();
 };
 }else {
 //BA.debugLineNum = 1675;BA.debugLine="Private mYAxis0 = Graph.Bottom As Int";
_myaxis0 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom;
 //BA.debugLineNum = 1677;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step56 = 1;
final int limit56 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit56 ;_i = _i + step56 ) {
 //BA.debugLineNum = 1678;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1679;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1680;BA.debugLine="Private py(PD.YArray.Length) As Double";
_py = new double[_pd.YArray.length];
;
 //BA.debugLineNum = 1681;BA.debugLine="x0 = Graph.Left + Graph.XOffset + (i  + 0.5) *";
_x0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset+(_i+0.5)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarWidth/(double)2);
 //BA.debugLineNum = 1682;BA.debugLine="py = PD.YArray";
_py = _pd.YArray;
 //BA.debugLineNum = 1684;BA.debugLine="y = mYAxis0";
_y = _myaxis0;
 //BA.debugLineNum = 1685;BA.debugLine="For j = 0 To PD.YArray.Length - 1";
{
final int step63 = 1;
final int limit63 = (int) (_pd.YArray.length-1);
_j = (int) (0) ;
for (;_j <= limit63 ;_j = _j + step63 ) {
 //BA.debugLineNum = 1686;BA.debugLine="Private r, rb As B4XRect";
_r = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
_rb = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 1687;BA.debugLine="h = py(j) * Scale(sY).Scale";
_h = (int) (_py[_j]*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1688;BA.debugLine="r.Initialize(x0, y - h, x0 + Graph.BarWidth, y";
_r.Initialize((float) (_x0),(float) (_y-_h),(float) (_x0+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarWidth),(float) (_y));
 //BA.debugLineNum = 1689;BA.debugLine="If Graph.GradientColors = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColors==__c.False) { 
 //BA.debugLineNum = 1690;BA.debugLine="xcvsGraph.DrawRect(r, Cols(j), True, 1dip)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_cols[_j],__c.True,(float) (__c.DipToCurrent((int) (1))));
 }else {
 //BA.debugLineNum = 1692;BA.debugLine="rb.Initialize(0, 0, Graph.BarSubWidth, Max(1,";
_rb.Initialize((float) (0),(float) (0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarSubWidth),(float) (__c.Max(1,__c.Abs(_h))));
 //BA.debugLineNum = 1693;BA.debugLine="Private bmc1 As BitmapCreator";
_bmc1 = new b4a.example.bitmapcreator();
 //BA.debugLineNum = 1694;BA.debugLine="bmc1.Initialize(Graph.BarSubWidth, Max(1, Abs";
_bmc1._initialize(ba,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarSubWidth,(int) (__c.Max(1,__c.Abs(_h))));
 //BA.debugLineNum = 1695;BA.debugLine="bmc1.FillGradient(Array As Int(Cols(j), ACols";
_bmc1._fillgradient(new int[]{_cols[_j],_acols[_j]},_rb,"TOP_BOTTOM");
 //BA.debugLineNum = 1696;BA.debugLine="xcvsGraph.DrawBitmap(bmc1.Bitmap, r)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawBitmap((android.graphics.Bitmap)(_bmc1._getbitmap().getObject()),_r);
 };
 //BA.debugLineNum = 1698;BA.debugLine="y = y - h";
_y = (int) (_y-_h);
 }
};
 }
};
 //BA.debugLineNum = 1701;BA.debugLine="xcvsGraph.DrawLine(Graph.Left, mYAxis0, Graph.Ri";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_myaxis0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_myaxis0),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,(float) (__c.DipToCurrent((int) (1))));
 };
 //BA.debugLineNum = 1704;BA.debugLine="If Legend.IncludeLegend <> \"NONE\" And Items.Size";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend).equals("NONE") == false && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()>0) { 
 //BA.debugLineNum = 1705;BA.debugLine="DrawLegend";
_vvvvvv0();
 };
 //BA.debugLineNum = 1708;BA.debugLine="xcvsGraph.Invalidate";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.Invalidate();
 //BA.debugLineNum = 1709;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvv4() throws Exception{
int _i = 0;
int _h = 0;
int _x = 0;
int _xt = 0;
int _dy = 0;
int _y = 0;
int _yt = 0;
int _col = 0;
String _txt = "";
int _myaxis0 = 0;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _recttext = null;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _recttextbackground = null;
int _textwidth = 0;
String _localbarvalueorientation = "";
float _localtextsize = 0f;
int _localtextheight = 0;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _localfont = null;
cmarsoft.recu.xchart._itemdata _id = null;
cmarsoft.recu.xchart._pointdata _pd = null;
double[] _py = null;
String _textalignment = "";
 //BA.debugLineNum = 1805;BA.debugLine="Private Sub DrawBarValues";
 //BA.debugLineNum = 1806;BA.debugLine="If MinMaxMeanValues(0) = 0 And MinMaxMeanValues(1";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)]==0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)]==0) { 
if (true) return "";};
 //BA.debugLineNum = 1808;BA.debugLine="Private i, h, x, xt, dy, y, yt As Int";
_i = 0;
_h = 0;
_x = 0;
_xt = 0;
_dy = 0;
_y = 0;
_yt = 0;
 //BA.debugLineNum = 1809;BA.debugLine="Private Col As Int";
_col = 0;
 //BA.debugLineNum = 1810;BA.debugLine="Private txt As String";
_txt = "";
 //BA.debugLineNum = 1811;BA.debugLine="Private mYAxis0 = Graph.Bottom + Scale(sY).MinVal";
_myaxis0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1812;BA.debugLine="Private rectText, rectTextBackground As B4XRect";
_recttext = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
_recttextbackground = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 1813;BA.debugLine="Private TextWidth As Int";
_textwidth = 0;
 //BA.debugLineNum = 1814;BA.debugLine="Private LocalBarValueOrientation As String";
_localbarvalueorientation = "";
 //BA.debugLineNum = 1815;BA.debugLine="Private LocalTextSize As Float";
_localtextsize = 0f;
 //BA.debugLineNum = 1816;BA.debugLine="Private LocalTextHeight As Int";
_localtextheight = 0;
 //BA.debugLineNum = 1817;BA.debugLine="Private LocalFont As B4XFont";
_localfont = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont();
 //BA.debugLineNum = 1818;BA.debugLine="Private ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 1820;BA.debugLine="ID = Items.Get(0)";
_id = (cmarsoft.recu.xchart._itemdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Get((int) (0)));
 //BA.debugLineNum = 1822;BA.debugLine="LocalBarValueOrientation = Graph.BarValueOrientat";
_localbarvalueorientation = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarValueOrientation;
 //BA.debugLineNum = 1823;BA.debugLine="LocalFont = Texts.ScaleFont";
_localfont = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont;
 //BA.debugLineNum = 1824;BA.debugLine="LocalTextHeight = Texts.ScaleTextHeight";
_localtextheight = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight;
 //BA.debugLineNum = 1825;BA.debugLine="LocalTextSize = Texts.ScaleTextSize";
_localtextsize = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextSize;
 //BA.debugLineNum = 1827;BA.debugLine="If Graph.BarValueOrientation = \"HORIZONTAL\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarValueOrientation).equals("HORIZONTAL")) { 
 //BA.debugLineNum = 1828;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step19 = 1;
final int limit19 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit19 ;_i = _i + step19 ) {
 //BA.debugLineNum = 1829;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1830;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1831;BA.debugLine="Private py(PD.YArray.Length) As Double";
_py = new double[_pd.YArray.length];
;
 //BA.debugLineNum = 1832;BA.debugLine="py = PD.YArray";
_py = _pd.YArray;
 //BA.debugLineNum = 1833;BA.debugLine="rectText = xcvsGraph.MeasureText(py(0), Texts.S";
_recttext = _vvvvvvvvvvvvvvvvvvvvvvvvvvv7.MeasureText(BA.NumberToString(_py[(int) (0)]),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont);
 //BA.debugLineNum = 1834;BA.debugLine="TextWidth = rectText.Width + Texts.ScaleTextHei";
_textwidth = (int) (_recttext.getWidth()+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 1835;BA.debugLine="If TextWidth + Texts.ScaleTextHeight > Graph.XI";
if (_textwidth+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval) { 
 //BA.debugLineNum = 1836;BA.debugLine="LocalBarValueOrientation = \"VERTICAL\"";
_localbarvalueorientation = "VERTICAL";
 //BA.debugLineNum = 1837;BA.debugLine="Log(\"xChart BarValueOrientation set to VERTICA";
__c.LogImpl("93866656","xChart BarValueOrientation set to VERTICAL",0);
 //BA.debugLineNum = 1838;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 };
 //BA.debugLineNum = 1843;BA.debugLine="If LocalBarValueOrientation = \"VERTICAL\" Then";
if ((_localbarvalueorientation).equals("VERTICAL")) { 
 //BA.debugLineNum = 1844;BA.debugLine="Private TextAlignment As String";
_textalignment = "";
 //BA.debugLineNum = 1847;BA.debugLine="If Texts.ScaleTextHeight - 4dip > Graph.BarWidth";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight-__c.DipToCurrent((int) (4))>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarWidth) { 
 //BA.debugLineNum = 1848;BA.debugLine="rectText = xcvsGraph.MeasureText(\"10\", Texts.Sc";
_recttext = _vvvvvvvvvvvvvvvvvvvvvvvvvvv7.MeasureText("10",_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont);
 //BA.debugLineNum = 1849;BA.debugLine="LocalTextSize = Texts.ScaleTextSize * Graph.Bar";
_localtextsize = (float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextSize*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarWidth/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 1850;BA.debugLine="LocalFont = xui.CreateFont2(Texts.ScaleFont, Lo";
_localfont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateFont2(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont,_localtextsize);
 //BA.debugLineNum = 1851;BA.debugLine="LocalTextHeight = Texts.ScaleTextHeight * Local";
_localtextheight = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight*_localtextsize/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextSize);
 //BA.debugLineNum = 1852;BA.debugLine="If LocalTextSize < 10 Then";
if (_localtextsize<10) { 
 //BA.debugLineNum = 1853;BA.debugLine="Log(\"Bar value text size too small\")";
__c.LogImpl("93866672","Bar value text size too small",0);
 //BA.debugLineNum = 1854;BA.debugLine="Return";
if (true) return "";
 };
 };
 //BA.debugLineNum = 1858;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step45 = 1;
final int limit45 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit45 ;_i = _i + step45 ) {
 //BA.debugLineNum = 1859;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1860;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1861;BA.debugLine="Private py(PD.YArray.Length) As Double";
_py = new double[_pd.YArray.length];
;
 //BA.debugLineNum = 1862;BA.debugLine="py = PD.YArray";
_py = _pd.YArray;
 //BA.debugLineNum = 1863;BA.debugLine="xt = Graph.Left + Graph.XOffset + (i + 0.5) * G";
_xt = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset+(_i+0.5)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval+0.28*_localtextheight);
 //BA.debugLineNum = 1864;BA.debugLine="x = xt - 0.72 * LocalTextHeight";
_x = (int) (_xt-0.72*_localtextheight);
 //BA.debugLineNum = 1865;BA.debugLine="h = py(0) * Scale(sY).Scale";
_h = (int) (_py[(int) (0)]*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1866;BA.debugLine="rectText = xcvsGraph.MeasureText(py(0), LocalFo";
_recttext = _vvvvvvvvvvvvvvvvvvvvvvvvvvv7.MeasureText(BA.NumberToString(_py[(int) (0)]),_localfont);
 //BA.debugLineNum = 1867;BA.debugLine="TextWidth = rectText.Width + LocalTextHeight";
_textwidth = (int) (_recttext.getWidth()+_localtextheight);
 //BA.debugLineNum = 1868;BA.debugLine="If Abs(h) > TextWidth Then";
if (__c.Abs(_h)>_textwidth) { 
 //BA.debugLineNum = 1869;BA.debugLine="yt = mYAxis0 - h / 2";
_yt = (int) (_myaxis0-_h/(double)2);
 //BA.debugLineNum = 1870;BA.debugLine="TextAlignment = \"CENTER\"";
_textalignment = "CENTER";
 //BA.debugLineNum = 1871;BA.debugLine="Col = GetContrastColor(ID.Color)";
_col = _vvvvvvvv5(_id.Color);
 }else {
 //BA.debugLineNum = 1873;BA.debugLine="y = mYAxis0 - h";
_y = (int) (_myaxis0-_h);
 //BA.debugLineNum = 1874;BA.debugLine="dy = 0.5 * LocalTextHeight";
_dy = (int) (0.5*_localtextheight);
 //BA.debugLineNum = 1875;BA.debugLine="rectTextBackground.Initialize(x, y, x + LocalT";
_recttextbackground.Initialize((float) (_x),(float) (_y),(float) (_x+_localtextheight),(float) (_y+_textwidth));
 //BA.debugLineNum = 1876;BA.debugLine="rectTextBackground.Height = TextWidth";
_recttextbackground.setHeight((float) (_textwidth));
 //BA.debugLineNum = 1877;BA.debugLine="If h = 0 Then";
if (_h==0) { 
 //BA.debugLineNum = 1878;BA.debugLine="If Scale(sY).MinVal < 0 And Scale(sY).MaxVal";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal<0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal<=0) { 
 //BA.debugLineNum = 1879;BA.debugLine="yt = y - dy";
_yt = (int) (_y-_dy);
 //BA.debugLineNum = 1880;BA.debugLine="TextAlignment = \"RIGHT\"";
_textalignment = "RIGHT";
 //BA.debugLineNum = 1881;BA.debugLine="rectTextBackground.Top = y";
_recttextbackground.setTop((float) (_y));
 //BA.debugLineNum = 1882;BA.debugLine="rectTextBackground.Height = TextWidth";
_recttextbackground.setHeight((float) (_textwidth));
 }else {
 //BA.debugLineNum = 1884;BA.debugLine="yt = y - dy";
_yt = (int) (_y-_dy);
 //BA.debugLineNum = 1885;BA.debugLine="TextAlignment = \"LEFT\"";
_textalignment = "LEFT";
 //BA.debugLineNum = 1886;BA.debugLine="rectTextBackground.Top = y - TextWidth";
_recttextbackground.setTop((float) (_y-_textwidth));
 //BA.debugLineNum = 1887;BA.debugLine="rectTextBackground.Height = TextWidth";
_recttextbackground.setHeight((float) (_textwidth));
 };
 }else if(_h>0) { 
 //BA.debugLineNum = 1890;BA.debugLine="If Abs(h) + TextWidth > mYAxis0 - Graph.Top T";
if (__c.Abs(_h)+_textwidth>_myaxis0-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top) { 
 //BA.debugLineNum = 1891;BA.debugLine="yt = mYAxis0 + dy + 2dip";
_yt = (int) (_myaxis0+_dy+__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 1892;BA.debugLine="TextAlignment = \"RIGHT\"";
_textalignment = "RIGHT";
 //BA.debugLineNum = 1893;BA.debugLine="rectTextBackground.Top = mYAxis0 + 2dip";
_recttextbackground.setTop((float) (_myaxis0+__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1894;BA.debugLine="rectTextBackground.Height = TextWidth";
_recttextbackground.setHeight((float) (_textwidth));
 }else {
 //BA.debugLineNum = 1896;BA.debugLine="yt = y - dy";
_yt = (int) (_y-_dy);
 //BA.debugLineNum = 1897;BA.debugLine="TextAlignment = \"LEFT\"";
_textalignment = "LEFT";
 //BA.debugLineNum = 1898;BA.debugLine="rectTextBackground.Top = y - TextWidth";
_recttextbackground.setTop((float) (_y-_textwidth));
 //BA.debugLineNum = 1899;BA.debugLine="rectTextBackground.Height = TextWidth";
_recttextbackground.setHeight((float) (_textwidth));
 };
 }else {
 //BA.debugLineNum = 1902;BA.debugLine="If Abs(h) + TextWidth > Graph.Bottom - mYAxis";
if (__c.Abs(_h)+_textwidth>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-_myaxis0) { 
 //BA.debugLineNum = 1903;BA.debugLine="yt = mYAxis0 - dy- 2dip";
_yt = (int) (_myaxis0-_dy-__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 1904;BA.debugLine="TextAlignment = \"LEFT\"";
_textalignment = "LEFT";
 //BA.debugLineNum = 1905;BA.debugLine="rectTextBackground.Top = mYAxis0 - TextWidth";
_recttextbackground.setTop((float) (_myaxis0-_textwidth-__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1906;BA.debugLine="rectTextBackground.Height = TextWidth";
_recttextbackground.setHeight((float) (_textwidth));
 }else {
 //BA.debugLineNum = 1908;BA.debugLine="yt = y + dy";
_yt = (int) (_y+_dy);
 //BA.debugLineNum = 1909;BA.debugLine="TextAlignment = \"RIGHT\"";
_textalignment = "RIGHT";
 //BA.debugLineNum = 1910;BA.debugLine="rectTextBackground.Top = y";
_recttextbackground.setTop((float) (_y));
 //BA.debugLineNum = 1911;BA.debugLine="rectTextBackground.Height = TextWidth";
_recttextbackground.setHeight((float) (_textwidth));
 };
 };
 //BA.debugLineNum = 1915;BA.debugLine="Col = GetContrastColor(Graph.ChartBackgroundCo";
_col = _vvvvvvvv5(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor);
 //BA.debugLineNum = 1916;BA.debugLine="xcvsGraph.DrawRect(rectTextBackground, Graph.C";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_recttextbackground,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor,__c.True,(float) (__c.DipToCurrent((int) (1))));
 };
 //BA.debugLineNum = 1918;BA.debugLine="txt = py(0)";
_txt = BA.NumberToString(_py[(int) (0)]);
 //BA.debugLineNum = 1919;BA.debugLine="xcvsGraph.DrawTextRotated(txt, xt, yt, LocalFon";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawTextRotated(ba,_txt,(float) (_xt),(float) (_yt),_localfont,_col,BA.getEnumFromString(android.graphics.Paint.Align.class,_textalignment),(float) (-90));
 }
};
 }else {
 //BA.debugLineNum = 1922;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step108 = 1;
final int limit108 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit108 ;_i = _i + step108 ) {
 //BA.debugLineNum = 1923;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1924;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1925;BA.debugLine="Private py(PD.YArray.Length) As Double";
_py = new double[_pd.YArray.length];
;
 //BA.debugLineNum = 1926;BA.debugLine="py = PD.YArray";
_py = _pd.YArray;
 //BA.debugLineNum = 1927;BA.debugLine="x = Graph.Left + Graph.XOffset + (i + 0.5) * Gr";
_x = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset+(_i+0.5)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval);
 //BA.debugLineNum = 1928;BA.debugLine="h = py(0) * Scale(sY).Scale";
_h = (int) (_py[(int) (0)]*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1929;BA.debugLine="If Abs(h) > 1.5 * Texts.ScaleTextHeight Then";
if (__c.Abs(_h)>1.5*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight) { 
 //BA.debugLineNum = 1930;BA.debugLine="y = mYAxis0 - h / 2";
_y = (int) (_myaxis0-_h/(double)2);
 //BA.debugLineNum = 1931;BA.debugLine="If h >= 0 Then";
if (_h>=0) { 
 //BA.debugLineNum = 1932;BA.debugLine="y = y + 0.3 * Texts.ScaleTextHeight";
_y = (int) (_y+0.3*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 }else {
 //BA.debugLineNum = 1934;BA.debugLine="y = y + 0.25 * Texts.ScaleTextHeight";
_y = (int) (_y+0.25*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 };
 //BA.debugLineNum = 1936;BA.debugLine="Col = GetContrastColor(ID.Color)";
_col = _vvvvvvvv5(_id.Color);
 }else {
 //BA.debugLineNum = 1938;BA.debugLine="y = mYAxis0 - h";
_y = (int) (_myaxis0-_h);
 //BA.debugLineNum = 1939;BA.debugLine="If h = 0 Then";
if (_h==0) { 
 //BA.debugLineNum = 1940;BA.debugLine="If Scale(sY).MinVal < 0 And Scale(sY).MaxVal";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal<0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal<=0) { 
 //BA.debugLineNum = 1941;BA.debugLine="y = y + 0.9 * Texts.ScaleTextHeight";
_y = (int) (_y+0.9*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 }else {
 //BA.debugLineNum = 1943;BA.debugLine="y = y - Texts.ScaleTextHeight / 3";
_y = (int) (_y-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight/(double)3);
 };
 }else if(_h>0) { 
 //BA.debugLineNum = 1946;BA.debugLine="y = y - Texts.ScaleTextHeight / 3";
_y = (int) (_y-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight/(double)3);
 }else {
 //BA.debugLineNum = 1948;BA.debugLine="y = y + 0.9 * Texts.ScaleTextHeight";
_y = (int) (_y+0.9*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 };
 //BA.debugLineNum = 1951;BA.debugLine="Col = GetContrastColor(Graph.ChartBackgroundCo";
_col = _vvvvvvvv5(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor);
 };
 //BA.debugLineNum = 1953;BA.debugLine="txt = py(0)";
_txt = BA.NumberToString(_py[(int) (0)]);
 //BA.debugLineNum = 1954;BA.debugLine="xcvsGraph.DrawText(txt, x, y, Texts.ScaleFont,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_txt,(float) (_x),(float) (_y),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont,_col,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 }
};
 };
 //BA.debugLineNum = 1957;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvv5() throws Exception{
 //BA.debugLineNum = 1200;BA.debugLine="Public Sub DrawChart";
 //BA.debugLineNum = 1201;BA.debugLine="InitChart";
_vvvvvvvvvvvvv0();
 //BA.debugLineNum = 1202;BA.debugLine="Select Graph.ChartType";
switch (BA.switchObjectToInt(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType,"LINE","BAR","STACKED_BAR","PIE","YX_CHART")) {
case 0: {
 //BA.debugLineNum = 1204;BA.debugLine="GetXIntervals";
_vvvvvvvvvvvv6();
 //BA.debugLineNum = 1205;BA.debugLine="DrawGrid";
_vvvvvv6();
 //BA.debugLineNum = 1206;BA.debugLine="DrawLines";
_vvvvvvv1();
 break; }
case 1: 
case 2: {
 //BA.debugLineNum = 1208;BA.debugLine="If BarWidth0 = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1==__c.False) { 
 //BA.debugLineNum = 1209;BA.debugLine="DrawGrid";
_vvvvvv6();
 //BA.debugLineNum = 1210;BA.debugLine="DrawBars";
_vvvvvv3();
 };
 break; }
case 3: {
 //BA.debugLineNum = 1213;BA.debugLine="DrawPies";
_vvvvvvv2();
 break; }
case 4: {
 //BA.debugLineNum = 1215;BA.debugLine="DrawGrid";
_vvvvvv6();
 //BA.debugLineNum = 1216;BA.debugLine="DrawYXLines";
_vvvvvvv6();
 break; }
}
;
 //BA.debugLineNum = 1222;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvv6() throws Exception{
int _x1 = 0;
int _y = 0;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _rctouter = null;
 //BA.debugLineNum = 1225;BA.debugLine="Private Sub DrawGrid";
 //BA.debugLineNum = 1226;BA.debugLine="Private x1, y As Int";
_x1 = 0;
_y = 0;
 //BA.debugLineNum = 1228;BA.debugLine="Scale(sY).Scale = Graph.Height / (Scale(sY).MaxVa";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height/(double)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal);
 //BA.debugLineNum = 1229;BA.debugLine="xcvsGraph.ClearRect(xcvsGraph.TargetRect)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.ClearRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect());
 //BA.debugLineNum = 1230;BA.debugLine="xcvsGraph.DrawRect(xcvsGraph.TargetRect, Graph.Ch";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect(),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor,__c.True,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1231;BA.debugLine="DrawYScale";
_vvvvvvv5();
 //BA.debugLineNum = 1232;BA.debugLine="DrawXScale";
_vvvvvvv4();
 //BA.debugLineNum = 1234;BA.debugLine="y = 0.3 * Texts.TitleTextHeight";
_y = (int) (0.3*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextHeight);
 //BA.debugLineNum = 1235;BA.debugLine="If Graph.Title <> \"\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Title).equals("") == false) { 
 //BA.debugLineNum = 1236;BA.debugLine="y = y + 0.6 * Texts.TitleTextHeight";
_y = (int) (_y+0.6*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextHeight);
 //BA.debugLineNum = 1237;BA.debugLine="xcvsGraph.DrawText(Graph.Title, Graph.Left + Gra";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Title,(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width/(double)2),(float) (_y),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 };
 //BA.debugLineNum = 1240;BA.debugLine="If Graph.Subtitle <> \"\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Subtitle).equals("") == false) { 
 //BA.debugLineNum = 1241;BA.debugLine="y = y + Texts.SubtitleTextHeight";
_y = (int) (_y+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextHeight);
 //BA.debugLineNum = 1242;BA.debugLine="xcvsGraph.DrawText(Graph.Subtitle, Graph.Left +";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Subtitle,(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width/(double)2),(float) (_y),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 };
 //BA.debugLineNum = 1245;BA.debugLine="y = xcvsGraph.TargetRect.Height - 0.25 * Texts.Ax";
_y = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getHeight()-0.25*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextHeight);
 //BA.debugLineNum = 1246;BA.debugLine="If Legend.IncludeLegend = \"BOTTOM\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend).equals("BOTTOM")) { 
 //BA.debugLineNum = 1247;BA.debugLine="y = y - Legend.Height - 0.5 * Legend.TextHeight";
_y = (int) (_y-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.Height-0.5*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 };
 //BA.debugLineNum = 1250;BA.debugLine="If Graph.XAxisName <> \"\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XAxisName).equals("") == false) { 
 //BA.debugLineNum = 1251;BA.debugLine="xcvsGraph.DrawText(Graph.XAxisName, Graph.Left +";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XAxisName,(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width/(double)2),(float) (_y),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 };
 //BA.debugLineNum = 1254;BA.debugLine="x1 = Texts.AxisTextHeight";
_x1 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextHeight;
 //BA.debugLineNum = 1255;BA.debugLine="If xui.IsB4i Then x1 = 0.8 * Texts.AxisTextHeight";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.getIsB4i()) { 
_x1 = (int) (0.8*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextHeight);};
 //BA.debugLineNum = 1256;BA.debugLine="If Graph.YAxisName <> \"\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.YAxisName).equals("") == false) { 
 //BA.debugLineNum = 1257;BA.debugLine="xcvsGraph.DrawTextRotated(Graph.YAxisName, x1, G";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawTextRotated(ba,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.YAxisName,(float) (_x1),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height/(double)2),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"),(float) (-90));
 };
 //BA.debugLineNum = 1260;BA.debugLine="xcvsGraph.DrawRect(Graph.Rect, Graph.GridFrameCol";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Rect,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,__c.False,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1262;BA.debugLine="If Graph.DrawOuterFrame = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.DrawOuterFrame==__c.True) { 
 //BA.debugLineNum = 1263;BA.debugLine="Private rctOuter As B4XRect";
_rctouter = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 1264;BA.debugLine="rctOuter.Initialize(0, 0, xpnlCursor.Width, xpnl";
_rctouter.Initialize((float) (0),(float) (0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv2.getWidth()),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv2.getHeight()));
 //BA.debugLineNum = 1265;BA.debugLine="xcvsGraph.DrawRect(rctOuter, Graph.GridFrameColo";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_rctouter,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,__c.False,(float) (__c.DipToCurrent((int) (4))));
 };
 //BA.debugLineNum = 1267;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvv7(int _x,int _y) throws Exception{
int _index = 0;
cmarsoft.recu.xchart._pointdata _point = null;
int _h = 0;
int _i = 0;
double _total = 0;
int _top = 0;
int _xcursor = 0;
 //BA.debugLineNum = 440;BA.debugLine="Private Sub DrawItemValues(x As Int, y As Int)";
 //BA.debugLineNum = 441;BA.debugLine="If Graph.ChartType <> \"PIE\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("PIE") == false) { 
 //BA.debugLineNum = 442;BA.debugLine="Private Index As Int";
_index = 0;
 //BA.debugLineNum = 443;BA.debugLine="xcvsValues.ClearRect(Values.rectRight)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.ClearRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.rectRight);
 //BA.debugLineNum = 444;BA.debugLine="xcvsCursor.ClearRect(Values.rectCursor)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ClearRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.rectCursor);
 //BA.debugLineNum = 445;BA.debugLine="xcvsValues.DrawRect(Values.rectRight, 0xAAFFFFFF";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.rectRight,(int) (0xaaffffff),__c.True,(float) (0));
 //BA.debugLineNum = 446;BA.debugLine="Select Graph.ChartType";
switch (BA.switchObjectToInt(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType,"BAR","STACKED_BAR","LINE")) {
case 0: 
case 1: {
 //BA.debugLineNum = 448;BA.debugLine="Index =(x - Graph.Left) / Graph.XInterval";
_index = (int) ((_x-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left)/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval);
 break; }
case 2: {
 //BA.debugLineNum = 450;BA.debugLine="Index = (x - Graph.Left) / Scale(sX).Scale + 0";
_index = (int) ((_x-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left)/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale+0.5);
 break; }
}
;
 //BA.debugLineNum = 452;BA.debugLine="Index = Min(Index, Points.Size - 1)";
_index = (int) (__c.Min(_index,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1));
 //BA.debugLineNum = 453;BA.debugLine="Private Point As PointData";
_point = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 454;BA.debugLine="Point = Points.Get(Index)";
_point = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_index));
 //BA.debugLineNum = 455;BA.debugLine="Private h, i, x, y As Int";
_h = 0;
_i = 0;
_x = 0;
_y = 0;
 //BA.debugLineNum = 456;BA.debugLine="h = Values.TextHeight * 1.2";
_h = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight*1.2);
 //BA.debugLineNum = 457;BA.debugLine="x = Values.MidPont";
_x = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.MidPont;
 //BA.debugLineNum = 458;BA.debugLine="y = 0.8 * Values.TextHeight";
_y = (int) (0.8*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight);
 //BA.debugLineNum = 459;BA.debugLine="xcvsValues.DrawText(Point.X, x, y + 0.2 * h, Val";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,_point.X,(float) (_x),(float) (_y+0.2*_h),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"LEFT"));
 //BA.debugLineNum = 460;BA.debugLine="Private Total = 0 As Double";
_total = 0;
 //BA.debugLineNum = 461;BA.debugLine="Private top As Int";
_top = 0;
 //BA.debugLineNum = 462;BA.debugLine="For i = 0 To Point.YArray.Length - 1";
{
final int step22 = 1;
final int limit22 = (int) (_point.YArray.length-1);
_i = (int) (0) ;
for (;_i <= limit22 ;_i = _i + step22 ) {
 //BA.debugLineNum = 463;BA.debugLine="top = y + h * (i + 1)";
_top = (int) (_y+_h*(_i+1));
 //BA.debugLineNum = 464;BA.debugLine="xcvsValues.DrawText(NumberFormat3(Point.YArray(";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,_vvvvvvvvvvvvvv4(_point.YArray[_i],_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.MaxDigits),(float) (_x),(float) (_top+0.2*_h),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"LEFT"));
 //BA.debugLineNum = 465;BA.debugLine="Total = Total + Point.YArray(i)";
_total = _total+_point.YArray[_i];
 }
};
 //BA.debugLineNum = 467;BA.debugLine="If Graph.ChartType = \"STACKED_BAR\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("STACKED_BAR")) { 
 //BA.debugLineNum = 468;BA.debugLine="top = y + h * (i + 1)";
_top = (int) (_y+_h*(_i+1));
 //BA.debugLineNum = 469;BA.debugLine="xcvsValues.DrawText(NumberFormat3(Total, Values";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,_vvvvvvvvvvvvvv4(_total,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.MaxDigits),(float) (_x),(float) (_top+0.2*_h),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Black,BA.getEnumFromString(android.graphics.Paint.Align.class,"LEFT"));
 };
 //BA.debugLineNum = 472;BA.debugLine="If Graph.ChartType = \"LINE\" And Point.YArray.Len";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("LINE") && _point.YArray.length==1) { 
 //BA.debugLineNum = 473;BA.debugLine="top = top + 0.2 * h";
_top = (int) (_top+0.2*_h);
 //BA.debugLineNum = 474;BA.debugLine="If Graph.IncludeMaxLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMaxLine==__c.True) { 
 //BA.debugLineNum = 475;BA.debugLine="top = top + h";
_top = (int) (_top+_h);
 //BA.debugLineNum = 476;BA.debugLine="xcvsValues.DrawText(NumberFormat3(MinMaxMeanVa";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)],_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.MaxDigits),(float) (_x),(float) (_top),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Black,BA.getEnumFromString(android.graphics.Paint.Align.class,"LEFT"));
 };
 //BA.debugLineNum = 478;BA.debugLine="If Graph.IncludeMeanLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMeanLine==__c.True) { 
 //BA.debugLineNum = 479;BA.debugLine="top = top + h";
_top = (int) (_top+_h);
 //BA.debugLineNum = 480;BA.debugLine="xcvsValues.DrawText(NumberFormat3(MinMaxMeanVa";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (2)],_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.MaxDigits),(float) (_x),(float) (_top),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Black,BA.getEnumFromString(android.graphics.Paint.Align.class,"LEFT"));
 };
 //BA.debugLineNum = 482;BA.debugLine="If Graph.IncludeMinLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMinLine==__c.True) { 
 //BA.debugLineNum = 483;BA.debugLine="top = top + h";
_top = (int) (_top+_h);
 //BA.debugLineNum = 484;BA.debugLine="xcvsValues.DrawText(NumberFormat3(MinMaxMeanVa";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)],_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.MaxDigits),(float) (_x),(float) (_top),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Black,BA.getEnumFromString(android.graphics.Paint.Align.class,"LEFT"));
 };
 };
 //BA.debugLineNum = 488;BA.debugLine="Private xCursor As Int";
_xcursor = 0;
 //BA.debugLineNum = 489;BA.debugLine="Select Graph.ChartType";
switch (BA.switchObjectToInt(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType,"BAR","STACKED_BAR","LINE")) {
case 0: 
case 1: {
 //BA.debugLineNum = 491;BA.debugLine="xCursor = (Index + 0.5) * Graph.XInterval + Gr";
_xcursor = (int) ((_index+0.5)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset);
 break; }
case 2: {
 //BA.debugLineNum = 493;BA.debugLine="xCursor = Index * Scale(sX).Scale + Graph.Left";
_xcursor = (int) (_index*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left);
 break; }
}
;
 //BA.debugLineNum = 495;BA.debugLine="xcvsCursor.DrawLine(xCursor, Graph.Top, xCursor,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.DrawLine((float) (_xcursor),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top),(float) (_xcursor),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom),_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Red,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 496;BA.debugLine="Values.rectCursor.Initialize(xCursor - 2dip, 0,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.rectCursor.Initialize((float) (_xcursor-__c.DipToCurrent((int) (2))),(float) (0),(float) (_xcursor+__c.DipToCurrent((int) (2))),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv2.getHeight()));
 //BA.debugLineNum = 497;BA.debugLine="xcvsValues.Invalidate";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Invalidate();
 //BA.debugLineNum = 498;BA.debugLine="xcvsCursor.Invalidate";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.Invalidate();
 };
 //BA.debugLineNum = 500;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvv0() throws Exception{
int _y = 0;
int _y1 = 0;
int _w = 0;
int _x = 0;
int _h = 0;
int _box = 0;
int _textverticaloffset = 0;
int _i = 0;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _r = null;
cmarsoft.recu.xchart._itemdata _item = null;
String _txt = "";
int _top = 0;
int _y0 = 0;
 //BA.debugLineNum = 2112;BA.debugLine="Private Sub DrawLegend";
 //BA.debugLineNum = 2113;BA.debugLine="Private y As Int = 0.8 * Legend.TextHeight";
_y = (int) (0.8*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 //BA.debugLineNum = 2114;BA.debugLine="Private y1, w, x As Int";
_y1 = 0;
_w = 0;
_x = 0;
 //BA.debugLineNum = 2115;BA.debugLine="Private h As Int = 1.2 * Legend.TextHeight";
_h = (int) (1.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 //BA.debugLineNum = 2116;BA.debugLine="Private box As Int = 0.7 * Legend.TextHeight";
_box = (int) (0.7*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 //BA.debugLineNum = 2117;BA.debugLine="Private textVerticalOffset As Int = 0.25 * Legend";
_textverticaloffset = (int) (0.25*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 //BA.debugLineNum = 2118;BA.debugLine="If xui.IsB4i Then textVerticalOffset = 0.3 * Lege";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.getIsB4i()) { 
_textverticaloffset = (int) (0.3*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);};
 //BA.debugLineNum = 2119;BA.debugLine="Private i As Int";
_i = 0;
 //BA.debugLineNum = 2120;BA.debugLine="Private r As B4XRect";
_r = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 2122;BA.debugLine="Select Legend.IncludeLegend";
switch (BA.switchObjectToInt(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend,"TOP_RIGHT","BOTTOM")) {
case 0: {
 //BA.debugLineNum = 2124;BA.debugLine="h = Texts.AxisTextHeight * 0.8";
_h = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextHeight*0.8);
 //BA.debugLineNum = 2125;BA.debugLine="For Each Item As ItemData In Items";
{
final anywheresoftware.b4a.BA.IterableList group12 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0;
final int groupLen12 = group12.getSize()
;int index12 = 0;
;
for (; index12 < groupLen12;index12++){
_item = (cmarsoft.recu.xchart._itemdata)(group12.Get(index12));
 //BA.debugLineNum = 2126;BA.debugLine="Private txt As String = Item.Name";
_txt = _item.Name;
 //BA.debugLineNum = 2127;BA.debugLine="If Graph.ChartType = \"PIE\" And Graph.IncludeVa";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("PIE") && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeValues) { 
 //BA.debugLineNum = 2128;BA.debugLine="txt = txt & \" : \" & Item.Value";
_txt = _txt+" : "+BA.NumberToString(_item.Value);
 };
 //BA.debugLineNum = 2130;BA.debugLine="w = Max(w, MeasureTextWidth(txt, Legend.TextFo";
_w = (int) (__c.Max(_w,_vvvvvvvvvvvvvv3(_txt,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextFont)));
 }
};
 //BA.debugLineNum = 2132;BA.debugLine="w = w + 2 * box + Texts.AxisTextHeight";
_w = (int) (_w+2*_box+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextHeight);
 //BA.debugLineNum = 2133;BA.debugLine="x = xcvsGraph.TargetRect.Width - w - 0.5 * box";
_x = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth()-_w-0.5*_box);
 //BA.debugLineNum = 2134;BA.debugLine="r.Initialize(x - box, y - 0.5 * box, x + w, y +";
_r.Initialize((float) (_x-_box),(float) (_y-0.5*_box),(float) (_x+_w),(float) (_y+_h*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()+0.5*_box));
 //BA.debugLineNum = 2135;BA.debugLine="If Graph.ChartBackgroundColor = xui.Color_Trans";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor==_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Transparent) { 
 //BA.debugLineNum = 2136;BA.debugLine="xcvsGraph.DrawRect(r, Graph.ChartBackgroundCol";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor,__c.True,(float) (0));
 }else {
 //BA.debugLineNum = 2138;BA.debugLine="xcvsGraph.DrawRect(r, 0x66FFFFFF, True, 0)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,(int) (0x66ffffff),__c.True,(float) (0));
 };
 //BA.debugLineNum = 2140;BA.debugLine="For Each Item As ItemData In Items";
{
final anywheresoftware.b4a.BA.IterableList group27 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0;
final int groupLen27 = group27.getSize()
;int index27 = 0;
;
for (; index27 < groupLen27;index27++){
_item = (cmarsoft.recu.xchart._itemdata)(group27.Get(index27));
 //BA.debugLineNum = 2141;BA.debugLine="Private top As Int = y + h * i";
_top = (int) (_y+_h*_i);
 //BA.debugLineNum = 2142;BA.debugLine="r.Initialize(x, top + 0.5 * h - 0.65 * box, x";
_r.Initialize((float) (_x),(float) (_top+0.5*_h-0.65*_box),(float) (_x+_box),(float) (_top+0.5*_h+0.35*_box));
 //BA.debugLineNum = 2143;BA.debugLine="xcvsGraph.DrawRect(r, Item.Color, True, 0)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_item.Color,__c.True,(float) (0));
 //BA.debugLineNum = 2144;BA.debugLine="Private txt As String = Item.Name";
_txt = _item.Name;
 //BA.debugLineNum = 2145;BA.debugLine="If Graph.ChartType = \"PIE\" And Graph.IncludeVa";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("PIE") && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeValues) { 
 //BA.debugLineNum = 2146;BA.debugLine="txt = txt & \" : \" & Item.Value";
_txt = _txt+" : "+BA.NumberToString(_item.Value);
 };
 //BA.debugLineNum = 2148;BA.debugLine="xcvsGraph.DrawText(txt, x + box + box, top + 0";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_txt,(float) (_x+_box+_box),(float) (_top+0.5*_h+_textverticaloffset),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Black,BA.getEnumFromString(android.graphics.Paint.Align.class,"LEFT"));
 //BA.debugLineNum = 2149;BA.debugLine="i = i + 1";
_i = (int) (_i+1);
 }
};
 break; }
case 1: {
 //BA.debugLineNum = 2153;BA.debugLine="Private x, y0, y As Int";
_x = 0;
_y0 = 0;
_y = 0;
 //BA.debugLineNum = 2154;BA.debugLine="Private i As Int";
_i = 0;
 //BA.debugLineNum = 2155;BA.debugLine="Private r As B4XRect";
_r = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 2157;BA.debugLine="y0  = xcvsGraph.TargetRect.Height - Legend.Heig";
_y0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getHeight()-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.Height+0.6*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 //BA.debugLineNum = 2158;BA.debugLine="x = box";
_x = _box;
 //BA.debugLineNum = 2160;BA.debugLine="r.Initialize(0.5 * box, xcvsGraph.TargetRect.He";
_r.Initialize((float) (0.5*_box),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getHeight()-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.Height-0.5*_box),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth()-0.5*_box),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getHeight()-0.5*_box));
 //BA.debugLineNum = 2161;BA.debugLine="If Graph.ChartBackgroundColor = xui.Color_Trans";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor==_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Transparent) { 
 //BA.debugLineNum = 2162;BA.debugLine="xcvsGraph.DrawRect(r, Graph.ChartBackgroundCol";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor,__c.True,(float) (0));
 }else {
 //BA.debugLineNum = 2164;BA.debugLine="xcvsGraph.DrawRect(r, 0x66FFFFFF, True, 0)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,(int) (0x66ffffff),__c.True,(float) (0));
 };
 //BA.debugLineNum = 2167;BA.debugLine="For i = 0 To Items.Size - 1";
{
final int step50 = 1;
final int limit50 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit50 ;_i = _i + step50 ) {
 //BA.debugLineNum = 2168;BA.debugLine="Private Item As ItemData";
_item = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 2169;BA.debugLine="Item = Items.Get(i)";
_item = (cmarsoft.recu.xchart._itemdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Get(_i));
 //BA.debugLineNum = 2170;BA.debugLine="y = y0 + 1.6 * box * Legend.LineNumbers.Get(i)";
_y = (int) (_y0+1.6*_box*(double)(BA.ObjectToNumber(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumbers.Get(_i))));
 //BA.debugLineNum = 2171;BA.debugLine="Private txt As String = Item.Name";
_txt = _item.Name;
 //BA.debugLineNum = 2172;BA.debugLine="If Graph.ChartType = \"PIE\" And Graph.IncludeVa";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("PIE") && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeValues) { 
 //BA.debugLineNum = 2173;BA.debugLine="txt = txt & \" : \" & Item.Value";
_txt = _txt+" : "+BA.NumberToString(_item.Value);
 };
 //BA.debugLineNum = 2175;BA.debugLine="If Legend.LineChange.Get(i) = True Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineChange.Get(_i)).equals((Object)(__c.True))) { 
 //BA.debugLineNum = 2176;BA.debugLine="x = box";
_x = _box;
 };
 //BA.debugLineNum = 2179;BA.debugLine="r.Initialize(x, y - box, x + box, y)";
_r.Initialize((float) (_x),(float) (_y-_box),(float) (_x+_box),(float) (_y));
 //BA.debugLineNum = 2180;BA.debugLine="xcvsGraph.DrawRect(r, Item.Color, True, 0)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_item.Color,__c.True,(float) (0));
 //BA.debugLineNum = 2181;BA.debugLine="Private txt As String = Item.Name";
_txt = _item.Name;
 //BA.debugLineNum = 2182;BA.debugLine="If Graph.ChartType = \"PIE\" And Graph.IncludeVa";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("PIE") && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeValues) { 
 //BA.debugLineNum = 2183;BA.debugLine="txt = txt & \" : \" & Item.Value";
_txt = _txt+" : "+BA.NumberToString(_item.Value);
 };
 //BA.debugLineNum = 2187;BA.debugLine="y1 = y '+ 0.1 * box";
_y1 = _y;
 //BA.debugLineNum = 2193;BA.debugLine="xcvsGraph.DrawText(txt, x + 1.5 * box, y1, Leg";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_txt,(float) (_x+1.5*_box),(float) (_y1),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Black,BA.getEnumFromString(android.graphics.Paint.Align.class,"LEFT"));
 //BA.debugLineNum = 2194;BA.debugLine="x = x + 2.5 * box + MeasureTextWidth(txt, Lege";
_x = (int) (_x+2.5*_box+_vvvvvvvvvvvvvv3(_txt,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextFont));
 }
};
 break; }
}
;
 //BA.debugLineNum = 2197;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvvv1() throws Exception{
int _i = 0;
int _x0 = 0;
int _x1 = 0;
cmarsoft.recu.xchart._pointdata _pd = null;
int[] _cols = null;
int[] _pointcols = null;
int[] _strokewidths = null;
String[] _names = null;
String[] _pointtypes = null;
boolean[] _filled = null;
double _smax = 0;
double _smin = 0;
double _smean = 0;
double[] _py0 = null;
double[] _py1 = null;
double[] _psy0 = null;
double[] _psy1 = null;
cmarsoft.recu.xchart._itemdata _id = null;
int _j = 0;
int _myaxis0 = 0;
 //BA.debugLineNum = 1380;BA.debugLine="Private Sub DrawLines";
 //BA.debugLineNum = 1381;BA.debugLine="Private i As Int";
_i = 0;
 //BA.debugLineNum = 1382;BA.debugLine="Private x0, x1 As Int";
_x0 = 0;
_x1 = 0;
 //BA.debugLineNum = 1384;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1385;BA.debugLine="Private Cols(Items.Size), PointCols(Items.Size),";
_cols = new int[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()];
;
_pointcols = new int[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()];
;
_strokewidths = new int[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()];
;
 //BA.debugLineNum = 1386;BA.debugLine="Private Names(Items.Size), PointTypes(Items.Size)";
_names = new String[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()];
java.util.Arrays.fill(_names,"");
_pointtypes = new String[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()];
java.util.Arrays.fill(_pointtypes,"");
 //BA.debugLineNum = 1387;BA.debugLine="Private Filled(Items.Size) As Boolean";
_filled = new boolean[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()];
;
 //BA.debugLineNum = 1389;BA.debugLine="If Items.Size = 1 And (MinMaxMeanValues(0) <> 0 O";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()==1 && (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)]!=0 || _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)]!=0)) { 
 //BA.debugLineNum = 1390;BA.debugLine="Private sMax, sMin, sMean As Double";
_smax = 0;
_smin = 0;
_smean = 0;
 //BA.debugLineNum = 1391;BA.debugLine="If Graph.IncludeMinLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMinLine==__c.True) { 
 //BA.debugLineNum = 1392;BA.debugLine="sMin = Graph.Bottom - (MinMaxMeanValues(0) - Sc";
_smin = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale;
 //BA.debugLineNum = 1393;BA.debugLine="xcvsGraph.DrawLine(Graph.Left, sMin, Graph.Righ";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_smin),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_smin),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MinLineColor,(float) (__c.DipToCurrent((int) (2))));
 };
 //BA.debugLineNum = 1395;BA.debugLine="If Graph.IncludeMaxLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMaxLine==__c.True) { 
 //BA.debugLineNum = 1396;BA.debugLine="sMax = Graph.Bottom - (MinMaxMeanValues(1) - Sc";
_smax = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale;
 //BA.debugLineNum = 1397;BA.debugLine="xcvsGraph.DrawLine(Graph.Left, sMax, Graph.Righ";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_smax),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_smax),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MaxLineColor,(float) (__c.DipToCurrent((int) (2))));
 };
 //BA.debugLineNum = 1399;BA.debugLine="If Graph.IncludeMeanLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMeanLine==__c.True) { 
 //BA.debugLineNum = 1400;BA.debugLine="sMean = Graph.Bottom - (MinMaxMeanValues(2) - S";
_smean = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (2)]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale;
 //BA.debugLineNum = 1401;BA.debugLine="xcvsGraph.DrawLine(Graph.Left, sMean, Graph.Rig";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_smean),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_smean),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MeanLineColor,(float) (__c.DipToCurrent((int) (2))));
 };
 };
 //BA.debugLineNum = 1405;BA.debugLine="PD = Points.Get(0)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get((int) (0)));
 //BA.debugLineNum = 1406;BA.debugLine="x0 = Graph.Left";
_x0 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left;
 //BA.debugLineNum = 1407;BA.debugLine="Private py0(PD.YArray.Length), py1(PD.YArray.Leng";
_py0 = new double[_pd.YArray.length];
;
_py1 = new double[_pd.YArray.length];
;
 //BA.debugLineNum = 1408;BA.debugLine="Private psy0(PD.YArray.Length), psy1(PD.YArray.Le";
_psy0 = new double[_pd.YArray.length];
;
_psy1 = new double[_pd.YArray.length];
;
 //BA.debugLineNum = 1409;BA.debugLine="py0 = PD.YArray";
_py0 = _pd.YArray;
 //BA.debugLineNum = 1410;BA.debugLine="For i = 0 To py0.Length - 1";
{
final int step27 = 1;
final int limit27 = (int) (_py0.length-1);
_i = (int) (0) ;
for (;_i <= limit27 ;_i = _i + step27 ) {
 //BA.debugLineNum = 1411;BA.debugLine="Private ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 1412;BA.debugLine="ID = Items.Get(i)";
_id = (cmarsoft.recu.xchart._itemdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Get(_i));
 //BA.debugLineNum = 1413;BA.debugLine="Cols(i) = ID.Color";
_cols[_i] = _id.Color;
 //BA.debugLineNum = 1414;BA.debugLine="PointCols(i) = ID.PointColor";
_pointcols[_i] = _id.PointColor;
 //BA.debugLineNum = 1415;BA.debugLine="Names(i) = ID.Name";
_names[_i] = _id.Name;
 //BA.debugLineNum = 1416;BA.debugLine="StrokeWidths(i) = ID.StrokeWidth";
_strokewidths[_i] = _id.StrokeWidth;
 //BA.debugLineNum = 1417;BA.debugLine="PointTypes(i) = ID.PointType";
_pointtypes[_i] = _id.PointType;
 //BA.debugLineNum = 1418;BA.debugLine="Filled(i) = ID.Filled";
_filled[_i] = _id.Filled;
 //BA.debugLineNum = 1419;BA.debugLine="psy0(i) = Graph.Bottom - (py0(i) - Scale(sY).Min";
_psy0[_i] = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-(_py0[_i]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale;
 }
};
 //BA.debugLineNum = 1422;BA.debugLine="xcvsGraph.ClipPath(pthGrid)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.ClipPath(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv4);
 //BA.debugLineNum = 1423;BA.debugLine="For i = 1 To Points.Size - 1";
{
final int step39 = 1;
final int limit39 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (1) ;
for (;_i <= limit39 ;_i = _i + step39 ) {
 //BA.debugLineNum = 1424;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1425;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1426;BA.debugLine="py1 = PD.YArray";
_py1 = _pd.YArray;
 //BA.debugLineNum = 1427;BA.debugLine="x1 = Graph.Left + i * Scale(sX).Scale";
_x1 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_i*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale);
 //BA.debugLineNum = 1428;BA.debugLine="For j = 0 To py1.Length - 1";
{
final int step44 = 1;
final int limit44 = (int) (_py1.length-1);
_j = (int) (0) ;
for (;_j <= limit44 ;_j = _j + step44 ) {
 //BA.debugLineNum = 1429;BA.debugLine="psy1(j) = Graph.Bottom - (py1(j) - Scale(sY).Mi";
_psy1[_j] = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-(_py1[_j]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale;
 //BA.debugLineNum = 1430;BA.debugLine="xcvsGraph.DrawLine(x0, psy0(j), x1, psy1(j), Co";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x0),(float) (_psy0[_j]),(float) (_x1),(float) (_psy1[_j]),_cols[_j],(float) (_strokewidths[_j]));
 //BA.debugLineNum = 1431;BA.debugLine="psy0(j) = psy1(j)";
_psy0[_j] = _psy1[_j];
 }
};
 //BA.debugLineNum = 1433;BA.debugLine="x0 = x1";
_x0 = _x1;
 }
};
 //BA.debugLineNum = 1435;BA.debugLine="xcvsGraph.RemoveClip";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.RemoveClip();
 //BA.debugLineNum = 1437;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step52 = 1;
final int limit52 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit52 ;_i = _i + step52 ) {
 //BA.debugLineNum = 1438;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1439;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1440;BA.debugLine="py1 = PD.YArray";
_py1 = _pd.YArray;
 //BA.debugLineNum = 1441;BA.debugLine="x1 = Graph.Left + i * Scale(sX).Scale";
_x1 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_i*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale);
 //BA.debugLineNum = 1442;BA.debugLine="For j = 0 To py1.Length - 1";
{
final int step57 = 1;
final int limit57 = (int) (_py1.length-1);
_j = (int) (0) ;
for (;_j <= limit57 ;_j = _j + step57 ) {
 //BA.debugLineNum = 1443;BA.debugLine="psy1(j) = Graph.Bottom - (py1(j) - Scale(sY).Mi";
_psy1[_j] = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-(_py1[_j]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale;
 //BA.debugLineNum = 1444;BA.debugLine="If PointTypes(j) <> \"NONE\" Then";
if ((_pointtypes[_j]).equals("NONE") == false) { 
 //BA.debugLineNum = 1445;BA.debugLine="DrawPoint(x1, psy1(j), PointCols(j), PointType";
_vvvvvvv3(_x1,(int) (_psy1[_j]),_pointcols[_j],_pointtypes[_j],_filled[_j],_strokewidths[_j]);
 };
 }
};
 }
};
 //BA.debugLineNum = 1451;BA.debugLine="If Scale(sY).MinVal< 0 And Scale(sY).MaxVal > 0 T";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal<0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal>0) { 
 //BA.debugLineNum = 1452;BA.debugLine="Private mYAxis0 = Graph.Bottom + Scale(sY).MinVa";
_myaxis0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1453;BA.debugLine="xcvsGraph.DrawLine(Graph.Left, mYAxis0, Graph.Ri";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_myaxis0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_myaxis0),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,(float) (__c.DipToCurrent((int) (2))));
 };
 //BA.debugLineNum = 1456;BA.debugLine="If Legend.IncludeLegend <> \"NONE\" And Points.Size";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend).equals("NONE") == false && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()>0) { 
 //BA.debugLineNum = 1457;BA.debugLine="DrawLegend";
_vvvvvv0();
 };
 //BA.debugLineNum = 1460;BA.debugLine="xcvsGraph.Invalidate";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.Invalidate();
 //BA.debugLineNum = 1461;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvvv2() throws Exception{
float _total = 0f;
cmarsoft.recu.xchart._itemdata _item = null;
int _centerx = 0;
int _centery = 0;
int _titleheight = 0;
float _radius = 0f;
float _radiustext = 0f;
float _startangle = 0f;
float _totalangle = 0f;
float _midangle = 0f;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _rectcircle = null;
int _percentage = 0;
anywheresoftware.b4a.objects.B4XCanvas.B4XPath _mpath = null;
float _angle = 0f;
b4a.example.bitmapcreator._argbcolor _argb = null;
b4a.example.bitmapcreator _bmpcreate = null;
int _acol = 0;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _rb = null;
b4a.example.bitmapcreator _bc1 = null;
int _x = 0;
int _y = 0;
String _txt = "";
 //BA.debugLineNum = 1960;BA.debugLine="Private Sub DrawPies";
 //BA.debugLineNum = 1961;BA.debugLine="xcvsGraph.DrawRect(xcvsGraph.TargetRect, Graph.Ch";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect(),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor,__c.True,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1963;BA.debugLine="Dim Total As Float";
_total = 0f;
 //BA.debugLineNum = 1964;BA.debugLine="For Each Item As ItemData In Items";
{
final anywheresoftware.b4a.BA.IterableList group3 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0;
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_item = (cmarsoft.recu.xchart._itemdata)(group3.Get(index3));
 //BA.debugLineNum = 1965;BA.debugLine="Total = Total + Item.Value";
_total = (float) (_total+_item.Value);
 }
};
 //BA.debugLineNum = 1968;BA.debugLine="Private CenterX, CenterY, TitleHeight As Int";
_centerx = 0;
_centery = 0;
_titleheight = 0;
 //BA.debugLineNum = 1970;BA.debugLine="If Graph.Title <> \"\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Title).equals("") == false) { 
 //BA.debugLineNum = 1971;BA.debugLine="TitleHeight = 1.2 * Texts.TitleTextHeight";
_titleheight = (int) (1.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextHeight);
 };
 //BA.debugLineNum = 1973;BA.debugLine="Private Radius As Float = Min(xcvsGraph.TargetRec";
_radius = (float) (__c.Min(_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth(),(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height-_titleheight))/(double)2-__c.DipToCurrent((int) (10)));
 //BA.debugLineNum = 1975;BA.debugLine="If Legend.IncludeLegend <> \"NONE\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend).equals("NONE") == false) { 
 //BA.debugLineNum = 1976;BA.debugLine="If xcvsGraph.TargetRect.Width > xcvsGraph.Target";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth()>_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getHeight()) { 
 //BA.debugLineNum = 1977;BA.debugLine="CenterX = Radius + 10dip";
_centerx = (int) (_radius+__c.DipToCurrent((int) (10)));
 }else {
 //BA.debugLineNum = 1979;BA.debugLine="CenterX = xcvsGraph.TargetRect.Width / 2";
_centerx = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth()/(double)2);
 };
 }else {
 //BA.debugLineNum = 1982;BA.debugLine="CenterX = xcvsGraph.TargetRect.Width / 2";
_centerx = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth()/(double)2);
 };
 //BA.debugLineNum = 1985;BA.debugLine="CenterY = Graph.Height - Radius - 10dip";
_centery = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height-_radius-__c.DipToCurrent((int) (10)));
 //BA.debugLineNum = 1987;BA.debugLine="If Graph.Title <> \"\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Title).equals("") == false) { 
 //BA.debugLineNum = 1988;BA.debugLine="xcvsGraph.DrawText(Graph.Title, xcvsGraph.Target";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Title,(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth()/(double)2),(float) (0.8*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextHeight),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Black,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 };
 //BA.debugLineNum = 1991;BA.debugLine="Private RadiusText As Float = Radius * 0.7";
_radiustext = (float) (_radius*0.7);
 //BA.debugLineNum = 1992;BA.debugLine="Private StartAngle, TotalAngle, MidAngle As Float";
_startangle = 0f;
_totalangle = 0f;
_midangle = 0f;
 //BA.debugLineNum = 1993;BA.debugLine="TotalAngle = 360 - Graph.PieGapDegrees * Items.Si";
_totalangle = (float) (360-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.PieGapDegrees*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize());
 //BA.debugLineNum = 1994;BA.debugLine="Private rectCircle As B4XRect";
_rectcircle = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 1995;BA.debugLine="rectCircle.Initialize(CenterX - Radius, CenterY -";
_rectcircle.Initialize((float) (_centerx-_radius),(float) (_centery-_radius),(float) (_centerx+_radius),(float) (_centery+_radius));
 //BA.debugLineNum = 1996;BA.debugLine="Private Percentage As Int";
_percentage = 0;
 //BA.debugLineNum = 1997;BA.debugLine="Private Percentage As Int";
_percentage = 0;
 //BA.debugLineNum = 1998;BA.debugLine="For Each Item As ItemData In Items";
{
final anywheresoftware.b4a.BA.IterableList group31 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0;
final int groupLen31 = group31.getSize()
;int index31 = 0;
;
for (; index31 < groupLen31;index31++){
_item = (cmarsoft.recu.xchart._itemdata)(group31.Get(index31));
 //BA.debugLineNum = 1999;BA.debugLine="Private mPath As B4XPath";
_mpath = new anywheresoftware.b4a.objects.B4XCanvas.B4XPath();
 //BA.debugLineNum = 2000;BA.debugLine="Private Angle As Float = Item.Value / Total * To";
_angle = (float) (_item.Value/(double)_total*_totalangle);
 //BA.debugLineNum = 2001;BA.debugLine="If Angle = TotalAngle Then";
if (_angle==_totalangle) { 
 //BA.debugLineNum = 2002;BA.debugLine="If Graph.GradientColors = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColors==__c.False) { 
 //BA.debugLineNum = 2003;BA.debugLine="xcvsGraph.DrawCircle(CenterX, CenterY, Radius,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawCircle((float) (_centerx),(float) (_centery),_radius,_item.Color,__c.True,(float) (0));
 }else {
 };
 }else {
 //BA.debugLineNum = 2007;BA.debugLine="Private ARGB As ARGBColor";
_argb = new b4a.example.bitmapcreator._argbcolor();
 //BA.debugLineNum = 2008;BA.debugLine="Private BmpCreate As BitmapCreator";
_bmpcreate = new b4a.example.bitmapcreator();
 //BA.debugLineNum = 2009;BA.debugLine="Private Acol As Int";
_acol = 0;
 //BA.debugLineNum = 2010;BA.debugLine="BmpCreate.Initialize(10, 10)";
_bmpcreate._initialize(ba,(int) (10),(int) (10));
 //BA.debugLineNum = 2011;BA.debugLine="BmpCreate.ColorToARGB(Item.Color, ARGB)";
_bmpcreate._colortoargb(_item.Color,_argb);
 //BA.debugLineNum = 2012;BA.debugLine="Acol = xui.Color_ARGB(Graph.GradientColorsAlpha";
_acol = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_ARGB(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColorsAlpha,_argb.r,_argb.g,_argb.b);
 //BA.debugLineNum = 2014;BA.debugLine="mPath.InitializeArc(CenterX, CenterY, Radius, S";
_mpath.InitializeArc((float) (_centerx),(float) (_centery),_radius,_startangle,_angle);
 //BA.debugLineNum = 2015;BA.debugLine="StartAngle = StartAngle + Angle + Graph.PieGapD";
_startangle = (float) (_startangle+_angle+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.PieGapDegrees);
 //BA.debugLineNum = 2016;BA.debugLine="xcvsGraph.ClipPath(mPath)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.ClipPath(_mpath);
 //BA.debugLineNum = 2017;BA.debugLine="If Graph.GradientColors = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColors==__c.False) { 
 //BA.debugLineNum = 2018;BA.debugLine="xcvsGraph.DrawCircle(CenterX, CenterY, Radius,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawCircle((float) (_centerx),(float) (_centery),_radius,_item.Color,__c.True,(float) (0));
 }else {
 //BA.debugLineNum = 2020;BA.debugLine="Private rb As B4XRect";
_rb = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 2021;BA.debugLine="rb.Initialize(0, 0, 2 * Radius, 2 * Radius)";
_rb.Initialize((float) (0),(float) (0),(float) (2*_radius),(float) (2*_radius));
 //BA.debugLineNum = 2022;BA.debugLine="Private bc1 As BitmapCreator";
_bc1 = new b4a.example.bitmapcreator();
 //BA.debugLineNum = 2023;BA.debugLine="bc1.Initialize(2 * Radius, 2 * Radius)";
_bc1._initialize(ba,(int) (2*_radius),(int) (2*_radius));
 //BA.debugLineNum = 2024;BA.debugLine="bc1.FillRadialGradient(Array As Int(Acol, Item";
_bc1._fillradialgradient(new int[]{_acol,_item.Color},_rb);
 //BA.debugLineNum = 2025;BA.debugLine="xcvsGraph.DrawBitmap(bc1.Bitmap, rectCircle)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawBitmap((android.graphics.Bitmap)(_bc1._getbitmap().getObject()),_rectcircle);
 };
 //BA.debugLineNum = 2027;BA.debugLine="xcvsGraph.RemoveClip";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.RemoveClip();
 };
 }
};
 //BA.debugLineNum = 2031;BA.debugLine="If Graph.PieAddPerentage Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.PieAddPerentage) { 
 //BA.debugLineNum = 2032;BA.debugLine="For Each Item As ItemData In Items";
{
final anywheresoftware.b4a.BA.IterableList group63 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0;
final int groupLen63 = group63.getSize()
;int index63 = 0;
;
for (; index63 < groupLen63;index63++){
_item = (cmarsoft.recu.xchart._itemdata)(group63.Get(index63));
 //BA.debugLineNum = 2033;BA.debugLine="Private mPath As B4XPath";
_mpath = new anywheresoftware.b4a.objects.B4XCanvas.B4XPath();
 //BA.debugLineNum = 2034;BA.debugLine="Private Angle As Float = Item.Value / Total * T";
_angle = (float) (_item.Value/(double)_total*_totalangle);
 //BA.debugLineNum = 2035;BA.debugLine="If Angle = TotalAngle Then";
if (_angle==_totalangle) { 
 //BA.debugLineNum = 2036;BA.debugLine="xcvsGraph.DrawCircle(CenterX, CenterY, Radius,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawCircle((float) (_centerx),(float) (_centery),_radius,_item.Color,__c.True,(float) (0));
 }else {
 //BA.debugLineNum = 2038;BA.debugLine="StartAngle = StartAngle + Angle + Graph.PieGap";
_startangle = (float) (_startangle+_angle+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.PieGapDegrees);
 //BA.debugLineNum = 2039;BA.debugLine="Private x, y As Int";
_x = 0;
_y = 0;
 //BA.debugLineNum = 2040;BA.debugLine="Private txt As String";
_txt = "";
 //BA.debugLineNum = 2041;BA.debugLine="MidAngle = StartAngle - Angle /2 - Graph.PieGa";
_midangle = (float) (_startangle-_angle/(double)2-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.PieGapDegrees);
 //BA.debugLineNum = 2042;BA.debugLine="x = CenterX + RadiusText * CosD(MidAngle)";
_x = (int) (_centerx+_radiustext*__c.CosD(_midangle));
 //BA.debugLineNum = 2043;BA.debugLine="y = CenterY + RadiusText * SinD(MidAngle) + 5d";
_y = (int) (_centery+_radiustext*__c.SinD(_midangle)+__c.DipToCurrent((int) (5)));
 //BA.debugLineNum = 2044;BA.debugLine="Percentage = Item.Value / Total * 100";
_percentage = (int) (_item.Value/(double)_total*100);
 //BA.debugLineNum = 2045;BA.debugLine="txt = Percentage & \" %\"";
_txt = BA.NumberToString(_percentage)+" %";
 //BA.debugLineNum = 2046;BA.debugLine="xcvsGraph.DrawText(txt, x, y, Texts.AxisFont,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_txt,(float) (_x),(float) (_y),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisFont,_vvvvvvvv5(_item.Color),BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 };
 }
};
 };
 //BA.debugLineNum = 2051;BA.debugLine="If Legend.IncludeLegend <> \"NONE\" And Items.Size";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend).equals("NONE") == false && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()>0) { 
 //BA.debugLineNum = 2052;BA.debugLine="DrawLegend";
_vvvvvv0();
 };
 //BA.debugLineNum = 2055;BA.debugLine="xcvsGraph.Invalidate";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.Invalidate();
 //BA.debugLineNum = 2056;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvvv3(int _x,int _y,int _color,String _pointtype,boolean _filled,int _strokewidth) throws Exception{
int _dx = 0;
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _r = null;
anywheresoftware.b4a.objects.B4XCanvas.B4XPath _tripath = null;
 //BA.debugLineNum = 1464;BA.debugLine="Private Sub DrawPoint(X As Int, Y As Int, Color As";
 //BA.debugLineNum = 1465;BA.debugLine="Private dx As Int";
_dx = 0;
 //BA.debugLineNum = 1467;BA.debugLine="If x < Graph.Left Or x > Graph.Right Or Y < Graph";
if (_x<_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left || _x>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right || _y<_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top || _y>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom) { 
 //BA.debugLineNum = 1468;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 1471;BA.debugLine="dx = Max(4dip, 1.4 * StrokeWidth)";
_dx = (int) (__c.Max(__c.DipToCurrent((int) (4)),1.4*_strokewidth));
 //BA.debugLineNum = 1472;BA.debugLine="Select PointType";
switch (BA.switchObjectToInt(_pointtype,"CIRCLE","SQUARE","TRIANGLE","RHOMBUS","CROSS+","CROSSX","CROSSx")) {
case 0: {
 //BA.debugLineNum = 1474;BA.debugLine="If Filled = False Then";
if (_filled==__c.False) { 
 //BA.debugLineNum = 1475;BA.debugLine="xcvsGraph.DrawCircle(X, Y, dx, Graph.ChartBack";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawCircle((float) (_x),(float) (_y),(float) (_dx),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor,__c.True,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1476;BA.debugLine="xcvsGraph.DrawCircle(X, Y, dx, Color, Filled,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawCircle((float) (_x),(float) (_y),(float) (_dx),_color,_filled,(float) (__c.DipToCurrent((int) (2))));
 }else {
 //BA.debugLineNum = 1478;BA.debugLine="xcvsGraph.DrawCircle(X, Y, dx, Color, True, 2d";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawCircle((float) (_x),(float) (_y),(float) (_dx),_color,__c.True,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1479;BA.debugLine="xcvsGraph.DrawCircle(X, Y, dx, Color, False, 2";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawCircle((float) (_x),(float) (_y),(float) (_dx),_color,__c.False,(float) (__c.DipToCurrent((int) (2))));
 };
 break; }
case 1: {
 //BA.debugLineNum = 1482;BA.debugLine="Private r As B4XRect";
_r = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 1483;BA.debugLine="r.Initialize(X - dx, Y - dx, X + dx, Y + dx)";
_r.Initialize((float) (_x-_dx),(float) (_y-_dx),(float) (_x+_dx),(float) (_y+_dx));
 //BA.debugLineNum = 1484;BA.debugLine="If Filled = False Then";
if (_filled==__c.False) { 
 //BA.debugLineNum = 1485;BA.debugLine="xcvsGraph.DrawRect(r, Graph.ChartBackgroundCol";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor,__c.True,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1486;BA.debugLine="xcvsGraph.DrawRect(r, Color, Filled, 2dip)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_color,_filled,(float) (__c.DipToCurrent((int) (2))));
 }else {
 //BA.debugLineNum = 1488;BA.debugLine="xcvsGraph.DrawRect(r, Color, True, 2dip)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_color,__c.True,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1489;BA.debugLine="xcvsGraph.DrawRect(r, Color, False, 2dip)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_color,__c.False,(float) (__c.DipToCurrent((int) (2))));
 };
 break; }
case 2: {
 //BA.debugLineNum = 1492;BA.debugLine="Private triPath As B4XPath";
_tripath = new anywheresoftware.b4a.objects.B4XCanvas.B4XPath();
 //BA.debugLineNum = 1493;BA.debugLine="triPath.Initialize(X - dx, Y + 0.8 * dx)";
_tripath.Initialize((float) (_x-_dx),(float) (_y+0.8*_dx));
 //BA.debugLineNum = 1494;BA.debugLine="triPath.LineTo(X, Y - 1.2 * dx)";
_tripath.LineTo((float) (_x),(float) (_y-1.2*_dx));
 //BA.debugLineNum = 1495;BA.debugLine="triPath.LineTo(X + dx, Y + 0.8 * dx)";
_tripath.LineTo((float) (_x+_dx),(float) (_y+0.8*_dx));
 //BA.debugLineNum = 1496;BA.debugLine="triPath.LineTo(X - dx, Y + 0.8 * dx)";
_tripath.LineTo((float) (_x-_dx),(float) (_y+0.8*_dx));
 //BA.debugLineNum = 1497;BA.debugLine="xcvsGraph.ClipPath(triPath)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.ClipPath(_tripath);
 //BA.debugLineNum = 1498;BA.debugLine="Private r As B4XRect";
_r = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 1499;BA.debugLine="r.Initialize(X - dx, Y - dx, X + dx, Y + dx)";
_r.Initialize((float) (_x-_dx),(float) (_y-_dx),(float) (_x+_dx),(float) (_y+_dx));
 //BA.debugLineNum = 1501;BA.debugLine="If Filled = False Then";
if (_filled==__c.False) { 
 //BA.debugLineNum = 1502;BA.debugLine="xcvsGraph.DrawRect(r, Graph.ChartBackgroundCol";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor,__c.True,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1503;BA.debugLine="xcvsGraph.RemoveClip";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.RemoveClip();
 //BA.debugLineNum = 1504;BA.debugLine="xcvsGraph.DrawLine(X - dx, Y + dx, X, Y - dx,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x-_dx),(float) (_y+_dx),(float) (_x),(float) (_y-_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1505;BA.debugLine="xcvsGraph.DrawLine(X, Y - dx, X + dx, Y + dx,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_y-_dx),(float) (_x+_dx),(float) (_y+_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1506;BA.debugLine="xcvsGraph.DrawLine(X - dx, Y + dx, X + dx, Y +";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x-_dx),(float) (_y+_dx),(float) (_x+_dx),(float) (_y+_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 }else {
 //BA.debugLineNum = 1508;BA.debugLine="xcvsGraph.DrawRect(r, Color, True, 1dip)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_color,__c.True,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1509;BA.debugLine="xcvsGraph.RemoveClip";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.RemoveClip();
 //BA.debugLineNum = 1510;BA.debugLine="xcvsGraph.DrawLine(X - dx, Y + dx, X, Y - dx,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x-_dx),(float) (_y+_dx),(float) (_x),(float) (_y-_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1511;BA.debugLine="xcvsGraph.DrawLine(X, Y - dx, X + dx, Y + dx,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_y-_dx),(float) (_x+_dx),(float) (_y+_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1512;BA.debugLine="xcvsGraph.DrawLine(X - dx, Y + dx, X + dx, Y +";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x-_dx),(float) (_y+_dx),(float) (_x+_dx),(float) (_y+_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 };
 break; }
case 3: {
 //BA.debugLineNum = 1515;BA.debugLine="Private triPath As B4XPath";
_tripath = new anywheresoftware.b4a.objects.B4XCanvas.B4XPath();
 //BA.debugLineNum = 1516;BA.debugLine="triPath.Initialize(X - dx, Y)";
_tripath.Initialize((float) (_x-_dx),(float) (_y));
 //BA.debugLineNum = 1517;BA.debugLine="triPath.LineTo(X, Y -  dx)";
_tripath.LineTo((float) (_x),(float) (_y-_dx));
 //BA.debugLineNum = 1518;BA.debugLine="triPath.LineTo(X + dx, Y)";
_tripath.LineTo((float) (_x+_dx),(float) (_y));
 //BA.debugLineNum = 1519;BA.debugLine="triPath.LineTo(X, Y + dx)";
_tripath.LineTo((float) (_x),(float) (_y+_dx));
 //BA.debugLineNum = 1520;BA.debugLine="triPath.LineTo(X - dx, Y)";
_tripath.LineTo((float) (_x-_dx),(float) (_y));
 //BA.debugLineNum = 1521;BA.debugLine="xcvsGraph.ClipPath(triPath)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.ClipPath(_tripath);
 //BA.debugLineNum = 1522;BA.debugLine="Private r As B4XRect";
_r = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 1523;BA.debugLine="r.Initialize(X - dx, Y - dx, X + dx, Y + dx)";
_r.Initialize((float) (_x-_dx),(float) (_y-_dx),(float) (_x+_dx),(float) (_y+_dx));
 //BA.debugLineNum = 1525;BA.debugLine="If Filled = False Then";
if (_filled==__c.False) { 
 //BA.debugLineNum = 1526;BA.debugLine="xcvsGraph.DrawRect(r, Graph.ChartBackgroundCol";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor,__c.True,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1527;BA.debugLine="xcvsGraph.RemoveClip";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.RemoveClip();
 //BA.debugLineNum = 1528;BA.debugLine="xcvsGraph.DrawLine(X - dx, Y, X, Y - dx, Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x-_dx),(float) (_y),(float) (_x),(float) (_y-_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1529;BA.debugLine="xcvsGraph.DrawLine(X, Y - dx, X + dx, Y, Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_y-_dx),(float) (_x+_dx),(float) (_y),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1530;BA.debugLine="xcvsGraph.DrawLine(X + dx, Y, X, Y + dx, Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x+_dx),(float) (_y),(float) (_x),(float) (_y+_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1531;BA.debugLine="xcvsGraph.DrawLine(X, Y + dx, X - dx, Y, Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_y+_dx),(float) (_x-_dx),(float) (_y),_color,(float) (__c.DipToCurrent((int) (2))));
 }else {
 //BA.debugLineNum = 1533;BA.debugLine="xcvsGraph.DrawRect(r, Color, True, 1dip)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_r,_color,__c.True,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1534;BA.debugLine="xcvsGraph.RemoveClip";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.RemoveClip();
 //BA.debugLineNum = 1535;BA.debugLine="xcvsGraph.DrawLine(X - dx, Y, X, Y - dx, Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x-_dx),(float) (_y),(float) (_x),(float) (_y-_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1536;BA.debugLine="xcvsGraph.DrawLine(X, Y - dx, X + dx, Y, Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_y-_dx),(float) (_x+_dx),(float) (_y),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1537;BA.debugLine="xcvsGraph.DrawLine(X + dx, Y, X, Y + dx, Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x+_dx),(float) (_y),(float) (_x),(float) (_y+_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1538;BA.debugLine="xcvsGraph.DrawLine(X, Y + dx, X - dx, Y, Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_y+_dx),(float) (_x-_dx),(float) (_y),_color,(float) (__c.DipToCurrent((int) (2))));
 };
 break; }
case 4: {
 //BA.debugLineNum = 1541;BA.debugLine="dx = dx + 1dip";
_dx = (int) (_dx+__c.DipToCurrent((int) (1)));
 //BA.debugLineNum = 1542;BA.debugLine="xcvsGraph.DrawLine(X, Y - dx, X, Y + dx, Color,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_y-_dx),(float) (_x),(float) (_y+_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1543;BA.debugLine="xcvsGraph.DrawLine(X - dx, Y, X + dx, Y, Color,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x-_dx),(float) (_y),(float) (_x+_dx),(float) (_y),_color,(float) (__c.DipToCurrent((int) (2))));
 break; }
case 5: 
case 6: {
 //BA.debugLineNum = 1545;BA.debugLine="xcvsGraph.DrawLine(X - dx, Y + dx, X + dx, Y -";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x-_dx),(float) (_y+_dx),(float) (_x+_dx),(float) (_y-_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1546;BA.debugLine="xcvsGraph.DrawLine(X - dx, Y - dx, X + dx, Y +";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x-_dx),(float) (_y-_dx),(float) (_x+_dx),(float) (_y+_dx),_color,(float) (__c.DipToCurrent((int) (2))));
 break; }
}
;
 //BA.debugLineNum = 1548;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvvv4() throws Exception{
int _i = 0;
int _x = 0;
int _x1 = 0;
int _xinterval = 0;
int _l1 = 0;
String _txt = "";
double _h1 = 0;
double _h2 = 0;
double _h3 = 0;
double _h4 = 0;
double _h5 = 0;
cmarsoft.recu.xchart._pointdata _pd = null;
 //BA.debugLineNum = 1295;BA.debugLine="Private Sub DrawXScale";
 //BA.debugLineNum = 1296;BA.debugLine="Private i, x, x1, XInterval, l1 As Int";
_i = 0;
_x = 0;
_x1 = 0;
_xinterval = 0;
_l1 = 0;
 //BA.debugLineNum = 1297;BA.debugLine="Private txt As String";
_txt = "";
 //BA.debugLineNum = 1298;BA.debugLine="Private h1, h2, h3, h4, h5 As Double";
_h1 = 0;
_h2 = 0;
_h3 = 0;
_h4 = 0;
_h5 = 0;
 //BA.debugLineNum = 1307;BA.debugLine="h1 = 1.1";
_h1 = 1.1;
 //BA.debugLineNum = 1308;BA.debugLine="h2 = 0.25";
_h2 = 0.25;
 //BA.debugLineNum = 1309;BA.debugLine="h3 = 0.3";
_h3 = 0.3;
 //BA.debugLineNum = 1310;BA.debugLine="h4 = 0.6";
_h4 = 0.6;
 //BA.debugLineNum = 1311;BA.debugLine="h5 = 0.8";
_h5 = 0.8;
 //BA.debugLineNum = 1313;BA.debugLine="l1 = 4dip";
_l1 = __c.DipToCurrent((int) (4));
 //BA.debugLineNum = 1315;BA.debugLine="If Graph.ChartType = \"YX_CHART\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("YX_CHART")) { 
 //BA.debugLineNum = 1316;BA.debugLine="XInterval = Graph.Width / Scale(sX).NbIntervals";
_xinterval = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].NbIntervals);
 //BA.debugLineNum = 1317;BA.debugLine="For i = 0 To Scale(sX).NbIntervals";
{
final int step12 = 1;
final int limit12 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].NbIntervals;
_i = (int) (0) ;
for (;_i <= limit12 ;_i = _i + step12 ) {
 //BA.debugLineNum = 1318;BA.debugLine="x = Graph.Left + i * XInterval";
_x = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_i*_xinterval);
 //BA.debugLineNum = 1319;BA.debugLine="txt = NumberFormat3(Scale(sX).MinVal + i * Scal";
_txt = _vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal+_i*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Interval,(int) (6));
 //BA.debugLineNum = 1321;BA.debugLine="xcvsGraph.DrawLine(x, Graph.Top, x, Graph.Botto";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top),(float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridColor,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1322;BA.debugLine="Select Graph.XScaleTextOrientation";
switch (BA.switchObjectToInt(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XScaleTextOrientation,"HORIZONTAL","VERTICAL","45 DEGREES")) {
case 0: {
 //BA.debugLineNum = 1324;BA.debugLine="If (x - x1) > 1.2 * MeasureTextWidth(txt, Tex";
if ((_x-_x1)>1.2*_vvvvvvvvvvvvvv3(_txt,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)) { 
 //BA.debugLineNum = 1325;BA.debugLine="xcvsGraph.DrawText(txt, x, Graph.Bottom + h1";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_txt,(float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_h1*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 //BA.debugLineNum = 1326;BA.debugLine="x1 = x";
_x1 = _x;
 };
 break; }
case 1: {
 //BA.debugLineNum = 1329;BA.debugLine="If (x - x1) > 1.2 * Texts.ScaleTextHeight The";
if ((_x-_x1)>1.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight) { 
 //BA.debugLineNum = 1330;BA.debugLine="xcvsGraph.DrawTextRotated(txt, x + h2 * Text";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawTextRotated(ba,_txt,(float) (_x+_h2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_h4*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"),(float) (-90));
 //BA.debugLineNum = 1331;BA.debugLine="x1 = x";
_x1 = _x;
 };
 break; }
case 2: {
 //BA.debugLineNum = 1334;BA.debugLine="If (x - x1) > 1.2 * Texts.ScaleTextHeight The";
if ((_x-_x1)>1.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight) { 
 //BA.debugLineNum = 1335;BA.debugLine="xcvsGraph.DrawTextRotated(txt, x + h3 * Text";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawTextRotated(ba,_txt,(float) (_x+_h3*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_h5*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"),(float) (-45));
 //BA.debugLineNum = 1336;BA.debugLine="x1 = x";
_x1 = _x;
 };
 //BA.debugLineNum = 1338;BA.debugLine="xcvsGraph.DrawLine(x, Graph.Bottom, x, Graph.";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom),(float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_l1),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,(float) (__c.DipToCurrent((int) (2))));
 break; }
}
;
 //BA.debugLineNum = 1340;BA.debugLine="x1 = x";
_x1 = _x;
 }
};
 }else {
 //BA.debugLineNum = 1343;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step37 = 1;
final int limit37 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit37 ;_i = _i + step37 ) {
 //BA.debugLineNum = 1344;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1345;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1346;BA.debugLine="If Graph.ChartType = \"LINE\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("LINE")) { 
 //BA.debugLineNum = 1347;BA.debugLine="x = Graph.Left + i * Scale(sX).Scale";
_x = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_i*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale);
 }else {
 //BA.debugLineNum = 1349;BA.debugLine="x = Graph.Left + Graph.XOffset + (i + 0.5) * G";
_x = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset+(_i+0.5)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval);
 };
 //BA.debugLineNum = 1351;BA.debugLine="If PD.ShowTick = True Then";
if (_pd.ShowTick==__c.True) { 
 //BA.debugLineNum = 1353;BA.debugLine="xcvsGraph.DrawLine(x, Graph.Top, x, Graph.Bott";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top),(float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridColor,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1354;BA.debugLine="Select Graph.XScaleTextOrientation";
switch (BA.switchObjectToInt(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XScaleTextOrientation,"HORIZONTAL","VERTICAL","45 DEGREES")) {
case 0: {
 //BA.debugLineNum = 1356;BA.debugLine="If (x - x1) > 1.2 * MeasureTextWidth(PD.X, T";
if ((_x-_x1)>1.2*_vvvvvvvvvvvvvv3(_pd.X,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)) { 
 //BA.debugLineNum = 1357;BA.debugLine="xcvsGraph.DrawText(PD.X, x, Graph.Bottom +";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_pd.X,(float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_h1*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"CENTER"));
 //BA.debugLineNum = 1358;BA.debugLine="x1 = x";
_x1 = _x;
 //BA.debugLineNum = 1359;BA.debugLine="xcvsGraph.DrawLine(x, Graph.Bottom, x, Grap";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom),(float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_l1),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,(float) (__c.DipToCurrent((int) (2))));
 };
 break; }
case 1: {
 //BA.debugLineNum = 1362;BA.debugLine="If (x - x1) > 1.2 * Texts.ScaleTextHeight Th";
if ((_x-_x1)>1.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight) { 
 //BA.debugLineNum = 1363;BA.debugLine="xcvsGraph.DrawTextRotated(PD.X, x + h2 * Te";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawTextRotated(ba,_pd.X,(float) (_x+_h2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_h4*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"),(float) (-90));
 //BA.debugLineNum = 1364;BA.debugLine="x1 = x";
_x1 = _x;
 //BA.debugLineNum = 1365;BA.debugLine="xcvsGraph.DrawLine(x, Graph.Bottom, x, Grap";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom),(float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_l1),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,(float) (__c.DipToCurrent((int) (2))));
 };
 break; }
case 2: {
 //BA.debugLineNum = 1368;BA.debugLine="If (x - x1) > 1.2 * Texts.ScaleTextHeight Th";
if ((_x-_x1)>1.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight) { 
 //BA.debugLineNum = 1369;BA.debugLine="xcvsGraph.DrawTextRotated(PD.X, x + h3 * Te";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawTextRotated(ba,_pd.X,(float) (_x+_h3*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_h5*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"),(float) (-45));
 //BA.debugLineNum = 1370;BA.debugLine="x1 = x";
_x1 = _x;
 //BA.debugLineNum = 1371;BA.debugLine="xcvsGraph.DrawLine(x, Graph.Bottom, x, Grap";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom),(float) (_x),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_l1),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,(float) (__c.DipToCurrent((int) (2))));
 };
 break; }
}
;
 };
 }
};
 };
 //BA.debugLineNum = 1377;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvvv5() throws Exception{
int _i = 0;
int _y = 0;
String _txt = "";
 //BA.debugLineNum = 1270;BA.debugLine="Private Sub DrawYScale";
 //BA.debugLineNum = 1271;BA.debugLine="Private i, y As Int";
_i = 0;
_y = 0;
 //BA.debugLineNum = 1272;BA.debugLine="Private txt As String";
_txt = "";
 //BA.debugLineNum = 1274;BA.debugLine="For i = 0 To Scale(sY).NbIntervals";
{
final int step3 = 1;
final int limit3 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].NbIntervals;
_i = (int) (0) ;
for (;_i <= limit3 ;_i = _i + step3 ) {
 //BA.debugLineNum = 1275;BA.debugLine="y = Graph.Top + i * Graph.YInterval";
_y = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top+_i*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.YInterval);
 //BA.debugLineNum = 1276;BA.debugLine="xcvsGraph.DrawLine(Graph.Left - 4dip, y, Graph.L";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left-__c.DipToCurrent((int) (4))),(float) (_y),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_y),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1277;BA.debugLine="xcvsGraph.DrawLine(Graph.Left, y, Graph.Right, y";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_y),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_y),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridColor,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 1278;BA.debugLine="If MinMaxMeanValues(0) = 0 And MinMaxMeanValues(";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)]==0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)]==0) { 
 //BA.debugLineNum = 1279;BA.debugLine="txt = \"\"";
_txt = "";
 }else {
 //BA.debugLineNum = 1281;BA.debugLine="txt = NumberFormat3(Scale(sY).MaxVal - i * Scal";
_txt = _vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal-_i*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Interval,(int) (6));
 };
 //BA.debugLineNum = 1285;BA.debugLine="xcvsGraph.DrawText(txt, Graph.Left - 0.5 * Texts";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawText(ba,_txt,(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left-0.5*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),(float) (_y+0.35*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"));
 }
};
 //BA.debugLineNum = 1292;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvvv6() throws Exception{
int _i = 0;
int _l = 0;
cmarsoft.recu.xchart._itemdata _id = null;
double[] _yxval = null;
int _x0 = 0;
int _y0 = 0;
int _x1 = 0;
int _y1 = 0;
int _myaxis0 = 0;
int _mxaxis0 = 0;
 //BA.debugLineNum = 1551;BA.debugLine="Private Sub DrawYXLines";
 //BA.debugLineNum = 1552;BA.debugLine="Private i, l As Int";
_i = 0;
_l = 0;
 //BA.debugLineNum = 1553;BA.debugLine="Private ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 1554;BA.debugLine="Private yxVal(2) As Double";
_yxval = new double[(int) (2)];
;
 //BA.debugLineNum = 1555;BA.debugLine="Private x0, y0, x1, y1 As Int";
_x0 = 0;
_y0 = 0;
_x1 = 0;
_y1 = 0;
 //BA.debugLineNum = 1557;BA.debugLine="If Items.Size = 0 Then Return";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()==0) { 
if (true) return "";};
 //BA.debugLineNum = 1559;BA.debugLine="xcvsGraph.ClipPath(pthGrid)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.ClipPath(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv4);
 //BA.debugLineNum = 1560;BA.debugLine="For l = 0 To Items.Size - 1";
{
final int step7 = 1;
final int limit7 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()-1);
_l = (int) (0) ;
for (;_l <= limit7 ;_l = _l + step7 ) {
 //BA.debugLineNum = 1561;BA.debugLine="ID = Items.Get(l)";
_id = (cmarsoft.recu.xchart._itemdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Get(_l));
 //BA.debugLineNum = 1562;BA.debugLine="yxVal = ID.YXArray.Get(0)";
_yxval = (double[])(_id.YXArray.Get((int) (0)));
 //BA.debugLineNum = 1563;BA.debugLine="x0 = Graph.Left + (yxVal(0) - Scale(sX).MinVal)";
_x0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+(_yxval[(int) (0)]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale);
 //BA.debugLineNum = 1564;BA.debugLine="y0 = Graph.Bottom - (yxVal(1) - Scale(sY).MinVal";
_y0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-(_yxval[(int) (1)]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1565;BA.debugLine="If ID.PointType <> \"NONE\" Then";
if ((_id.PointType).equals("NONE") == false) { 
 //BA.debugLineNum = 1566;BA.debugLine="DrawPoint(x0, y0, ID.PointColor, ID.PointType,";
_vvvvvvv3(_x0,_y0,_id.PointColor,_id.PointType,_id.Filled,_id.StrokeWidth);
 };
 //BA.debugLineNum = 1568;BA.debugLine="For i = 0 To ID.YXArray.Size - 1";
{
final int step15 = 1;
final int limit15 = (int) (_id.YXArray.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit15 ;_i = _i + step15 ) {
 //BA.debugLineNum = 1569;BA.debugLine="yxVal = ID.YXArray.Get(i)";
_yxval = (double[])(_id.YXArray.Get(_i));
 //BA.debugLineNum = 1570;BA.debugLine="x1 = Graph.Left + (yxVal(0) - Scale(sX).MinVal)";
_x1 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+(_yxval[(int) (0)]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale);
 //BA.debugLineNum = 1571;BA.debugLine="y1 = Graph.Bottom - (yxVal(1) - Scale(sY).MinVa";
_y1 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-(_yxval[(int) (1)]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1572;BA.debugLine="If ID.DrawLine = True Then";
if (_id.DrawLine==__c.True) { 
 //BA.debugLineNum = 1573;BA.debugLine="xcvsGraph.DrawLine(x0, y0, x1, y1 , ID.Color,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_x0),(float) (_y0),(float) (_x1),(float) (_y1),_id.Color,(float) (_id.StrokeWidth));
 };
 //BA.debugLineNum = 1575;BA.debugLine="x0 = x1";
_x0 = _x1;
 //BA.debugLineNum = 1576;BA.debugLine="y0 = y1";
_y0 = _y1;
 }
};
 }
};
 //BA.debugLineNum = 1579;BA.debugLine="xcvsGraph.RemoveClip";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.RemoveClip();
 //BA.debugLineNum = 1581;BA.debugLine="For l = 0 To Items.Size - 1";
{
final int step27 = 1;
final int limit27 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()-1);
_l = (int) (0) ;
for (;_l <= limit27 ;_l = _l + step27 ) {
 //BA.debugLineNum = 1582;BA.debugLine="ID = Items.Get(l)";
_id = (cmarsoft.recu.xchart._itemdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Get(_l));
 //BA.debugLineNum = 1583;BA.debugLine="If ID.PointType <> \"NONE\" Then";
if ((_id.PointType).equals("NONE") == false) { 
 //BA.debugLineNum = 1584;BA.debugLine="For i = 0 To ID.YXArray.Size - 1";
{
final int step30 = 1;
final int limit30 = (int) (_id.YXArray.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit30 ;_i = _i + step30 ) {
 //BA.debugLineNum = 1585;BA.debugLine="yxVal = ID.YXArray.Get(i)";
_yxval = (double[])(_id.YXArray.Get(_i));
 //BA.debugLineNum = 1586;BA.debugLine="x1 = Graph.Left + (yxVal(0) - Scale(sX).MinVal";
_x1 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+(_yxval[(int) (0)]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale);
 //BA.debugLineNum = 1587;BA.debugLine="y1 = Graph.Bottom - (yxVal(1) - Scale(sY).MinV";
_y1 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom-(_yxval[(int) (1)]-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1588;BA.debugLine="DrawPoint(x1, y1, ID.PointColor, ID.PointType,";
_vvvvvvv3(_x1,_y1,_id.PointColor,_id.PointType,_id.Filled,_id.StrokeWidth);
 }
};
 };
 }
};
 //BA.debugLineNum = 1593;BA.debugLine="xcvsGraph.DrawRect(Graph.Rect, Graph.GridFrameCol";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Rect,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,__c.False,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1594;BA.debugLine="If Scale(sY).MinVal< 0 And Scale(sY).MaxVal > 0 T";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal<0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal>0) { 
 //BA.debugLineNum = 1595;BA.debugLine="Private mYAxis0 = Graph.Bottom + Scale(sY).MinVa";
_myaxis0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale);
 //BA.debugLineNum = 1596;BA.debugLine="xcvsGraph.DrawLine(Graph.Left, mYAxis0, Graph.Ri";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_myaxis0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_myaxis0),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,(float) (__c.DipToCurrent((int) (2))));
 };
 //BA.debugLineNum = 1599;BA.debugLine="xcvsGraph.DrawRect(Graph.Rect, Graph.GridFrameCol";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Rect,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,__c.False,(float) (__c.DipToCurrent((int) (2))));
 //BA.debugLineNum = 1600;BA.debugLine="If Scale(sX).MinVal< 0 And Scale(sX).MaxVal > 0 T";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal<0 && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MaxVal>0) { 
 //BA.debugLineNum = 1601;BA.debugLine="Private mXAxis0 = Graph.Left - Scale(sX).MinVal";
_mxaxis0 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale);
 //BA.debugLineNum = 1602;BA.debugLine="xcvsGraph.DrawLine(mXAxis0, Graph.Top, mXAxis0,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.DrawLine((float) (_mxaxis0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top),(float) (_mxaxis0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor,(float) (__c.DipToCurrent((int) (2))));
 };
 //BA.debugLineNum = 1605;BA.debugLine="If Legend.IncludeLegend <> \"NONE\" And (Points.Siz";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend).equals("NONE") == false && (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()>0 || (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("YX_CHART"))) { 
 //BA.debugLineNum = 1606;BA.debugLine="DrawLegend";
_vvvvvv0();
 };
 //BA.debugLineNum = 1609;BA.debugLine="xcvsGraph.Invalidate";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.Invalidate();
 //BA.debugLineNum = 1610;BA.debugLine="End Sub";
return "";
}
public boolean  _getvvvvvvvvvvvvvvvvvvvv0() throws Exception{
 //BA.debugLineNum = 2399;BA.debugLine="Public Sub getAutomaticScale As Boolean";
 //BA.debugLineNum = 2400;BA.debugLine="Return Scale(sY).Automatic";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Automatic;
 //BA.debugLineNum = 2401;BA.debugLine="End Sub";
return false;
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvv1() throws Exception{
 //BA.debugLineNum = 2481;BA.debugLine="Public Sub getAutomaticTextSizes As Boolean";
 //BA.debugLineNum = 2482;BA.debugLine="Return Texts.AutomaticTextSizes";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AutomaticTextSizes;
 //BA.debugLineNum = 2483;BA.debugLine="End Sub";
return false;
}
public float  _getvvvvvvvvvvvvvvvvvvvvv2() throws Exception{
 //BA.debugLineNum = 2503;BA.debugLine="Public Sub getAxisTextSize As Float";
 //BA.debugLineNum = 2504;BA.debugLine="Return Texts.AxisTextSize";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextSize;
 //BA.debugLineNum = 2505;BA.debugLine="End Sub";
return 0f;
}
public double[]  _vvvvvvvv2() throws Exception{
int _j = 0;
double[] _minmax = null;
int _i = 0;
double[] _yvals = null;
cmarsoft.recu.xchart._pointdata _pd = null;
double _total = 0;
 //BA.debugLineNum = 1046;BA.debugLine="Private Sub GetBarPointsMinMaxValues As Double()";
 //BA.debugLineNum = 1047;BA.debugLine="Private j, j As Int";
_j = 0;
_j = 0;
 //BA.debugLineNum = 1048;BA.debugLine="Private MinMax(2) As Double";
_minmax = new double[(int) (2)];
;
 //BA.debugLineNum = 1050;BA.debugLine="If Graph.ChartType = \"BAR\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("BAR")) { 
 //BA.debugLineNum = 1052;BA.debugLine="MinMax(1) = -1E10";
_minmax[(int) (1)] = -1e10;
 //BA.debugLineNum = 1053;BA.debugLine="MinMax(0) = 1E10";
_minmax[(int) (0)] = 1e10;
 //BA.debugLineNum = 1055;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step6 = 1;
final int limit6 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit6 ;_i = _i + step6 ) {
 //BA.debugLineNum = 1056;BA.debugLine="Private YVals() As Double";
_yvals = new double[(int) (0)];
;
 //BA.debugLineNum = 1057;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1058;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1059;BA.debugLine="YVals = PD.YArray";
_yvals = _pd.YArray;
 //BA.debugLineNum = 1060;BA.debugLine="For j = 0 To PD.YArray.Length - 1";
{
final int step11 = 1;
final int limit11 = (int) (_pd.YArray.length-1);
_j = (int) (0) ;
for (;_j <= limit11 ;_j = _j + step11 ) {
 //BA.debugLineNum = 1061;BA.debugLine="MinMax(1) = Max(MinMax(1), YVals(j))";
_minmax[(int) (1)] = __c.Max(_minmax[(int) (1)],_yvals[_j]);
 //BA.debugLineNum = 1062;BA.debugLine="MinMax(0) = Min(MinMax(0), YVals(j))";
_minmax[(int) (0)] = __c.Min(_minmax[(int) (0)],_yvals[_j]);
 }
};
 }
};
 //BA.debugLineNum = 1065;BA.debugLine="MinMaxMeanValues(0) = MinMax(0)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)] = _minmax[(int) (0)];
 //BA.debugLineNum = 1066;BA.debugLine="MinMaxMeanValues(1) = MinMax(1)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)] = _minmax[(int) (1)];
 //BA.debugLineNum = 1067;BA.debugLine="If MinMax(0) > 0 And MinMax(1) > 0 Then";
if (_minmax[(int) (0)]>0 && _minmax[(int) (1)]>0) { 
 //BA.debugLineNum = 1068;BA.debugLine="MinMax(0) = 0";
_minmax[(int) (0)] = 0;
 };
 //BA.debugLineNum = 1070;BA.debugLine="If MinMax(0) < 0 And MinMax(1) < 0 Then";
if (_minmax[(int) (0)]<0 && _minmax[(int) (1)]<0) { 
 //BA.debugLineNum = 1071;BA.debugLine="MinMax(1) = 0";
_minmax[(int) (1)] = 0;
 };
 }else {
 //BA.debugLineNum = 1075;BA.debugLine="MinMax(1) = 0";
_minmax[(int) (1)] = 0;
 //BA.debugLineNum = 1076;BA.debugLine="MinMax(0) = 0";
_minmax[(int) (0)] = 0;
 //BA.debugLineNum = 1078;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step27 = 1;
final int limit27 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit27 ;_i = _i + step27 ) {
 //BA.debugLineNum = 1079;BA.debugLine="Private YVals(), Total As Double";
_yvals = new double[(int) (0)];
;
_total = 0;
 //BA.debugLineNum = 1080;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1081;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1082;BA.debugLine="YVals = PD.YArray";
_yvals = _pd.YArray;
 //BA.debugLineNum = 1083;BA.debugLine="For j = 0 To PD.YArray.Length - 1";
{
final int step32 = 1;
final int limit32 = (int) (_pd.YArray.length-1);
_j = (int) (0) ;
for (;_j <= limit32 ;_j = _j + step32 ) {
 //BA.debugLineNum = 1084;BA.debugLine="Total = Total + YVals(j)";
_total = _total+_yvals[_j];
 }
};
 //BA.debugLineNum = 1086;BA.debugLine="MinMax(1) = Max(MinMax(1), Total)";
_minmax[(int) (1)] = __c.Max(_minmax[(int) (1)],_total);
 }
};
 //BA.debugLineNum = 1088;BA.debugLine="MinMaxMeanValues(0) = MinMax(0)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)] = _minmax[(int) (0)];
 //BA.debugLineNum = 1089;BA.debugLine="MinMaxMeanValues(1) = MinMax(1)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)] = _minmax[(int) (1)];
 };
 //BA.debugLineNum = 1092;BA.debugLine="Return MinMax";
if (true) return _minmax;
 //BA.debugLineNum = 1093;BA.debugLine="End Sub";
return null;
}
public String  _getvvvvvvvvvvvvvvvvvvvvv3() throws Exception{
 //BA.debugLineNum = 2802;BA.debugLine="Public Sub getBarValueOrientation As String";
 //BA.debugLineNum = 2803;BA.debugLine="Return Graph.BarValueOrientation";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarValueOrientation;
 //BA.debugLineNum = 2804;BA.debugLine="End Sub";
return "";
}
public String  _getvvvvvvvvvvvvvvvvvvvvv4() throws Exception{
 //BA.debugLineNum = 2420;BA.debugLine="Public Sub getChartType As String";
 //BA.debugLineNum = 2421;BA.debugLine="Return Graph.ChartType";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType;
 //BA.debugLineNum = 2422;BA.debugLine="End Sub";
return "";
}
public int  _vvvvvvvv5(int _color) throws Exception{
int _a = 0;
int _r = 0;
int _g = 0;
int _b = 0;
int _yiq = 0;
 //BA.debugLineNum = 2094;BA.debugLine="Private Sub GetContrastColor(Color As Int) As Int";
 //BA.debugLineNum = 2095;BA.debugLine="Private a, r, g, b, yiq As Int	'ignore";
_a = 0;
_r = 0;
_g = 0;
_b = 0;
_yiq = 0;
 //BA.debugLineNum = 2097;BA.debugLine="a = Bit.UnsignedShiftRight(Bit.And(Color, 0xff000";
_a = __c.Bit.UnsignedShiftRight(__c.Bit.And(_color,(int) (0xff000000)),(int) (24));
 //BA.debugLineNum = 2098;BA.debugLine="r = Bit.UnsignedShiftRight(Bit.And(Color, 0xff000";
_r = __c.Bit.UnsignedShiftRight(__c.Bit.And(_color,(int) (0xff0000)),(int) (16));
 //BA.debugLineNum = 2099;BA.debugLine="g = Bit.UnsignedShiftRight(Bit.And(Color, 0xff00)";
_g = __c.Bit.UnsignedShiftRight(__c.Bit.And(_color,(int) (0xff00)),(int) (8));
 //BA.debugLineNum = 2100;BA.debugLine="b = Bit.And(Color, 0xff)";
_b = __c.Bit.And(_color,(int) (0xff));
 //BA.debugLineNum = 2102;BA.debugLine="yiq = r * 0.299 + g * 0.587 + b * 0.114";
_yiq = (int) (_r*0.299+_g*0.587+_b*0.114);
 //BA.debugLineNum = 2104;BA.debugLine="If yiq > 128 Then";
if (_yiq>128) { 
 //BA.debugLineNum = 2105;BA.debugLine="Return xui.Color_Black";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_Black;
 }else {
 //BA.debugLineNum = 2107;BA.debugLine="Return xui.Color_White";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.Color_White;
 };
 //BA.debugLineNum = 2109;BA.debugLine="End Sub";
return 0;
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvv5() throws Exception{
 //BA.debugLineNum = 2551;BA.debugLine="Public Sub getDisplayValues As Boolean";
 //BA.debugLineNum = 2552;BA.debugLine="Return Values.Show";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Show;
 //BA.debugLineNum = 2553;BA.debugLine="End Sub";
return false;
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvv6() throws Exception{
 //BA.debugLineNum = 2715;BA.debugLine="Public Sub getDrawOuterFrame As Boolean";
 //BA.debugLineNum = 2716;BA.debugLine="Return Graph.DrawOuterFrame";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.DrawOuterFrame;
 //BA.debugLineNum = 2717;BA.debugLine="End Sub";
return false;
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvv7() throws Exception{
 //BA.debugLineNum = 2576;BA.debugLine="Public Sub getGradientColors As Boolean";
 //BA.debugLineNum = 2577;BA.debugLine="Return Graph.GradientColors";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColors;
 //BA.debugLineNum = 2578;BA.debugLine="End Sub";
return false;
}
public int  _getvvvvvvvvvvvvvvvvvvvvv0() throws Exception{
 //BA.debugLineNum = 2587;BA.debugLine="Public Sub getGradientColorsAlpha As Int";
 //BA.debugLineNum = 2588;BA.debugLine="Return Graph.GradientColorsAlpha";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColorsAlpha;
 //BA.debugLineNum = 2589;BA.debugLine="End Sub";
return 0;
}
public int  _getvvvvvvvvvvvvvvvvvvvvvv1() throws Exception{
 //BA.debugLineNum = 2461;BA.debugLine="Public Sub getHeight As Int";
 //BA.debugLineNum = 2462;BA.debugLine="Return xBase.Height";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvv6.getHeight();
 //BA.debugLineNum = 2463;BA.debugLine="End Sub";
return 0;
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvvv2() throws Exception{
 //BA.debugLineNum = 2389;BA.debugLine="Public Sub getIncludeBarMeanLine As Boolean";
 //BA.debugLineNum = 2390;BA.debugLine="Return Graph.IncludeBarMeanLine";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeBarMeanLine;
 //BA.debugLineNum = 2391;BA.debugLine="End Sub";
return false;
}
public String  _getvvvvvvvvvvvvvvvvvvvvvv3() throws Exception{
 //BA.debugLineNum = 2369;BA.debugLine="Public Sub getIncludeLegend As String";
 //BA.debugLineNum = 2370;BA.debugLine="Return Legend.IncludeLegend";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend;
 //BA.debugLineNum = 2371;BA.debugLine="End Sub";
return "";
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvvv4() throws Exception{
 //BA.debugLineNum = 2736;BA.debugLine="Public Sub getIncludeMaxLine As Boolean";
 //BA.debugLineNum = 2737;BA.debugLine="Return Graph.IncludeMaxLine";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMaxLine;
 //BA.debugLineNum = 2738;BA.debugLine="End Sub";
return false;
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvvv5() throws Exception{
 //BA.debugLineNum = 2747;BA.debugLine="Public Sub getIncludeMeanLine As Boolean";
 //BA.debugLineNum = 2748;BA.debugLine="Return Graph.IncludeMeanLine";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMeanLine;
 //BA.debugLineNum = 2749;BA.debugLine="End Sub";
return false;
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvvv6() throws Exception{
 //BA.debugLineNum = 2725;BA.debugLine="Public Sub getIncludeMinLine As Boolean";
 //BA.debugLineNum = 2726;BA.debugLine="Return Graph.IncludeMinLine";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMinLine;
 //BA.debugLineNum = 2727;BA.debugLine="End Sub";
return false;
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvvv7() throws Exception{
 //BA.debugLineNum = 2379;BA.debugLine="Public Sub getIncludeValues As Boolean";
 //BA.debugLineNum = 2380;BA.debugLine="Return Graph.IncludeValues";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeValues;
 //BA.debugLineNum = 2381;BA.debugLine="End Sub";
return false;
}
public int  _getvvvvvvvvvvvvvvvvvvvvvv0() throws Exception{
 //BA.debugLineNum = 2433;BA.debugLine="Public Sub getLeft As Int";
 //BA.debugLineNum = 2434;BA.debugLine="Return xBase.Left";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvv6.getLeft();
 //BA.debugLineNum = 2435;BA.debugLine="End Sub";
return 0;
}
public String  _vvvvvvvvvv2(int _limit) throws Exception{
int _x = 0;
int _box = 0;
boolean _alltoobig = false;
int _i = 0;
cmarsoft.recu.xchart._itemdata _item = null;
String _txt = "";
 //BA.debugLineNum = 2200;BA.debugLine="Private Sub GetLegendLineNumbers(Limit As Int)";
 //BA.debugLineNum = 2201;BA.debugLine="Private x As Int";
_x = 0;
 //BA.debugLineNum = 2202;BA.debugLine="Private box As Int = 0.7 * Legend.TextHeight";
_box = (int) (0.7*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 //BA.debugLineNum = 2204;BA.debugLine="Legend.LineNumber = 1";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumber = (int) (1);
 //BA.debugLineNum = 2205;BA.debugLine="Legend.LineNumbers.Clear";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumbers.Clear();
 //BA.debugLineNum = 2206;BA.debugLine="Legend.LineChange.Clear";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineChange.Clear();
 //BA.debugLineNum = 2208;BA.debugLine="Private AllTooBig = False As Boolean";
_alltoobig = __c.False;
 //BA.debugLineNum = 2210;BA.debugLine="For i = 0 To Items.Size - 1";
{
final int step7 = 1;
final int limit7 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit7 ;_i = _i + step7 ) {
 //BA.debugLineNum = 2211;BA.debugLine="Private Item As ItemData";
_item = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 2212;BA.debugLine="Item = Items.Get(i)";
_item = (cmarsoft.recu.xchart._itemdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Get(_i));
 //BA.debugLineNum = 2213;BA.debugLine="Private txt As String = Item.Name";
_txt = _item.Name;
 //BA.debugLineNum = 2214;BA.debugLine="If Graph.ChartType = \"PIE\" And Legend.IncludeLeg";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("PIE") && (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend).equals("BOTTOM") && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeValues==__c.True) { 
 //BA.debugLineNum = 2215;BA.debugLine="txt = txt & \" : \" & Item.Value";
_txt = _txt+" : "+BA.NumberToString(_item.Value);
 };
 //BA.debugLineNum = 2217;BA.debugLine="If 2.5 * box + MeasureTextWidth(txt, Legend.Text";
if (2.5*_box+_vvvvvvvvvvvvvv3(_txt,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextFont)>_limit) { 
 //BA.debugLineNum = 2218;BA.debugLine="AllTooBig = True";
_alltoobig = __c.True;
 };
 }
};
 //BA.debugLineNum = 2222;BA.debugLine="If AllTooBig = True Then";
if (_alltoobig==__c.True) { 
 //BA.debugLineNum = 2223;BA.debugLine="Legend.LineNumber = Items.Size";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumber = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize();
 //BA.debugLineNum = 2224;BA.debugLine="For i = 0 To Items.Size - 1";
{
final int step20 = 1;
final int limit20 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit20 ;_i = _i + step20 ) {
 //BA.debugLineNum = 2225;BA.debugLine="Legend.LineChange.Add(True)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineChange.Add((Object)(__c.True));
 //BA.debugLineNum = 2226;BA.debugLine="Legend.LineNumbers.Add(i)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumbers.Add((Object)(_i));
 }
};
 }else {
 //BA.debugLineNum = 2229;BA.debugLine="x = 0";
_x = (int) (0);
 //BA.debugLineNum = 2230;BA.debugLine="For i = 0 To Items.Size - 1";
{
final int step26 = 1;
final int limit26 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit26 ;_i = _i + step26 ) {
 //BA.debugLineNum = 2231;BA.debugLine="Private Item As ItemData";
_item = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 2232;BA.debugLine="Item = Items.Get(i)";
_item = (cmarsoft.recu.xchart._itemdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Get(_i));
 //BA.debugLineNum = 2233;BA.debugLine="Private txt As String = Item.Name";
_txt = _item.Name;
 //BA.debugLineNum = 2234;BA.debugLine="If Graph.ChartType = \"PIE\" And Legend.IncludeLe";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("PIE") && (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend).equals("BOTTOM") && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeValues==__c.True) { 
 //BA.debugLineNum = 2235;BA.debugLine="txt = txt & \" : \" & Item.Value";
_txt = _txt+" : "+BA.NumberToString(_item.Value);
 };
 //BA.debugLineNum = 2237;BA.debugLine="x = x + 2.5 * box + MeasureTextWidth(txt, Legen";
_x = (int) (_x+2.5*_box+_vvvvvvvvvvvvvv3(_txt,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextFont));
 //BA.debugLineNum = 2238;BA.debugLine="If x > Limit Then";
if (_x>_limit) { 
 //BA.debugLineNum = 2239;BA.debugLine="x = 2.5 * box + MeasureTextWidth(txt, Legend.T";
_x = (int) (2.5*_box+_vvvvvvvvvvvvvv3(_txt,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextFont));
 //BA.debugLineNum = 2240;BA.debugLine="Legend.LineNumber = Legend.LineNumber + 1";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumber = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumber+1);
 //BA.debugLineNum = 2241;BA.debugLine="Legend.LineChange.Add(True)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineChange.Add((Object)(__c.True));
 }else {
 //BA.debugLineNum = 2243;BA.debugLine="Legend.LineChange.Add(False)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineChange.Add((Object)(__c.False));
 };
 //BA.debugLineNum = 2245;BA.debugLine="Legend.LineNumbers.Add(Legend.LineNumber - 1)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumbers.Add((Object)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumber-1));
 }
};
 };
 //BA.debugLineNum = 2248;BA.debugLine="End Sub";
return "";
}
public float  _getvvvvvvvvvvvvvvvvvvvvvvv1() throws Exception{
 //BA.debugLineNum = 2527;BA.debugLine="Public Sub getLegendTextSize As Float";
 //BA.debugLineNum = 2528;BA.debugLine="Return Legend.TextSize";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextSize;
 //BA.debugLineNum = 2529;BA.debugLine="End Sub";
return 0f;
}
public double[]  _vvvvvvvvvv4(int _axis) throws Exception{
int _j = 0;
int _i = 0;
double[] _yvals = null;
cmarsoft.recu.xchart._pointdata _pd = null;
cmarsoft.recu.xchart._itemdata _id = null;
int _l = 0;
double[] _yxval = null;
 //BA.debugLineNum = 1096;BA.debugLine="Private Sub GetLinePointsMinMaxMeanValues(Axis As";
 //BA.debugLineNum = 1097;BA.debugLine="Private j, j As Int";
_j = 0;
_j = 0;
 //BA.debugLineNum = 1099;BA.debugLine="MinMaxMeanValues(1) = -1E10";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)] = -1e10;
 //BA.debugLineNum = 1100;BA.debugLine="MinMaxMeanValues(0) = 1E10";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)] = 1e10;
 //BA.debugLineNum = 1101;BA.debugLine="MinMaxMeanValues(2) = 0";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (2)] = 0;
 //BA.debugLineNum = 1103;BA.debugLine="If Graph.ChartType = \"LINE\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("LINE")) { 
 //BA.debugLineNum = 1104;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step6 = 1;
final int limit6 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit6 ;_i = _i + step6 ) {
 //BA.debugLineNum = 1105;BA.debugLine="Private YVals() As Double";
_yvals = new double[(int) (0)];
;
 //BA.debugLineNum = 1106;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1107;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1108;BA.debugLine="If Axis = 0 Then";
if (_axis==0) { 
 //BA.debugLineNum = 1109;BA.debugLine="YVals = PD.YArray";
_yvals = _pd.YArray;
 }else {
 //BA.debugLineNum = 1111;BA.debugLine="YVals = PD.XArray";
_yvals = _pd.XArray;
 };
 //BA.debugLineNum = 1113;BA.debugLine="For j = 0 To PD.YArray.Length - 1";
{
final int step15 = 1;
final int limit15 = (int) (_pd.YArray.length-1);
_j = (int) (0) ;
for (;_j <= limit15 ;_j = _j + step15 ) {
 //BA.debugLineNum = 1114;BA.debugLine="MinMaxMeanValues(1) = Max(MinMaxMeanValues(1),";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)] = __c.Max(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)],_yvals[_j]);
 //BA.debugLineNum = 1115;BA.debugLine="MinMaxMeanValues(0) = Min(MinMaxMeanValues(0),";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)] = __c.Min(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)],_yvals[_j]);
 //BA.debugLineNum = 1116;BA.debugLine="MinMaxMeanValues(2) = MinMaxMeanValues(2) + YV";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (2)] = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (2)]+_yvals[_j];
 }
};
 }
};
 //BA.debugLineNum = 1119;BA.debugLine="MinMaxMeanValues(2) = MinMaxMeanValues(2) / Poin";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (2)] = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (2)]/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()/(double)_pd.YArray.length;
 }else {
 //BA.debugLineNum = 1121;BA.debugLine="Private ID As ItemData";
_id = new cmarsoft.recu.xchart._itemdata();
 //BA.debugLineNum = 1123;BA.debugLine="For l = 0 To Items.Size - 1";
{
final int step24 = 1;
final int limit24 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()-1);
_l = (int) (0) ;
for (;_l <= limit24 ;_l = _l + step24 ) {
 //BA.debugLineNum = 1124;BA.debugLine="ID = Items.Get(l)";
_id = (cmarsoft.recu.xchart._itemdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Get(_l));
 //BA.debugLineNum = 1125;BA.debugLine="For i = 0 To ID.YXArray.Size - 1";
{
final int step26 = 1;
final int limit26 = (int) (_id.YXArray.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit26 ;_i = _i + step26 ) {
 //BA.debugLineNum = 1126;BA.debugLine="Private YXVal(2) As Double";
_yxval = new double[(int) (2)];
;
 //BA.debugLineNum = 1127;BA.debugLine="YXVal = ID.YXArray.Get(i)";
_yxval = (double[])(_id.YXArray.Get(_i));
 //BA.debugLineNum = 1128;BA.debugLine="If Axis = 0 Then  'Y axis";
if (_axis==0) { 
 //BA.debugLineNum = 1129;BA.debugLine="MinMaxMeanValues(1) = Max(MinMaxMeanValues(1)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)] = __c.Max(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)],_yxval[(int) (1)]);
 //BA.debugLineNum = 1130;BA.debugLine="MinMaxMeanValues(0) = Min(MinMaxMeanValues(0)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)] = __c.Min(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)],_yxval[(int) (1)]);
 }else {
 //BA.debugLineNum = 1132;BA.debugLine="MinMaxMeanValues(1) = Max(MinMaxMeanValues(1)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)] = __c.Max(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)],_yxval[(int) (0)]);
 //BA.debugLineNum = 1133;BA.debugLine="MinMaxMeanValues(0) = Min(MinMaxMeanValues(0)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)] = __c.Min(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)],_yxval[(int) (0)]);
 };
 }
};
 }
};
 //BA.debugLineNum = 1137;BA.debugLine="MinMaxMeanValues(0) = MinMaxMeanValues(0)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)] = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (0)];
 //BA.debugLineNum = 1138;BA.debugLine="MinMaxMeanValues(1) = MinMaxMeanValues(1)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)] = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (1)];
 //BA.debugLineNum = 1139;BA.debugLine="MinMaxMeanValues(2) = 0";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6[(int) (2)] = 0;
 };
 //BA.debugLineNum = 1142;BA.debugLine="Return MinMaxMeanValues";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv6;
 //BA.debugLineNum = 1143;BA.debugLine="End Sub";
return null;
}
public int  _getvvvvvvvvvvvvvvvvvvvvvvv2() throws Exception{
 //BA.debugLineNum = 2693;BA.debugLine="Public Sub getNbPoints As Int";
 //BA.debugLineNum = 2694;BA.debugLine="Return Points.Size";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize();
 //BA.debugLineNum = 2695;BA.debugLine="End Sub";
return 0;
}
public int  _getvvvvvvvvvvvvvvvvvvvvvvv3() throws Exception{
 //BA.debugLineNum = 2673;BA.debugLine="Public Sub getNbXIntervals As Int";
 //BA.debugLineNum = 2674;BA.debugLine="Return Scale(sX).NbIntervals";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].NbIntervals;
 //BA.debugLineNum = 2675;BA.debugLine="End Sub";
return 0;
}
public int  _getvvvvvvvvvvvvvvvvvvvvvvv4() throws Exception{
 //BA.debugLineNum = 2662;BA.debugLine="Public Sub getNbYIntervals As Int";
 //BA.debugLineNum = 2663;BA.debugLine="Return Scale(sY).NbIntervals";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].NbIntervals;
 //BA.debugLineNum = 2664;BA.debugLine="End Sub";
return 0;
}
public double  _getvvvvvvvvvvvvvvvvvvvvvvv5() throws Exception{
 //BA.debugLineNum = 2704;BA.debugLine="Public Sub getRotation As Double";
 //BA.debugLineNum = 2705;BA.debugLine="Return Graph.Rotation";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Rotation;
 //BA.debugLineNum = 2706;BA.debugLine="End Sub";
return 0;
}
public double  _vvvvvvvvvvv1(double _scalemant0) throws Exception{
double _scalemant1 = 0;
String[] _scales = null;
double[] _vals = null;
double[] _logs = null;
int _i = 0;
 //BA.debugLineNum = 1019;BA.debugLine="Private Sub GetScaleMant(ScaleMant0 As Double) As";
 //BA.debugLineNum = 1020;BA.debugLine="Private ScaleMant1 As Double";
_scalemant1 = 0;
 //BA.debugLineNum = 1021;BA.debugLine="Private Scales() As String";
_scales = new String[(int) (0)];
java.util.Arrays.fill(_scales,"");
 //BA.debugLineNum = 1023;BA.debugLine="Scales = Regex.Split(\"!\", Scale(sY).ScaleValues)";
_scales = __c.Regex.Split("!",_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].ScaleValues);
 //BA.debugLineNum = 1024;BA.debugLine="Private Vals(Scales.Length), Logs(Scales.Length)";
_vals = new double[_scales.length];
;
_logs = new double[_scales.length];
;
 //BA.debugLineNum = 1026;BA.debugLine="For i = 0 To Scales.Length - 1";
{
final int step5 = 1;
final int limit5 = (int) (_scales.length-1);
_i = (int) (0) ;
for (;_i <= limit5 ;_i = _i + step5 ) {
 //BA.debugLineNum = 1027;BA.debugLine="Vals(i) = Scales(i)";
_vals[_i] = (double)(Double.parseDouble(_scales[_i]));
 //BA.debugLineNum = 1028;BA.debugLine="Logs(i) = Logarithm(Vals(i), 10) + 0.00000000000";
_logs[_i] = __c.Logarithm(_vals[_i],10)+0.00000000000001;
 }
};
 //BA.debugLineNum = 1031;BA.debugLine="If ScaleMant0 <= Logs(0) Then";
if (_scalemant0<=_logs[(int) (0)]) { 
 //BA.debugLineNum = 1032;BA.debugLine="ScaleMant1 = 0";
_scalemant1 = 0;
 }else {
 //BA.debugLineNum = 1034;BA.debugLine="For i = 0 To Scales.Length - 2";
{
final int step12 = 1;
final int limit12 = (int) (_scales.length-2);
_i = (int) (0) ;
for (;_i <= limit12 ;_i = _i + step12 ) {
 //BA.debugLineNum = 1035;BA.debugLine="If ScaleMant0 > Logs(i) And ScaleMant0 <= Logs(";
if (_scalemant0>_logs[_i] && _scalemant0<=_logs[(int) (_i+1)]) { 
 //BA.debugLineNum = 1036;BA.debugLine="ScaleMant1 = Logarithm(Vals(i + 1), 10)";
_scalemant1 = __c.Logarithm(_vals[(int) (_i+1)],10);
 //BA.debugLineNum = 1037;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 };
 //BA.debugLineNum = 1042;BA.debugLine="Return ScaleMant1";
if (true) return _scalemant1;
 //BA.debugLineNum = 1043;BA.debugLine="End Sub";
return 0;
}
public float  _getvvvvvvvvvvvvvvvvvvvvvvv6() throws Exception{
 //BA.debugLineNum = 2515;BA.debugLine="Public Sub getScaleTextSize As Float";
 //BA.debugLineNum = 2516;BA.debugLine="Return Texts.ScaleTextSize";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextSize;
 //BA.debugLineNum = 2517;BA.debugLine="End Sub";
return 0f;
}
public String  _getvvvvvvvvvvvvvvvvvvvvvvv7() throws Exception{
 //BA.debugLineNum = 2563;BA.debugLine="Public Sub getScaleValues As String";
 //BA.debugLineNum = 2564;BA.debugLine="Return Scale(sY).ScaleValues";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].ScaleValues;
 //BA.debugLineNum = 2565;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper  _getvvvvvvvvvvvvvvvvvvvvvvv0() throws Exception{
 //BA.debugLineNum = 2698;BA.debugLine="Public Sub getSnapshot As B4XBitmap";
 //BA.debugLineNum = 2699;BA.debugLine="Return xBase.Snapshot";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvv6.Snapshot();
 //BA.debugLineNum = 2700;BA.debugLine="End Sub";
return null;
}
public String  _getvvvvvvvvvvvvvvvvvvvvvvvv1() throws Exception{
 //BA.debugLineNum = 2773;BA.debugLine="Public Sub getSubtitle As String";
 //BA.debugLineNum = 2774;BA.debugLine="Return Graph.Subtitle";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Subtitle;
 //BA.debugLineNum = 2775;BA.debugLine="End Sub";
return "";
}
public float  _getvvvvvvvvvvvvvvvvvvvvvvvv2() throws Exception{
 //BA.debugLineNum = 2783;BA.debugLine="Public Sub getSubtitleTextSize As Float";
 //BA.debugLineNum = 2784;BA.debugLine="Return Texts.AxisTextSize";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextSize;
 //BA.debugLineNum = 2785;BA.debugLine="End Sub";
return 0f;
}
public String  _getvvvvvvvvvvvvvvvvvvvvvvvv3() throws Exception{
 //BA.debugLineNum = 2287;BA.debugLine="Public Sub getTitle As String";
 //BA.debugLineNum = 2288;BA.debugLine="Return Graph.Title";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Title;
 //BA.debugLineNum = 2289;BA.debugLine="End Sub";
return "";
}
public float  _getvvvvvvvvvvvvvvvvvvvvvvvv4() throws Exception{
 //BA.debugLineNum = 2491;BA.debugLine="Public Sub getTitleTextSize As Float";
 //BA.debugLineNum = 2492;BA.debugLine="Return Texts.TitleTextSize";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextSize;
 //BA.debugLineNum = 2493;BA.debugLine="End Sub";
return 0f;
}
public int  _getvvvvvvvvvvvvvvvvvvvvvvvv5() throws Exception{
 //BA.debugLineNum = 2442;BA.debugLine="Public Sub getTop As Int";
 //BA.debugLineNum = 2443;BA.debugLine="Return xBase.Top";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvv6.getTop();
 //BA.debugLineNum = 2444;BA.debugLine="End Sub";
return 0;
}
public float  _getvvvvvvvvvvvvvvvvvvvvvvvv6() throws Exception{
 //BA.debugLineNum = 2539;BA.debugLine="Public Sub getValuesTextSize As Float";
 //BA.debugLineNum = 2540;BA.debugLine="Return Values.TextSize";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextSize;
 //BA.debugLineNum = 2541;BA.debugLine="End Sub";
return 0f;
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvvvvv7() throws Exception{
 //BA.debugLineNum = 2471;BA.debugLine="Public Sub getVisible As Boolean";
 //BA.debugLineNum = 2472;BA.debugLine="Return xBase.Visible";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvv6.getVisible();
 //BA.debugLineNum = 2473;BA.debugLine="End Sub";
return false;
}
public int  _getvvvvvvvvvvvvvvvvvvvvvvvv0() throws Exception{
 //BA.debugLineNum = 2451;BA.debugLine="Public Sub getWidth As Int";
 //BA.debugLineNum = 2452;BA.debugLine="Return xBase.Width";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvv6.getWidth();
 //BA.debugLineNum = 2453;BA.debugLine="End Sub";
return 0;
}
public String  _getvvvvvvvvvvvvvvvvvvvvvvvvv1() throws Exception{
 //BA.debugLineNum = 2296;BA.debugLine="Public Sub getXAxisName As String";
 //BA.debugLineNum = 2297;BA.debugLine="Return Graph.XAxisName";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XAxisName;
 //BA.debugLineNum = 2298;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvvvvvvvv6() throws Exception{
int _i = 0;
cmarsoft.recu.xchart._pointdata _pd = null;
 //BA.debugLineNum = 2059;BA.debugLine="Private Sub GetXIntervals";
 //BA.debugLineNum = 2060;BA.debugLine="Private I As Int";
_i = 0;
 //BA.debugLineNum = 2062;BA.debugLine="Scale(sX).Scale = Graph.Width / (Points.Size - 1)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width/(double)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
 //BA.debugLineNum = 2064;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step3 = 1;
final int limit3 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit3 ;_i = _i + step3 ) {
 //BA.debugLineNum = 2065;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 2066;BA.debugLine="PD = Points.Get(I)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 2067;BA.debugLine="If PD.ShowTick = True Then";
if (_pd.ShowTick==__c.True) { 
 //BA.debugLineNum = 2068;BA.debugLine="Scale(sX).NbIntervals = Scale(sX).NbIntervals +";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].NbIntervals = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].NbIntervals+1);
 };
 }
};
 //BA.debugLineNum = 2071;BA.debugLine="Scale(sX).Scale = Graph.Width / (Points.Size - 1)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width/(double)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
 //BA.debugLineNum = 2072;BA.debugLine="End Sub";
return "";
}
public double  _getvvvvvvvvvvvvvvvvvvvvvvvvv2() throws Exception{
 //BA.debugLineNum = 2343;BA.debugLine="Public Sub getXScaleMaxValue As Double";
 //BA.debugLineNum = 2344;BA.debugLine="Return Scale(sX).MaxVal";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MaxVal;
 //BA.debugLineNum = 2345;BA.debugLine="End Sub";
return 0;
}
public double  _getvvvvvvvvvvvvvvvvvvvvvvvvv3() throws Exception{
 //BA.debugLineNum = 2357;BA.debugLine="Public Sub getXScaleMinValue As Double";
 //BA.debugLineNum = 2358;BA.debugLine="Return Scale(sX).MinVal";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal;
 //BA.debugLineNum = 2359;BA.debugLine="End Sub";
return 0;
}
public String  _getvvvvvvvvvvvvvvvvvvvvvvvvv4() throws Exception{
 //BA.debugLineNum = 2410;BA.debugLine="Public Sub getXScaleTextOrientation As String";
 //BA.debugLineNum = 2411;BA.debugLine="Return Graph.XScaleTextOrientation";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XScaleTextOrientation;
 //BA.debugLineNum = 2412;BA.debugLine="End Sub";
return "";
}
public int  _vvvvvvvvvvvvv2() throws Exception{
int _width = 0;
int _i = 0;
cmarsoft.recu.xchart._pointdata _pd = null;
 //BA.debugLineNum = 1146;BA.debugLine="Private Sub GetXScaleWidth As Int";
 //BA.debugLineNum = 1147;BA.debugLine="Private Width As Int";
_width = 0;
 //BA.debugLineNum = 1149;BA.debugLine="If Graph.ChartType = \"YX_CHART\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("YX_CHART")) { 
 //BA.debugLineNum = 1150;BA.debugLine="If Scale(sY).Automatic = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Automatic==__c.True) { 
 //BA.debugLineNum = 1151;BA.debugLine="Width = MeasureTextWidth(NumberFormat3(Scale(sX";
_width = _vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MaxVal,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont);
 //BA.debugLineNum = 1152;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberForma";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 //BA.debugLineNum = 1153;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberForma";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Interval,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 }else {
 //BA.debugLineNum = 1155;BA.debugLine="Width = MeasureTextWidth(NumberFormat3(Scale(sX";
_width = _vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MaxVal,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont);
 //BA.debugLineNum = 1156;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberForma";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 //BA.debugLineNum = 1157;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberForma";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Interval,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 //BA.debugLineNum = 1158;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberForma";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Interval,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 //BA.debugLineNum = 1159;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberForma";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Interval,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 };
 }else {
 //BA.debugLineNum = 1162;BA.debugLine="For i = 0 To Points.Size - 1";
{
final int step15 = 1;
final int limit15 = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit15 ;_i = _i + step15 ) {
 //BA.debugLineNum = 1163;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 1164;BA.debugLine="PD = Points.Get(i)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 1165;BA.debugLine="If Graph.ChartType = \"LINE\" And PD.ShowTick = T";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("LINE") && _pd.ShowTick==__c.True) { 
 //BA.debugLineNum = 1166;BA.debugLine="Width = Max(Width, MeasureTextWidth(PD.X, Text";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_pd.X,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 }else {
 //BA.debugLineNum = 1168;BA.debugLine="Width = Max(Width, MeasureTextWidth(PD.X, Text";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_pd.X,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 };
 }
};
 };
 //BA.debugLineNum = 1172;BA.debugLine="Return Width";
if (true) return _width;
 //BA.debugLineNum = 1173;BA.debugLine="End Sub";
return 0;
}
public String  _getvvvvvvvvvvvvvvvvvvvvvvvvv5() throws Exception{
 //BA.debugLineNum = 2305;BA.debugLine="Public Sub getYAxisName As String";
 //BA.debugLineNum = 2306;BA.debugLine="Return Graph.YAxisName";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.YAxisName;
 //BA.debugLineNum = 2307;BA.debugLine="End Sub";
return "";
}
public double  _getvvvvvvvvvvvvvvvvvvvvvvvvv6() throws Exception{
 //BA.debugLineNum = 2316;BA.debugLine="Public Sub getYScaleMaxValue As Double";
 //BA.debugLineNum = 2317;BA.debugLine="Return Scale(sY).MaxVal";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal;
 //BA.debugLineNum = 2318;BA.debugLine="End Sub";
return 0;
}
public double  _getvvvvvvvvvvvvvvvvvvvvvvvvv7() throws Exception{
 //BA.debugLineNum = 2329;BA.debugLine="Public Sub getYScaleMinValue As Double";
 //BA.debugLineNum = 2330;BA.debugLine="Return Scale(sY).MinVal";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal;
 //BA.debugLineNum = 2331;BA.debugLine="End Sub";
return 0;
}
public int  _vvvvvvvvvvvvv6() throws Exception{
int _width = 0;
int _i = 0;
 //BA.debugLineNum = 1176;BA.debugLine="Private Sub GetYScaleWidth As Int";
 //BA.debugLineNum = 1177;BA.debugLine="Private Width As Int";
_width = 0;
 //BA.debugLineNum = 1179;BA.debugLine="If Scale(sY).Automatic = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Automatic==__c.True) { 
 //BA.debugLineNum = 1184;BA.debugLine="Width = MeasureTextWidth(NumberFormat3(Scale(sY)";
_width = _vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont);
 //BA.debugLineNum = 1185;BA.debugLine="For i = 1 To Scale(sY).NbIntervals";
{
final int step4 = 1;
final int limit4 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].NbIntervals;
_i = (int) (1) ;
for (;_i <= limit4 ;_i = _i + step4 ) {
 //BA.debugLineNum = 1187;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberForma";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal+_i*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].IntervalAuto,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 }
};
 }else {
 //BA.debugLineNum = 1190;BA.debugLine="Width = MeasureTextWidth(NumberFormat3(Scale(sY)";
_width = _vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont);
 //BA.debugLineNum = 1191;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberFormat";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 //BA.debugLineNum = 1192;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberFormat";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Interval,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 //BA.debugLineNum = 1193;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberFormat";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal-_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Interval,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 //BA.debugLineNum = 1194;BA.debugLine="Width = Max(Width, MeasureTextWidth(NumberFormat";
_width = (int) (__c.Max(_width,_vvvvvvvvvvvvvv3(_vvvvvvvvvvvvvv4(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal+_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Interval,(int) (6)),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont)));
 };
 //BA.debugLineNum = 1196;BA.debugLine="Return Width";
if (true) return _width;
 //BA.debugLineNum = 1197;BA.debugLine="End Sub";
return 0;
}
public boolean  _getvvvvvvvvvvvvvvvvvvvvvvvvv0() throws Exception{
 //BA.debugLineNum = 2684;BA.debugLine="Public Sub getYZeroAxis As Boolean";
 //BA.debugLineNum = 2685;BA.debugLine="Return Scale(sY).YZeroAxis";
if (true) return _vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].YZeroAxis;
 //BA.debugLineNum = 2686;BA.debugLine="End Sub";
return false;
}
public String  _vvvvvvvvvvvvv0() throws Exception{
int _graphsize = 0;
cmarsoft.recu.xchart._pointdata _pd = null;
int _space = 0;
int _limit = 0;
 //BA.debugLineNum = 705;BA.debugLine="Private Sub InitChart";
 //BA.debugLineNum = 706;BA.debugLine="If Texts.AutomaticTextSizes = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AutomaticTextSizes==__c.True) { 
 //BA.debugLineNum = 707;BA.debugLine="Private GraphSize As Int";
_graphsize = 0;
 //BA.debugLineNum = 708;BA.debugLine="GraphSize = Min(xcvsGraph.TargetRect.Width, xcvs";
_graphsize = (int) (__c.Min(_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth(),_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getHeight())/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.getScale());
 //BA.debugLineNum = 709;BA.debugLine="Texts.TitleTextSize = (1 + (GraphSize - 250)/100";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextSize = (float) ((1+(_graphsize-250)/(double)1000)*18);
 //BA.debugLineNum = 710;BA.debugLine="Texts.SubtitleTextSize = (1 + (GraphSize - 250)/";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextSize = (float) ((1+(_graphsize-250)/(double)1000)*16);
 //BA.debugLineNum = 711;BA.debugLine="Texts.AxisTextSize = (1 + (GraphSize - 250)/1000";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextSize = (float) ((1+(_graphsize-250)/(double)1000)*14);
 //BA.debugLineNum = 712;BA.debugLine="Legend.TextSize = (1 + (GraphSize - 250)/1000) *";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextSize = (float) ((1+(_graphsize-250)/(double)1000)*14);
 //BA.debugLineNum = 713;BA.debugLine="Texts.ScaleTextSize = (1 + (GraphSize - 250)/100";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextSize = (float) ((1+(_graphsize-250)/(double)1000)*12);
 //BA.debugLineNum = 714;BA.debugLine="Values.TextSize = (1 + (GraphSize - 250)/1000) *";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextSize = (float) ((1+(_graphsize-250)/(double)1000)*14);
 };
 //BA.debugLineNum = 717;BA.debugLine="Texts.TitleFont = xui.CreateDefaultFont(Texts.Tit";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextSize);
 //BA.debugLineNum = 718;BA.debugLine="Texts.SubtitleFont = xui.CreateDefaultFont(Texts.";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextSize);
 //BA.debugLineNum = 719;BA.debugLine="Texts.AxisFont = xui.CreateDefaultFont(Texts.Axis";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextSize);
 //BA.debugLineNum = 720;BA.debugLine="Texts.ScaleFont = xui.CreateDefaultFont(Texts.Sca";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextSize);
 //BA.debugLineNum = 721;BA.debugLine="Legend.TextFont = xui.CreateDefaultFont(Legend.Te";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextSize);
 //BA.debugLineNum = 722;BA.debugLine="Values.TextFont = xui.CreateDefaultFont(Values.Te";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextSize);
 //BA.debugLineNum = 724;BA.debugLine="Texts.TitleTextHeight = MeasureTextHeight(\"Mg\", T";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextHeight = _vvvvvvvvvvvvvv2("Mg",_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleFont);
 //BA.debugLineNum = 725;BA.debugLine="Texts.SubtitleTextHeight = MeasureTextHeight(\"Mg\"";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextHeight = _vvvvvvvvvvvvvv2("Mg",_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleFont);
 //BA.debugLineNum = 726;BA.debugLine="Texts.AxisTextHeight = MeasureTextHeight(\"Mg\", Te";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextHeight = _vvvvvvvvvvvvvv2("Mg",_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisFont);
 //BA.debugLineNum = 727;BA.debugLine="Texts.ScaleTextHeight = MeasureTextHeight(\"Mg\", T";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight = _vvvvvvvvvvvvvv2("Mg",_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont);
 //BA.debugLineNum = 728;BA.debugLine="Legend.TextHeight = MeasureTextHeight(\"Mg\", Legen";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight = _vvvvvvvvvvvvvv2("Mg",_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextFont);
 //BA.debugLineNum = 729;BA.debugLine="Values.TextHeight = MeasureTextHeight(\"Mg\", Value";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight = _vvvvvvvvvvvvvv2("Mg",_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont);
 //BA.debugLineNum = 731;BA.debugLine="If Graph.ChartType = \"PIE\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("PIE")) { 
 //BA.debugLineNum = 732;BA.debugLine="Graph.Height = xcvsGraph.TargetRect.Height";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getHeight());
 //BA.debugLineNum = 733;BA.debugLine="If Legend.IncludeLegend = \"BOTTOM\" And Items.Siz";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend).equals("BOTTOM") && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()>0) { 
 //BA.debugLineNum = 734;BA.debugLine="GetLegendLineNumbers(xcvsGraph.TargetRect.Width";
_vvvvvvvvvv2((int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth()-0.8*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight));
 //BA.debugLineNum = 735;BA.debugLine="Legend.Height = (Legend.LineNumber + 0.2) * Leg";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.Height = (int) ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumber+0.2)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 //BA.debugLineNum = 736;BA.debugLine="Graph.Height = Graph.Height - Legend.Height - 0";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.Height-0.5*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 };
 //BA.debugLineNum = 738;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 741;BA.debugLine="If Scale(sY).Automatic = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Automatic==__c.True) { 
 //BA.debugLineNum = 742;BA.debugLine="CalcScaleAuto(sY)";
_vvvvv7(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6);
 //BA.debugLineNum = 743;BA.debugLine="If Graph.ChartType = \"YX_CHART\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("YX_CHART")) { 
 //BA.debugLineNum = 744;BA.debugLine="CalcScaleAuto(sX)";
_vvvvv7(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7);
 };
 }else {
 //BA.debugLineNum = 747;BA.debugLine="CalcScaleManu(sY)";
_vvvvv0(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6);
 //BA.debugLineNum = 748;BA.debugLine="CalcScaleManu(sX)";
_vvvvv0(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7);
 };
 //BA.debugLineNum = 751;BA.debugLine="Graph.Left = GetYScaleWidth + 0.7 * Texts.ScaleTe";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left = (int) (_vvvvvvvvvvvvv6()+0.7*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 753;BA.debugLine="If Graph.YAxisName <> \"\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.YAxisName).equals("") == false) { 
 //BA.debugLineNum = 754;BA.debugLine="Graph.Left = Graph.Left + Texts.AxisTextHeight *";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextHeight*1.2);
 };
 //BA.debugLineNum = 757;BA.debugLine="Graph.Right = xcvsGraph.TargetRect.Width - Texts.";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth()-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 //BA.debugLineNum = 758;BA.debugLine="Graph.Width = Graph.Right - Graph.Left";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left);
 //BA.debugLineNum = 759;BA.debugLine="If Graph.ChartType = \"YX_CHART\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("YX_CHART")) { 
 //BA.debugLineNum = 760;BA.debugLine="Graph.Width = Floor(Graph.Width / Scale(sX).NbIn";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width = (int) (__c.Floor(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].NbIntervals)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].NbIntervals);
 //BA.debugLineNum = 761;BA.debugLine="Graph.Right = Graph.Left + Graph.Width";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width);
 };
 //BA.debugLineNum = 764;BA.debugLine="If Graph.ChartType = \"BAR\" Or Graph.ChartType = \"";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("BAR") || (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("STACKED_BAR")) { 
 //BA.debugLineNum = 765;BA.debugLine="BarWidth0 = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = __c.False;
 //BA.debugLineNum = 766;BA.debugLine="Private PD As PointData = Points.Get(0)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get((int) (0)));
 //BA.debugLineNum = 767;BA.debugLine="Private Space = 0.02 * xcvsGraph.TargetRect.Widt";
_space = (int) (0.02*_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth());
 //BA.debugLineNum = 768;BA.debugLine="Graph.XInterval = (Graph.Width - Space) / Points";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval = (int) ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width-_space)/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize());
 //BA.debugLineNum = 770;BA.debugLine="If Space > 0.3 * Graph.XInterval Then";
if (_space>0.3*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval) { 
 //BA.debugLineNum = 771;BA.debugLine="Space = 0.3 * Graph.XInterval";
_space = (int) (0.3*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval);
 //BA.debugLineNum = 772;BA.debugLine="Graph.XInterval = (Graph.Width - Space) / Point";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval = (int) ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width-_space)/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize());
 };
 //BA.debugLineNum = 775;BA.debugLine="Private Limit As Int";
_limit = 0;
 //BA.debugLineNum = 776;BA.debugLine="If Graph.ChartType = \"BAR\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("BAR")) { 
 //BA.debugLineNum = 777;BA.debugLine="Limit = 4dip * PD.YArray.Length";
_limit = (int) (__c.DipToCurrent((int) (4))*_pd.YArray.length);
 }else {
 //BA.debugLineNum = 779;BA.debugLine="Limit = 4dip";
_limit = __c.DipToCurrent((int) (4));
 };
 //BA.debugLineNum = 784;BA.debugLine="If Graph.XInterval - Space < Limit Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval-_space<_limit) { 
 //BA.debugLineNum = 785;BA.debugLine="Log(\"Bar width = too small !!! Drawing of Bar c";
__c.LogImpl("92752592","Bar width = too small !!! Drawing of Bar chart skipped",0);
 //BA.debugLineNum = 786;BA.debugLine="BarWidth0 = True";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = __c.True;
 };
 //BA.debugLineNum = 789;BA.debugLine="Graph.XOffset = (Graph.Width - Graph.XInterval *";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XOffset = (int) ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Width-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getSize())/(double)2);
 //BA.debugLineNum = 790;BA.debugLine="Graph.BarWidth = Graph.XInterval - Space";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarWidth = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XInterval-_space);
 //BA.debugLineNum = 791;BA.debugLine="Graph.BarSubWidth = Graph.BarWidth / PD.YArray.L";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarSubWidth = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarWidth/(double)_pd.YArray.length);
 //BA.debugLineNum = 793;BA.debugLine="If Graph.ChartType = \"BAR\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("BAR")) { 
 //BA.debugLineNum = 795;BA.debugLine="If Graph.BarSubWidth < 4dip And BarWidth0 = Fal";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarSubWidth<__c.DipToCurrent((int) (4)) && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1==__c.False) { 
 //BA.debugLineNum = 796;BA.debugLine="Log(\"Bar width = too small !!! Drawing of Bar";
__c.LogImpl("92752603","Bar width = too small !!! Drawing of Bar chart skipped",0);
 //BA.debugLineNum = 797;BA.debugLine="BarWidth0 = True";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = __c.True;
 };
 };
 };
 //BA.debugLineNum = 802;BA.debugLine="If Graph.Title <> \"\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Title).equals("") == false) { 
 //BA.debugLineNum = 803;BA.debugLine="Graph.Top = 1.2 * Texts.TitleTextHeight";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top = (int) (1.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextHeight);
 }else {
 //BA.debugLineNum = 805;BA.debugLine="Graph.Top = 0.6 * Texts.TitleTextHeight";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top = (int) (0.6*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextHeight);
 };
 //BA.debugLineNum = 808;BA.debugLine="If Graph.Subtitle <> \"\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Subtitle).equals("") == false) { 
 //BA.debugLineNum = 809;BA.debugLine="Graph.Top = Graph.Top + Texts.SubtitleTextHeight";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextHeight);
 };
 //BA.debugLineNum = 812;BA.debugLine="Select Graph.XScaleTextOrientation";
switch (BA.switchObjectToInt(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XScaleTextOrientation,"HORIZONTAL","VERTICAL","45 DEGREES")) {
case 0: {
 //BA.debugLineNum = 814;BA.debugLine="Graph.Height = xcvsGraph.TargetRect.Height - Gr";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getHeight()-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top-1.4*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight);
 break; }
case 1: {
 //BA.debugLineNum = 816;BA.debugLine="Graph.Height = xcvsGraph.TargetRect.Height - Gr";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getHeight()-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top-0.6*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight-_vvvvvvvvvvvvv2());
 break; }
case 2: {
 //BA.debugLineNum = 818;BA.debugLine="Graph.Height = xcvsGraph.TargetRect.Height - Gr";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getHeight()-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top-0.6*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextHeight-_vvvvvvvvvvvvv2()*0.8);
 break; }
}
;
 //BA.debugLineNum = 820;BA.debugLine="If Graph.XAxisName <> \"\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XAxisName).equals("") == false) { 
 //BA.debugLineNum = 821;BA.debugLine="Graph.Height = Graph.Height - 0.85 * Texts.AxisT";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height-0.85*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextHeight);
 };
 //BA.debugLineNum = 824;BA.debugLine="If Legend.IncludeLegend = \"BOTTOM\" And Items.Size";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend).equals("BOTTOM") && _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()>0) { 
 //BA.debugLineNum = 825;BA.debugLine="GetLegendLineNumbers(xcvsGraph.TargetRect.Width";
_vvvvvvvvvv2((int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvv7.getTargetRect().getWidth()-0.8*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight));
 //BA.debugLineNum = 826;BA.debugLine="Legend.Height = (Legend.LineNumber + 0.2) * Lege";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.Height = (int) ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineNumber+0.2)*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 //BA.debugLineNum = 827;BA.debugLine="Graph.Height = Graph.Height - Legend.Height - 0.";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.Height-0.5*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextHeight);
 };
 //BA.debugLineNum = 830;BA.debugLine="Graph.YInterval = Graph.Height / Scale(sY).NbInte";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.YInterval = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].NbIntervals);
 //BA.debugLineNum = 831;BA.debugLine="Graph.Height =  Graph.YInterval * Scale(sY).NbInt";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.YInterval*_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].NbIntervals);
 //BA.debugLineNum = 832;BA.debugLine="Graph.Bottom = Graph.Top + Graph.Height";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Height);
 //BA.debugLineNum = 833;BA.debugLine="Graph.Rect.Initialize(Graph.Left, Graph.Top, Grap";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Rect.Initialize((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom));
 //BA.debugLineNum = 836;BA.debugLine="pthGrid.Initialize(Graph.Left, Graph.Top)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv4.Initialize((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top));
 //BA.debugLineNum = 837;BA.debugLine="pthGrid.LineTo(Graph.Right, Graph.Top)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineTo((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top));
 //BA.debugLineNum = 838;BA.debugLine="pthGrid.LineTo(Graph.Right, Graph.Bottom)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineTo((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom));
 //BA.debugLineNum = 839;BA.debugLine="pthGrid.LineTo(Graph.Left, Graph.Bottom)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineTo((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom));
 //BA.debugLineNum = 840;BA.debugLine="pthGrid.LineTo(Graph.Left, Graph.Top)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv4.LineTo((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top));
 //BA.debugLineNum = 842;BA.debugLine="InitValues";
_vvvvvvvvvvvvvv1();
 //BA.debugLineNum = 843;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 209;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 210;BA.debugLine="mEventName = EventName";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv4 = _eventname;
 //BA.debugLineNum = 211;BA.debugLine="mCallBack = Callback";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv5 = _callback;
 //BA.debugLineNum = 212;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvvvvvvvvvv1() throws Exception{
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _r = null;
int _linenumber = 0;
cmarsoft.recu.xchart._pointdata _pd = null;
int _itemwidth = 0;
cmarsoft.recu.xchart._itemdata _item = null;
String _txt = "";
int _valuewidth = 0;
cmarsoft.recu.xchart._pointdata _pnt = null;
int _h = 0;
int _i = 0;
int _x = 0;
int _y = 0;
int _top = 0;
 //BA.debugLineNum = 345;BA.debugLine="Private Sub InitValues";
 //BA.debugLineNum = 346;BA.debugLine="Private r As B4XRect";
_r = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 347;BA.debugLine="Private LineNumber As Int";
_linenumber = 0;
 //BA.debugLineNum = 349;BA.debugLine="Values.Left = 0.3 * Values.TextHeight";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Left = (int) (0.3*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight);
 //BA.debugLineNum = 350;BA.debugLine="Values.Top = 0.3 * Values.TextHeight";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Top = (int) (0.3*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight);
 //BA.debugLineNum = 351;BA.debugLine="Values.MaxDigits = 6";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.MaxDigits = (int) (6);
 //BA.debugLineNum = 353;BA.debugLine="LineNumber = Items.Size + 1";
_linenumber = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()+1);
 //BA.debugLineNum = 354;BA.debugLine="If Graph.ChartType = \"LINE\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("LINE")) { 
 //BA.debugLineNum = 355;BA.debugLine="Private PD As PointData";
_pd = new cmarsoft.recu.xchart._pointdata();
 //BA.debugLineNum = 356;BA.debugLine="PD = Points.Get(0)";
_pd = (cmarsoft.recu.xchart._pointdata)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Get((int) (0)));
 //BA.debugLineNum = 357;BA.debugLine="If PD.YArray.Length = 1 Then";
if (_pd.YArray.length==1) { 
 //BA.debugLineNum = 358;BA.debugLine="If Graph.IncludeMinLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMinLine==__c.True) { 
 //BA.debugLineNum = 359;BA.debugLine="LineNumber = LineNumber + 1";
_linenumber = (int) (_linenumber+1);
 };
 //BA.debugLineNum = 361;BA.debugLine="If Graph.IncludeMaxLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMaxLine==__c.True) { 
 //BA.debugLineNum = 362;BA.debugLine="LineNumber = LineNumber + 1";
_linenumber = (int) (_linenumber+1);
 };
 //BA.debugLineNum = 364;BA.debugLine="If Graph.IncludeMeanLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMeanLine==__c.True) { 
 //BA.debugLineNum = 365;BA.debugLine="LineNumber = LineNumber + 1";
_linenumber = (int) (_linenumber+1);
 };
 };
 };
 //BA.debugLineNum = 369;BA.debugLine="Values.Height = Values.TextHeight * 1.2 * LineNum";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Height = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight*1.2*_linenumber);
 //BA.debugLineNum = 371;BA.debugLine="Private ItemWidth As Int";
_itemwidth = 0;
 //BA.debugLineNum = 372;BA.debugLine="For Each Item As ItemData In Items";
{
final anywheresoftware.b4a.BA.IterableList group24 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0;
final int groupLen24 = group24.getSize()
;int index24 = 0;
;
for (; index24 < groupLen24;index24++){
_item = (cmarsoft.recu.xchart._itemdata)(group24.Get(index24));
 //BA.debugLineNum = 373;BA.debugLine="Private txt As String = Item.Name & \" = \"";
_txt = _item.Name+" = ";
 //BA.debugLineNum = 374;BA.debugLine="ItemWidth = Max(ItemWidth, MeasureTextWidth(txt,";
_itemwidth = (int) (__c.Max(_itemwidth,_vvvvvvvvvvvvvv3(_txt,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont)));
 }
};
 //BA.debugLineNum = 376;BA.debugLine="If Graph.ChartType = \"STACKED_BAR\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("STACKED_BAR")) { 
 //BA.debugLineNum = 377;BA.debugLine="ItemWidth = Max(ItemWidth, MeasureTextWidth(\"Tot";
_itemwidth = (int) (__c.Max(_itemwidth,_vvvvvvvvvvvvvv3("Total = ",_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont)));
 //BA.debugLineNum = 378;BA.debugLine="Values.Height = Values.TextHeight * 1.2 * (Items";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Height = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight*1.2*(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv0.getSize()+2));
 };
 //BA.debugLineNum = 380;BA.debugLine="ItemWidth = ItemWidth + 1.2 * Values.TextHeight";
_itemwidth = (int) (_itemwidth+1.2*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight);
 //BA.debugLineNum = 381;BA.debugLine="Values.MidPont = ItemWidth - 0.6 * Values.TextHei";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.MidPont = (int) (_itemwidth-0.6*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight);
 //BA.debugLineNum = 382;BA.debugLine="Private ValueWidth = MeasureTextWidth(\"-1.23456\",";
_valuewidth = _vvvvvvvvvvvvvv3("-1.23456",_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont);
 //BA.debugLineNum = 383;BA.debugLine="For Each pnt As PointData In Points";
{
final anywheresoftware.b4a.BA.IterableList group35 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1;
final int groupLen35 = group35.getSize()
;int index35 = 0;
;
for (; index35 < groupLen35;index35++){
_pnt = (cmarsoft.recu.xchart._pointdata)(group35.Get(index35));
 //BA.debugLineNum = 384;BA.debugLine="Private txt As String = pnt.X";
_txt = _pnt.X;
 //BA.debugLineNum = 385;BA.debugLine="ValueWidth = Max(ValueWidth, MeasureTextWidth(tx";
_valuewidth = (int) (__c.Max(_valuewidth,_vvvvvvvvvvvvvv3(_txt,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont)));
 }
};
 //BA.debugLineNum = 387;BA.debugLine="Values.Width = ItemWidth + ValueWidth";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Width = (int) (_itemwidth+_valuewidth);
 //BA.debugLineNum = 388;BA.debugLine="Values.rectRight.Initialize(Values.MidPont, 0, Va";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.rectRight.Initialize((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.MidPont),(float) (0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Width),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Height));
 //BA.debugLineNum = 389;BA.debugLine="Values.rectCursor.Initialize(0, 0, 5dip, xpnlCurs";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.rectCursor.Initialize((float) (0),(float) (0),(float) (__c.DipToCurrent((int) (5))),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvv2.getHeight()));
 //BA.debugLineNum = 391;BA.debugLine="xpnlValues.Left = Values.Left";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.setLeft(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Left);
 //BA.debugLineNum = 392;BA.debugLine="xpnlValues.Top = Values.Top";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.setTop(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Top);
 //BA.debugLineNum = 393;BA.debugLine="xpnlValues.Width = Values.Width";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.setWidth(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Width);
 //BA.debugLineNum = 394;BA.debugLine="xpnlValues.Height = Values.Height";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.setHeight(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Height);
 //BA.debugLineNum = 395;BA.debugLine="xcvsValues.Resize(Values.Width, Values.Height)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Resize((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Width),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Height));
 //BA.debugLineNum = 397;BA.debugLine="r.Initialize(0, 0, Values.Width, Values.Height)";
_r.Initialize((float) (0),(float) (0),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Width),(float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Height));
 //BA.debugLineNum = 398;BA.debugLine="xcvsValues.ClearRect(r)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.ClearRect(_r);
 //BA.debugLineNum = 399;BA.debugLine="xcvsValues.DrawRect(r, 0xAAFFFFFF, True, 0)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawRect(_r,(int) (0xaaffffff),__c.True,(float) (0));
 //BA.debugLineNum = 401;BA.debugLine="Private h, i, x, y As Int";
_h = 0;
_i = 0;
_x = 0;
_y = 0;
 //BA.debugLineNum = 402;BA.debugLine="h = Values.TextHeight * 1.2";
_h = (int) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight*1.2);
 //BA.debugLineNum = 403;BA.debugLine="x = Values.MidPont";
_x = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.MidPont;
 //BA.debugLineNum = 404;BA.debugLine="y = 0.8 * Values.TextHeight";
_y = (int) (0.8*_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextHeight);
 //BA.debugLineNum = 405;BA.debugLine="xcvsValues.DrawText(\"x = \", x, y + 0.2 * h, Value";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,"x = ",(float) (_x),(float) (_y+0.2*_h),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"));
 //BA.debugLineNum = 406;BA.debugLine="i = 1";
_i = (int) (1);
 //BA.debugLineNum = 407;BA.debugLine="Private top As Int";
_top = 0;
 //BA.debugLineNum = 408;BA.debugLine="For Each Item As ItemData In Items";
{
final anywheresoftware.b4a.BA.IterableList group57 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv0;
final int groupLen57 = group57.getSize()
;int index57 = 0;
;
for (; index57 < groupLen57;index57++){
_item = (cmarsoft.recu.xchart._itemdata)(group57.Get(index57));
 //BA.debugLineNum = 409;BA.debugLine="top = y + h * i";
_top = (int) (_y+_h*_i);
 //BA.debugLineNum = 410;BA.debugLine="Private txt As String = Item.Name & \" = \"";
_txt = _item.Name+" = ";
 //BA.debugLineNum = 411;BA.debugLine="xcvsValues.DrawText(txt, x, top + 0.2 * h, Value";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,_txt,(float) (_x),(float) (_top+0.2*_h),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_item.Color,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"));
 //BA.debugLineNum = 412;BA.debugLine="i = i + 1";
_i = (int) (_i+1);
 }
};
 //BA.debugLineNum = 415;BA.debugLine="If Graph.ChartType = \"LINE\" And Graph.IncludeMinL";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("LINE") && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMinLine==__c.True) { 
 //BA.debugLineNum = 416;BA.debugLine="If  Graph.IncludeMaxLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMaxLine==__c.True) { 
 //BA.debugLineNum = 417;BA.debugLine="top = top + h";
_top = (int) (_top+_h);
 //BA.debugLineNum = 418;BA.debugLine="xcvsValues.DrawText(\"max = \", x, top + 0.2 * h,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,"max = ",(float) (_x),(float) (_top+0.2*_h),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MaxLineColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"));
 };
 //BA.debugLineNum = 420;BA.debugLine="If  Graph.IncludeMeanLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMeanLine==__c.True) { 
 //BA.debugLineNum = 421;BA.debugLine="top = top + h";
_top = (int) (_top+_h);
 //BA.debugLineNum = 422;BA.debugLine="xcvsValues.DrawText(\"mean = \", x, top + 0.2 * h";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,"mean = ",(float) (_x),(float) (_top+0.2*_h),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MeanLineColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"));
 };
 //BA.debugLineNum = 424;BA.debugLine="If  Graph.IncludeMinLine = True Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMinLine==__c.True) { 
 //BA.debugLineNum = 425;BA.debugLine="top = top + h";
_top = (int) (_top+_h);
 //BA.debugLineNum = 426;BA.debugLine="xcvsValues.DrawText(\"min = \", x, top + 0.2 * h,";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,"min = ",(float) (_x),(float) (_top+0.2*_h),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MinLineColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"));
 };
 };
 //BA.debugLineNum = 430;BA.debugLine="If Graph.ChartType = \"STACKED_BAR\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("STACKED_BAR")) { 
 //BA.debugLineNum = 431;BA.debugLine="Private top As Int = y + h * i";
_top = (int) (_y+_h*_i);
 //BA.debugLineNum = 432;BA.debugLine="Private txt As String = \"Total = \"";
_txt = "Total = ";
 //BA.debugLineNum = 433;BA.debugLine="xcvsValues.DrawText(txt, x, top + 0.2 * h, Value";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.DrawText(ba,_txt,(float) (_x),(float) (_top+0.2*_h),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextColor,BA.getEnumFromString(android.graphics.Paint.Align.class,"RIGHT"));
 };
 //BA.debugLineNum = 436;BA.debugLine="xcvsValues.Invalidate";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Invalidate();
 //BA.debugLineNum = 437;BA.debugLine="End Sub";
return "";
}
public int  _vvvvvvvvvvvvvv2(String _text,anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _font1) throws Exception{
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _rct = null;
 //BA.debugLineNum = 2086;BA.debugLine="Private Sub MeasureTextHeight(Text As String, Font";
 //BA.debugLineNum = 2087;BA.debugLine="Private rct As B4XRect";
_rct = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 2088;BA.debugLine="rct = xcvsCursor.MeasureText(Text, Font1)";
_rct = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.MeasureText(_text,_font1);
 //BA.debugLineNum = 2089;BA.debugLine="Return rct.Width";
if (true) return (int) (_rct.getWidth());
 //BA.debugLineNum = 2091;BA.debugLine="End Sub";
return 0;
}
public int  _vvvvvvvvvvvvvv3(String _text,anywheresoftware.b4a.objects.B4XViewWrapper.B4XFont _font1) throws Exception{
anywheresoftware.b4a.objects.B4XCanvas.B4XRect _rct = null;
 //BA.debugLineNum = 2080;BA.debugLine="Private Sub MeasureTextWidth(Text As String, Font1";
 //BA.debugLineNum = 2081;BA.debugLine="Private rct As B4XRect";
_rct = new anywheresoftware.b4a.objects.B4XCanvas.B4XRect();
 //BA.debugLineNum = 2082;BA.debugLine="rct = xcvsCursor.MeasureText(Text, Font1)";
_rct = _vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.MeasureText(_text,_font1);
 //BA.debugLineNum = 2083;BA.debugLine="Return rct.Width";
if (true) return (int) (_rct.getWidth());
 //BA.debugLineNum = 2084;BA.debugLine="End Sub";
return 0;
}
public String  _vvvvvvvvvvvvvv4(double _number,int _maxdigits) throws Exception{
double _mant = 0;
double _exp = 0;
double _lng = 0;
double _lng2 = 0;
String _str = "";
String _strminus = "";
 //BA.debugLineNum = 2253;BA.debugLine="Public Sub NumberFormat3(Number As Double, MaxDigi";
 //BA.debugLineNum = 2254;BA.debugLine="Private mant, exp, lng, lng2 As Double";
_mant = 0;
_exp = 0;
_lng = 0;
_lng2 = 0;
 //BA.debugLineNum = 2255;BA.debugLine="Private str, strMinus As String";
_str = "";
_strminus = "";
 //BA.debugLineNum = 2257;BA.debugLine="If Abs(Number) < 1e-12 Then Return \"0\"";
if (__c.Abs(_number)<1e-12) { 
if (true) return "0";};
 //BA.debugLineNum = 2259;BA.debugLine="If Number < 0 Then";
if (_number<0) { 
 //BA.debugLineNum = 2260;BA.debugLine="strMinus = \"-\"";
_strminus = "-";
 }else {
 //BA.debugLineNum = 2262;BA.debugLine="strMinus = \"\"";
_strminus = "";
 };
 //BA.debugLineNum = 2264;BA.debugLine="lng = Logarithm(Abs(Number), 10)";
_lng = __c.Logarithm(__c.Abs(_number),10);
 //BA.debugLineNum = 2265;BA.debugLine="exp = Floor(lng)";
_exp = __c.Floor(_lng);
 //BA.debugLineNum = 2266;BA.debugLine="If exp < 0 Then";
if (_exp<0) { 
 //BA.debugLineNum = 2267;BA.debugLine="lng2 = Floor(lng)";
_lng2 = __c.Floor(_lng);
 //BA.debugLineNum = 2268;BA.debugLine="lng = -lng2 + lng";
_lng = -_lng2+_lng;
 }else {
 //BA.debugLineNum = 2270;BA.debugLine="lng = lng - exp";
_lng = _lng-_exp;
 };
 //BA.debugLineNum = 2273;BA.debugLine="If exp < MaxDigits And exp > -5 Then";
if (_exp<_maxdigits && _exp>-5) { 
 //BA.debugLineNum = 2274;BA.debugLine="str = NumberFormat2(Number, 1, MaxDigits - 1 - e";
_str = __c.NumberFormat2(_number,(int) (1),(int) (_maxdigits-1-_exp),(int) (0),__c.False);
 }else if(_exp<=-5 && _exp>-7) { 
 //BA.debugLineNum = 2276;BA.debugLine="str = NumberFormat2(Number, 1, 9, 0, False)";
_str = __c.NumberFormat2(_number,(int) (1),(int) (9),(int) (0),__c.False);
 }else {
 //BA.debugLineNum = 2278;BA.debugLine="mant = Power(10, lng)";
_mant = __c.Power(10,_lng);
 //BA.debugLineNum = 2279;BA.debugLine="str = strMinus & NumberFormat2(mant, 1, MaxDigit";
_str = _strminus+__c.NumberFormat2(_mant,(int) (1),(int) (_maxdigits-1),(int) (0),__c.False);
 //BA.debugLineNum = 2280;BA.debugLine="str = str & \"E\" & exp";
_str = _str+"E"+BA.NumberToString(_exp);
 };
 //BA.debugLineNum = 2283;BA.debugLine="Return str";
if (true) return _str;
 //BA.debugLineNum = 2284;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvvvvvvvvvv5(int _index) throws Exception{
 //BA.debugLineNum = 2757;BA.debugLine="Public Sub RemovePointData(Index As Int)";
 //BA.debugLineNum = 2758;BA.debugLine="Points.RemoveAt(Index)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.RemoveAt(_index);
 //BA.debugLineNum = 2759;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvv0(boolean _automaticscale) throws Exception{
 //BA.debugLineNum = 2403;BA.debugLine="Public Sub setAutomaticScale(AutomaticScale As Boo";
 //BA.debugLineNum = 2404;BA.debugLine="Scale(sY).Automatic = AutomaticScale";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Automatic = _automaticscale;
 //BA.debugLineNum = 2405;BA.debugLine="Scale(sX).Automatic = AutomaticScale";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Automatic = _automaticscale;
 //BA.debugLineNum = 2406;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvv1(boolean _automatictextsizes) throws Exception{
 //BA.debugLineNum = 2485;BA.debugLine="Public Sub setAutomaticTextSizes(AutomaticTextSize";
 //BA.debugLineNum = 2486;BA.debugLine="Texts.AutomaticTextSizes = AutomaticTextSizes";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AutomaticTextSizes = _automatictextsizes;
 //BA.debugLineNum = 2487;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvv2(float _axistextsize) throws Exception{
 //BA.debugLineNum = 2507;BA.debugLine="Public Sub setAxisTextSize(AxisTextSize As Float)";
 //BA.debugLineNum = 2508;BA.debugLine="Texts.AxisTextSize = AxisTextSize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextSize = _axistextsize;
 //BA.debugLineNum = 2509;BA.debugLine="Texts.AxisFont = xui.CreateDefaultFont(Texts.Axis";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AxisTextSize);
 //BA.debugLineNum = 2510;BA.debugLine="Texts.AutomaticTextSizes = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AutomaticTextSizes = __c.False;
 //BA.debugLineNum = 2511;BA.debugLine="End Sub";
return "";
}
public String  _vvvvvvvvvvvvvvv1(int _minimumintegers,int _maximumfractions,int _minimumfractions,boolean _groupingused) throws Exception{
 //BA.debugLineNum = 2764;BA.debugLine="Public Sub SetBarMeanValueFormat(MinimumIntegers A";
 //BA.debugLineNum = 2765;BA.debugLine="BMVNFUsed = True";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv0 = __c.True;
 //BA.debugLineNum = 2766;BA.debugLine="BMVNF.MinimumIntegers = MinimumIntegers";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.MinimumIntegers = _minimumintegers;
 //BA.debugLineNum = 2767;BA.debugLine="BMVNF.MaximumFractions = MaximumFractions";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.MaximumFractions = _maximumfractions;
 //BA.debugLineNum = 2768;BA.debugLine="BMVNF.MinimumFractions = MinimumFractions";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.MinimumFractions = _minimumfractions;
 //BA.debugLineNum = 2769;BA.debugLine="BMVNF.GroupingUsed = GroupingUsed";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv7.GroupingUsed = _groupingused;
 //BA.debugLineNum = 2770;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvv3(String _barvalueorientation) throws Exception{
 //BA.debugLineNum = 2806;BA.debugLine="Public Sub setBarValueOrientation(BarValueOrientat";
 //BA.debugLineNum = 2807;BA.debugLine="If BarValueOrientation = \"HORIZONTAL\" Or BarValue";
if ((_barvalueorientation).equals("HORIZONTAL") || (_barvalueorientation).equals("VERTICAL")) { 
 //BA.debugLineNum = 2808;BA.debugLine="Graph.BarValueOrientation = BarValueOrientation";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.BarValueOrientation = _barvalueorientation;
 }else {
 //BA.debugLineNum = 2810;BA.debugLine="Log(\"Error: wrong BarValueOrientation value\")";
__c.LogImpl("910485764","Error: wrong BarValueOrientation value",0);
 };
 //BA.debugLineNum = 2812;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvvv1(int _color) throws Exception{
 //BA.debugLineNum = 2600;BA.debugLine="Public Sub setChartBackgroundColor(Color As Int)";
 //BA.debugLineNum = 2601;BA.debugLine="Graph.ChartBackgroundColor = Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartBackgroundColor = _color;
 //BA.debugLineNum = 2602;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvv4(String _charttype) throws Exception{
 //BA.debugLineNum = 2424;BA.debugLine="Public Sub setChartType(ChartType As String)";
 //BA.debugLineNum = 2425;BA.debugLine="If ChartType = \"BAR\" Or ChartType = \"STACKED_BAR\"";
if ((_charttype).equals("BAR") || (_charttype).equals("STACKED_BAR") || (_charttype).equals("LINE") || (_charttype).equals("PIE")) { 
 //BA.debugLineNum = 2426;BA.debugLine="Graph.ChartType = ChartType";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType = _charttype;
 }else {
 //BA.debugLineNum = 2428;BA.debugLine="Log(\"Wrong chart type\")";
__c.LogImpl("96160388","Wrong chart type",0);
 };
 //BA.debugLineNum = 2430;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvv5(boolean _displayvalues) throws Exception{
 //BA.debugLineNum = 2555;BA.debugLine="Public Sub setDisplayValues(DisplayValues As Boole";
 //BA.debugLineNum = 2556;BA.debugLine="Values.Show = DisplayValues";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Show = _displayvalues;
 //BA.debugLineNum = 2557;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvv6(boolean _drawouterframe) throws Exception{
 //BA.debugLineNum = 2719;BA.debugLine="Public Sub setDrawOuterFrame (DrawOuterFrame As Bo";
 //BA.debugLineNum = 2720;BA.debugLine="Graph.DrawOuterFrame = DrawOuterFrame";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.DrawOuterFrame = _drawouterframe;
 //BA.debugLineNum = 2721;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvv7(boolean _gradientcolors) throws Exception{
 //BA.debugLineNum = 2580;BA.debugLine="Public Sub setGradientColors(GradientColors As Boo";
 //BA.debugLineNum = 2581;BA.debugLine="Graph.GradientColors = GradientColors";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColors = _gradientcolors;
 //BA.debugLineNum = 2582;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvv0(int _gradientcolorsalpha) throws Exception{
 //BA.debugLineNum = 2591;BA.debugLine="Public Sub setGradientColorsAlpha(GradientColorsAl";
 //BA.debugLineNum = 2592;BA.debugLine="Graph.GradientColorsAlpha = GradientColorsAlpha";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColorsAlpha = _gradientcolorsalpha;
 //BA.debugLineNum = 2593;BA.debugLine="Graph.GradientColorsAlpha = Max(0, Graph.Gradient";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColorsAlpha = (int) (__c.Max(0,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColorsAlpha));
 //BA.debugLineNum = 2594;BA.debugLine="Graph.GradientColorsAlpha = Min(255, Graph.Gradie";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColorsAlpha = (int) (__c.Min(255,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GradientColorsAlpha));
 //BA.debugLineNum = 2595;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvvv2(int _color) throws Exception{
 //BA.debugLineNum = 2614;BA.debugLine="Public Sub setGridColor(Color As Int)";
 //BA.debugLineNum = 2615;BA.debugLine="Graph.GridColor = Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridColor = _color;
 //BA.debugLineNum = 2616;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvvv3(int _color) throws Exception{
 //BA.debugLineNum = 2607;BA.debugLine="Public Sub setGridFrameColor(Color As Int)";
 //BA.debugLineNum = 2608;BA.debugLine="Graph.GridFrameColor = Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.GridFrameColor = _color;
 //BA.debugLineNum = 2609;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvv1(int _height) throws Exception{
 //BA.debugLineNum = 2465;BA.debugLine="Public Sub setHeight(Height As Int)";
 //BA.debugLineNum = 2466;BA.debugLine="xBase.Height = Height";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.setHeight(_height);
 //BA.debugLineNum = 2467;BA.debugLine="DrawChart";
_vvvvvv5();
 //BA.debugLineNum = 2468;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvv2(boolean _includebarmeanline) throws Exception{
 //BA.debugLineNum = 2393;BA.debugLine="Public Sub setIncludeBarMeanLine(IncludeBarMeanLin";
 //BA.debugLineNum = 2394;BA.debugLine="Graph.IncludeBarMeanLine = IncludeBarMeanLine";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeBarMeanLine = _includebarmeanline;
 //BA.debugLineNum = 2395;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvv3(String _includelegend) throws Exception{
 //BA.debugLineNum = 2373;BA.debugLine="Public Sub setIncludeLegend(IncludeLegend As Strin";
 //BA.debugLineNum = 2374;BA.debugLine="Legend.IncludeLegend = IncludeLegend";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.IncludeLegend = _includelegend;
 //BA.debugLineNum = 2375;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvv4(boolean _includemaxline) throws Exception{
 //BA.debugLineNum = 2740;BA.debugLine="Public Sub setIncludeMaxLine (IncludeMaxLine As Bo";
 //BA.debugLineNum = 2741;BA.debugLine="Graph.IncludeMaxLine = IncludeMaxLine";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMaxLine = _includemaxline;
 //BA.debugLineNum = 2743;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvv5(boolean _includemeanline) throws Exception{
 //BA.debugLineNum = 2751;BA.debugLine="Public Sub setIncludeMeanLine (IncludeMeanLine As";
 //BA.debugLineNum = 2752;BA.debugLine="Graph.IncludeMeanLine = IncludeMeanLine";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMeanLine = _includemeanline;
 //BA.debugLineNum = 2754;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvv6(boolean _includeminline) throws Exception{
 //BA.debugLineNum = 2729;BA.debugLine="Public Sub setIncludeMinLine (IncludeMinLine As Bo";
 //BA.debugLineNum = 2730;BA.debugLine="Graph.IncludeMinLine = IncludeMinLine";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeMinLine = _includeminline;
 //BA.debugLineNum = 2732;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvv7(boolean _includevalues) throws Exception{
 //BA.debugLineNum = 2383;BA.debugLine="Public Sub setIncludeValues(IncludeValues As Boole";
 //BA.debugLineNum = 2384;BA.debugLine="Graph.IncludeValues = IncludeValues";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.IncludeValues = _includevalues;
 //BA.debugLineNum = 2385;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvv0(int _left) throws Exception{
 //BA.debugLineNum = 2437;BA.debugLine="Public Sub setLeft(Left As Int)";
 //BA.debugLineNum = 2438;BA.debugLine="xBase.Left = Left";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.setLeft(_left);
 //BA.debugLineNum = 2439;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvv1(float _legendtextsize) throws Exception{
 //BA.debugLineNum = 2531;BA.debugLine="Public Sub setLegendTextSize(LegendTextSize As Flo";
 //BA.debugLineNum = 2532;BA.debugLine="Legend.TextSize = LegendTextSize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextSize = _legendtextsize;
 //BA.debugLineNum = 2533;BA.debugLine="Legend.TextFont = xui.CreateDefaultFont(Legend.Te";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv4.TextSize);
 //BA.debugLineNum = 2534;BA.debugLine="Texts.AutomaticTextSizes = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AutomaticTextSizes = __c.False;
 //BA.debugLineNum = 2535;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvvv4(int _color) throws Exception{
 //BA.debugLineNum = 2649;BA.debugLine="Public Sub setMaxLineColor(Color As Int)";
 //BA.debugLineNum = 2650;BA.debugLine="Graph.MaxLineColor = Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MaxLineColor = _color;
 //BA.debugLineNum = 2651;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvvv5(int _color) throws Exception{
 //BA.debugLineNum = 2656;BA.debugLine="Public Sub setMeanLineColor(Color As Int)";
 //BA.debugLineNum = 2657;BA.debugLine="Graph.MeanLineColor = Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MeanLineColor = _color;
 //BA.debugLineNum = 2658;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvvv6(int _color) throws Exception{
 //BA.debugLineNum = 2642;BA.debugLine="Public Sub setMinLineColor(Color As Int)";
 //BA.debugLineNum = 2643;BA.debugLine="Graph.MinLineColor = Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.MinLineColor = _color;
 //BA.debugLineNum = 2644;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvv3(int _nbxintervals) throws Exception{
 //BA.debugLineNum = 2677;BA.debugLine="Public Sub setNbXIntervals (NbXIntervals As Int)";
 //BA.debugLineNum = 2678;BA.debugLine="Scale(sX).NbIntervals = NbXIntervals";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].NbIntervals = _nbxintervals;
 //BA.debugLineNum = 2679;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvv4(int _nbyintervals) throws Exception{
 //BA.debugLineNum = 2666;BA.debugLine="Public Sub setNbYIntervals (NbYIntervals As Int)";
 //BA.debugLineNum = 2667;BA.debugLine="Scale(sY).NbIntervals = NbYIntervals";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].NbIntervals = _nbyintervals;
 //BA.debugLineNum = 2668;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvv5(double _rotation) throws Exception{
 //BA.debugLineNum = 2708;BA.debugLine="Public Sub setRotation (Rotation As Double)";
 //BA.debugLineNum = 2709;BA.debugLine="Graph.Rotation = Rotation";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Rotation = _rotation;
 //BA.debugLineNum = 2710;BA.debugLine="xBase.Rotation = Graph.Rotation";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.setRotation((float) (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Rotation));
 //BA.debugLineNum = 2711;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvvv7(int _color) throws Exception{
 //BA.debugLineNum = 2628;BA.debugLine="Public Sub setScaleTextColor(Color As Int)";
 //BA.debugLineNum = 2629;BA.debugLine="Texts.ScaleTextColor = Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextColor = _color;
 //BA.debugLineNum = 2630;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvv6(float _scaletextsize) throws Exception{
 //BA.debugLineNum = 2519;BA.debugLine="Public Sub setScaleTextSize(ScaleTextSize As Float";
 //BA.debugLineNum = 2520;BA.debugLine="Texts.ScaleTextSize = ScaleTextSize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextSize = _scaletextsize;
 //BA.debugLineNum = 2521;BA.debugLine="Texts.ScaleFont = xui.CreateDefaultFont(Texts.Sca";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ScaleTextSize);
 //BA.debugLineNum = 2522;BA.debugLine="Texts.AutomaticTextSizes = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AutomaticTextSizes = __c.False;
 //BA.debugLineNum = 2523;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvv7(String _scalevalues) throws Exception{
 //BA.debugLineNum = 2567;BA.debugLine="Public Sub setScaleValues(ScaleValues As String)";
 //BA.debugLineNum = 2568;BA.debugLine="If ScaleValues.StartsWith(\"1!\") = False Or ScaleV";
if (_scalevalues.startsWith("1!")==__c.False || _scalevalues.startsWith("1!")==__c.False) { 
 //BA.debugLineNum = 2569;BA.debugLine="Log(\"Wrong ScaleValues property\")";
__c.LogImpl("97864322","Wrong ScaleValues property",0);
 //BA.debugLineNum = 2570;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 2572;BA.debugLine="Scale(sY).ScaleValues = ScaleValues";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].ScaleValues = _scalevalues;
 //BA.debugLineNum = 2573;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvvv0(int _color) throws Exception{
 //BA.debugLineNum = 2796;BA.debugLine="Public Sub setSubitleTextColor(Color As Int)";
 //BA.debugLineNum = 2797;BA.debugLine="Texts.SubtitleTextColor = Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextColor = _color;
 //BA.debugLineNum = 2798;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvv1(String _subtitle) throws Exception{
 //BA.debugLineNum = 2777;BA.debugLine="Public Sub setSubtitle(Subtitle As String)";
 //BA.debugLineNum = 2778;BA.debugLine="Graph.Subtitle = Subtitle";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Subtitle = _subtitle;
 //BA.debugLineNum = 2779;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvv2(float _subtitletextsize) throws Exception{
 //BA.debugLineNum = 2787;BA.debugLine="Public Sub setSubtitleTextSize(SubtitleTextSize As";
 //BA.debugLineNum = 2788;BA.debugLine="Texts.SubtitleTextSize = SubtitleTextSize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextSize = _subtitletextsize;
 //BA.debugLineNum = 2789;BA.debugLine="Texts.SubtitleFont = xui.CreateDefaultFont(Texts.";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubtitleTextSize);
 //BA.debugLineNum = 2790;BA.debugLine="Texts.AutomaticTextSizes = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AutomaticTextSizes = __c.False;
 //BA.debugLineNum = 2791;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvv3(String _title) throws Exception{
 //BA.debugLineNum = 2291;BA.debugLine="Public Sub setTitle(Title As String)";
 //BA.debugLineNum = 2292;BA.debugLine="Graph.Title = Title";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Title = _title;
 //BA.debugLineNum = 2293;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvvvv1(int _color) throws Exception{
 //BA.debugLineNum = 2621;BA.debugLine="Public Sub setTitleTextColor(Color As Int)";
 //BA.debugLineNum = 2622;BA.debugLine="Texts.TitleTextColor = Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextColor = _color;
 //BA.debugLineNum = 2623;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvv4(float _titletextsize) throws Exception{
 //BA.debugLineNum = 2495;BA.debugLine="Public Sub setTitleTextSize(TitleTextSize As Float";
 //BA.debugLineNum = 2496;BA.debugLine="Texts.TitleTextSize = TitleTextSize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextSize = _titletextsize;
 //BA.debugLineNum = 2497;BA.debugLine="Texts.TitleFont = xui.CreateDefaultFont(Texts.Tit";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.TitleTextSize);
 //BA.debugLineNum = 2498;BA.debugLine="Texts.AutomaticTextSizes = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AutomaticTextSizes = __c.False;
 //BA.debugLineNum = 2499;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvv5(int _top) throws Exception{
 //BA.debugLineNum = 2446;BA.debugLine="Public Sub setTop(Top As Int)";
 //BA.debugLineNum = 2447;BA.debugLine="xBase.Top = Top";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.setTop(_top);
 //BA.debugLineNum = 2448;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvvvv2(int _color) throws Exception{
 //BA.debugLineNum = 2635;BA.debugLine="Public Sub setValuesTextColor(Color As Int)";
 //BA.debugLineNum = 2636;BA.debugLine="Values.TextColor = Color";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextColor = _color;
 //BA.debugLineNum = 2637;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvv6(float _legendtextsize) throws Exception{
 //BA.debugLineNum = 2543;BA.debugLine="Public Sub setValuesTextSize(LegendTextSize As Flo";
 //BA.debugLineNum = 2544;BA.debugLine="Values.TextSize = LegendTextSize";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextSize = _legendtextsize;
 //BA.debugLineNum = 2545;BA.debugLine="Values.TextFont = xui.CreateDefaultFont(Values.Te";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextFont = _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.CreateDefaultFont(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.TextSize);
 //BA.debugLineNum = 2546;BA.debugLine="Texts.AutomaticTextSizes = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv3.AutomaticTextSizes = __c.False;
 //BA.debugLineNum = 2547;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvv7(boolean _visible) throws Exception{
 //BA.debugLineNum = 2475;BA.debugLine="Public Sub setVisible(Visible As Boolean)";
 //BA.debugLineNum = 2476;BA.debugLine="xBase.Visible = Visible";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.setVisible(_visible);
 //BA.debugLineNum = 2477;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvv0(int _width) throws Exception{
 //BA.debugLineNum = 2455;BA.debugLine="Public Sub setWidth(Width As Int)";
 //BA.debugLineNum = 2456;BA.debugLine="xBase.Width = Width";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv6.setWidth(_width);
 //BA.debugLineNum = 2457;BA.debugLine="DrawChart";
_vvvvvv5();
 //BA.debugLineNum = 2458;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvv1(String _xaxisname) throws Exception{
 //BA.debugLineNum = 2300;BA.debugLine="Public Sub setXAxisName(XAxisName As String)";
 //BA.debugLineNum = 2301;BA.debugLine="Graph.XAxisName = XAxisName";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XAxisName = _xaxisname;
 //BA.debugLineNum = 2302;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvv2(double _xscalemaxvalue) throws Exception{
 //BA.debugLineNum = 2347;BA.debugLine="Public Sub setXScaleMaxValue(XScaleMaxValue As Dou";
 //BA.debugLineNum = 2348;BA.debugLine="Scale(sX).MaxManu = XScaleMaxValue";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MaxManu = _xscalemaxvalue;
 //BA.debugLineNum = 2349;BA.debugLine="Scale(sX).MaxVal = XScaleMaxValue";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MaxVal = _xscalemaxvalue;
 //BA.debugLineNum = 2350;BA.debugLine="Scale(sX).Automatic = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Automatic = __c.False;
 //BA.debugLineNum = 2351;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvv3(double _xscaleminvalue) throws Exception{
 //BA.debugLineNum = 2361;BA.debugLine="Public Sub setXScaleMinValue(XScaleMinValue As Dou";
 //BA.debugLineNum = 2362;BA.debugLine="Scale(sX).MinManu = XScaleMinValue";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinManu = _xscaleminvalue;
 //BA.debugLineNum = 2363;BA.debugLine="Scale(sX).MinVal = XScaleMinValue";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal = _xscaleminvalue;
 //BA.debugLineNum = 2364;BA.debugLine="Scale(sX).Automatic = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Automatic = __c.False;
 //BA.debugLineNum = 2365;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvv4(String _xscaletextorientation) throws Exception{
 //BA.debugLineNum = 2414;BA.debugLine="Public Sub setXScaleTextOrientation(XScaleTextOrie";
 //BA.debugLineNum = 2415;BA.debugLine="Graph.XScaleTextOrientation = XScaleTextOrientati";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.XScaleTextOrientation = _xscaletextorientation;
 //BA.debugLineNum = 2416;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvv5(String _yaxisname) throws Exception{
 //BA.debugLineNum = 2309;BA.debugLine="Public Sub setYAxisName(YAxisName As String)";
 //BA.debugLineNum = 2310;BA.debugLine="Graph.YAxisName = YAxisName";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.YAxisName = _yaxisname;
 //BA.debugLineNum = 2311;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvv6(double _yscalemaxvalue) throws Exception{
 //BA.debugLineNum = 2320;BA.debugLine="Public Sub setYScaleMaxValue(YScaleMaxValue As Dou";
 //BA.debugLineNum = 2321;BA.debugLine="Scale(sY).MaxManu = YScaleMaxValue";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxManu = _yscalemaxvalue;
 //BA.debugLineNum = 2322;BA.debugLine="Scale(sY).MaxVal = YScaleMaxValue";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal = _yscalemaxvalue;
 //BA.debugLineNum = 2323;BA.debugLine="Scale(sY).Automatic = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Automatic = __c.False;
 //BA.debugLineNum = 2324;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvv7(double _yscaleminvalue) throws Exception{
 //BA.debugLineNum = 2333;BA.debugLine="Public Sub setYScaleMinValue(YScaleMinValue As Dou";
 //BA.debugLineNum = 2334;BA.debugLine="Scale(sY).MinManu = YScaleMinValue";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinManu = _yscaleminvalue;
 //BA.debugLineNum = 2335;BA.debugLine="Scale(sY).MinVal = YScaleMinValue";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MinVal = _yscaleminvalue;
 //BA.debugLineNum = 2336;BA.debugLine="Scale(sY).Automatic = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Automatic = __c.False;
 //BA.debugLineNum = 2337;BA.debugLine="End Sub";
return "";
}
public String  _setvvvvvvvvvvvvvvvvvvvvvvvvv0(boolean _yzeroaxis) throws Exception{
 //BA.debugLineNum = 2688;BA.debugLine="Public Sub setYZeroAxis (YZeroAxis As Boolean)";
 //BA.debugLineNum = 2689;BA.debugLine="Scale(sY).YZeroAxis = YZeroAxis";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].YZeroAxis = _yzeroaxis;
 //BA.debugLineNum = 2690;BA.debugLine="End Sub";
return "";
}
public String  _xpnlcursor_touch(int _action,float _x,float _y) throws Exception{
 //BA.debugLineNum = 309;BA.debugLine="Private Sub xpnlCursor_Touch (Action As Int, X As";
 //BA.debugLineNum = 310;BA.debugLine="If Graph.ChartType = \"YX_CHART\" Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("YX_CHART")) { 
 //BA.debugLineNum = 311;BA.debugLine="If (Action = 0 Or Action = 2) And X > Graph.Left";
if ((_action==0 || _action==2) && _x>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left && _x<_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right && _y>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top && _y<_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom && _vvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubExists(ba,_vvvvvvvvvvvvvvvvvvvvvvvvvvv5,_vvvvvvvvvvvvvvvvvvvvvvvvvvv4+"_Touch",(int) (2))) { 
 //BA.debugLineNum = 312;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_Touc";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvv3.SubExists(ba,_vvvvvvvvvvvvvvvvvvvvvvvvvvv5,_vvvvvvvvvvvvvvvvvvvvvvvvvvv4+"_Touch",(int) (2))) { 
 //BA.debugLineNum = 313;BA.debugLine="CallSubDelayed3(mCallBack, mEventName & \"_Touc";
__c.CallSubDelayed3(ba,_vvvvvvvvvvvvvvvvvvvvvvvvvvv5,_vvvvvvvvvvvvvvvvvvvvvvvvvvv4+"_Touch",(Object)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].MinVal+(_x-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left)/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv7].Scale),(Object)(_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].MaxVal-(_y-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top)/(double)_vvvvvvvvvvvvvvvvvvvvvvvvvvvv5[_vvvvvvvvvvvvvvvvvvvvvvvvvvvv6].Scale));
 };
 };
 };
 //BA.debugLineNum = 319;BA.debugLine="If Values.Show = False Or Graph.ChartType = \"PIE\"";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.Show==__c.False || (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("PIE") || (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.ChartType).equals("YX_CHART")) { 
 //BA.debugLineNum = 321;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 324;BA.debugLine="Select Action";
switch (_action) {
case 0: {
 //BA.debugLineNum = 326;BA.debugLine="If X > Graph.Left And X < Graph.Right And Y > G";
if (_x>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left && _x<_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right && _y>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top && _y<_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom) { 
 //BA.debugLineNum = 327;BA.debugLine="DrawItemValues(X, Y)";
_vvvvvv7((int) (_x),(int) (_y));
 //BA.debugLineNum = 328;BA.debugLine="xpnlValues.Visible = True";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.setVisible(__c.True);
 };
 break; }
case 1: {
 //BA.debugLineNum = 331;BA.debugLine="xpnlValues.Visible = False";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.setVisible(__c.False);
 //BA.debugLineNum = 332;BA.debugLine="xcvsCursor.ClearRect(Values.rectCursor)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.ClearRect(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv5.rectCursor);
 //BA.debugLineNum = 333;BA.debugLine="xcvsCursor.Invalidate";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvv3.Invalidate();
 break; }
case 2: {
 //BA.debugLineNum = 335;BA.debugLine="If xpnlValues.Visible = False Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.getVisible()==__c.False) { 
 //BA.debugLineNum = 336;BA.debugLine="xpnlValues.Visible = True";
_vvvvvvvvvvvvvvvvvvvvvvvvvvv0.setVisible(__c.True);
 };
 //BA.debugLineNum = 339;BA.debugLine="If X > Graph.Left And X < Graph.Right And Y > G";
if (_x>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Left && _x<_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Right && _y>_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Top && _y<_vvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.Bottom) { 
 //BA.debugLineNum = 340;BA.debugLine="DrawItemValues(X, Y)";
_vvvvvv7((int) (_x),(int) (_y));
 };
 break; }
}
;
 //BA.debugLineNum = 343;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
