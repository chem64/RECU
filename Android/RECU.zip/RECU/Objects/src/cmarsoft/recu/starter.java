package cmarsoft.recu;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class starter extends  android.app.Service{
	public static class starter_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (starter) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, starter.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, true, BA.class);
		}

	}
    static starter mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return starter.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "cmarsoft.recu", "cmarsoft.recu.starter");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "cmarsoft.recu.starter", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!true && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (starter) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (true) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (starter) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_NOT_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (true)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (starter) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (true) {
            BA.LogInfo("** Service (starter) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (starter) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.phone.Phone.PhoneWakeState _v5 = null;
public static boolean _v6 = false;
public static cmarsoft.recu.starter._ecutype _v7 = null;
public static boolean _buffer_4cyl = false;
public static double _o2_sum = 0;
public static double _o2_count = 0;
public static String _v0 = "";
public static long _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4 = 0L;
public static long _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = 0L;
public static boolean _vv1 = false;
public static int _vv2 = 0;
public static String _vv3 = "";
public static boolean _vv4 = false;
public static boolean _vv5 = false;
public static boolean _vv6 = false;
public static boolean _vv7 = false;
public static anywheresoftware.b4a.objects.Serial _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = null;
public static anywheresoftware.b4a.objects.Serial.BluetoothAdmin _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv0 = null;
public static anywheresoftware.b4a.randomaccessfile.AsyncStreams _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv6 = null;
public static boolean _vv0 = false;
public static boolean _vvv1 = false;
public static boolean _vvv2 = false;
public static boolean _vvv3 = false;
public cmarsoft.recu.main _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2 = null;
public cmarsoft.recu.utility _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4 = null;
public cmarsoft.recu.chart _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = null;
public cmarsoft.recu.setup _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv6 = null;
public static class _ecutype{
public boolean IsInitialized;
public double MAP;
public double CTS;
public double IAT;
public double O2;
public double O2AVG;
public double TPS;
public long RPM;
public double INJ;
public double VAC;
public int SPK;
public double STFT;
public double LTFT;
public String ECUMode;
public String O2State;
public String EGR;
public double VOLT;
public String PROG;
public String THROT;
public double TOFT;
public void Initialize() {
IsInitialized = true;
MAP = 0;
CTS = 0;
IAT = 0;
O2 = 0;
O2AVG = 0;
TPS = 0;
RPM = 0L;
INJ = 0;
VAC = 0;
SPK = 0;
STFT = 0;
LTFT = 0;
ECUMode = "";
O2State = "";
EGR = "";
VOLT = 0;
PROG = "";
THROT = "";
TOFT = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _admin_devicefound(String _name,String _macaddress) throws Exception{
 //BA.debugLineNum = 140;BA.debugLine="Private Sub admin_DeviceFound (Name As String, Mac";
 //BA.debugLineNum = 141;BA.debugLine="Utility.WriteLog($\"Device found: ${Name}\"$)";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvvv3(processBA,("Device found: "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_name))+""));
 //BA.debugLineNum = 142;BA.debugLine="If Name = \"RECU\" Then";
if ((_name).equals("RECU")) { 
 //BA.debugLineNum = 143;BA.debugLine="Utility.WriteLog(\"RECU device found\")";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvvv3(processBA,"RECU device found");
 //BA.debugLineNum = 144;BA.debugLine="admin.CancelDiscovery";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv0.CancelDiscovery();
 //BA.debugLineNum = 145;BA.debugLine="Utility.WriteLog(\"Connecting to BT Serial\")";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvvv3(processBA,"Connecting to BT Serial");
 //BA.debugLineNum = 146;BA.debugLine="serial.Connect(MacAddress)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Connect(processBA,_macaddress);
 };
 //BA.debugLineNum = 148;BA.debugLine="End Sub";
return "";
}
public static String  _admin_discoveryfinished() throws Exception{
 //BA.debugLineNum = 150;BA.debugLine="Private Sub admin_DiscoveryFinished";
 //BA.debugLineNum = 151;BA.debugLine="BluConnecting = False";
_vvv1 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 152;BA.debugLine="End Sub";
return "";
}
public static boolean  _application_error(anywheresoftware.b4a.objects.B4AException _error,String _stacktrace) throws Exception{
 //BA.debugLineNum = 83;BA.debugLine="Sub Application_Error (Error As Exception, StackTr";
 //BA.debugLineNum = 84;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return false;
}
public static String  _ast_newdata(byte[] _buffer) throws Exception{
int _tmp = 0;
 //BA.debugLineNum = 180;BA.debugLine="Private Sub Ast_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 181;BA.debugLine="Try";
try { //BA.debugLineNum = 182;BA.debugLine="ECU.PROG = UByte(Buffer(0))";
_v7.PROG = BA.NumberToString(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (0)]));
 //BA.debugLineNum = 183;BA.debugLine="Buffer_4Cyl = ECU.PROG = \"32\"";
_buffer_4cyl = (_v7.PROG).equals("32");
 //BA.debugLineNum = 184;BA.debugLine="If Buffer_4Cyl Then";
if (_buffer_4cyl) { 
 //BA.debugLineNum = 185;BA.debugLine="ECU.THROT = \"PAR\"";
_v7.THROT = "PAR";
 //BA.debugLineNum = 186;BA.debugLine="If(Not(BitRead(Buffer(2),3)) And BitRead(Buffer";
if ((anywheresoftware.b4a.keywords.Common.Not(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (2)],(int) (3))) && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (2)],(int) (4)))) { 
 //BA.debugLineNum = 187;BA.debugLine="ECU.THROT = \"CLO\"";
_v7.THROT = "CLO";
 };
 //BA.debugLineNum = 189;BA.debugLine="If(BitRead(Buffer(2),3)) And Not(BitRead(Buffer";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (2)],(int) (3))) && anywheresoftware.b4a.keywords.Common.Not(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (2)],(int) (4)))) { 
 //BA.debugLineNum = 190;BA.debugLine="ECU.THROT = \"WOT\"";
_v7.THROT = "WOT";
 };
 //BA.debugLineNum = 192;BA.debugLine="ECU.MAP = (UByte(Buffer(3)) / 9.13) + 3.1";
_v7.MAP = (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (3)])/(double)9.13)+3.1;
 //BA.debugLineNum = 193;BA.debugLine="If ShowMAPVolts Then";
if (_vv5) { 
 //BA.debugLineNum = 194;BA.debugLine="ECU.MAP = ((ECU.MAP + 3.1) * 9.13) / 51.2   '";
_v7.MAP = ((_v7.MAP+3.1)*9.13)/(double)51.2;
 };
 //BA.debugLineNum = 196;BA.debugLine="ECU.CTS = UByte(Buffer(4))";
_v7.CTS = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (4)]);
 //BA.debugLineNum = 197;BA.debugLine="ECU.IAT = UByte(Buffer(5))";
_v7.IAT = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (5)]);
 //BA.debugLineNum = 198;BA.debugLine="ECU.VOLT = (UByte(Buffer(6)) / 31.875) + 8";
_v7.VOLT = (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (6)])/(double)31.875)+8;
 //BA.debugLineNum = 199;BA.debugLine="ECU.O2 = UByte(Buffer(7)) * 4.34";
_v7.O2 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (7)])*4.34;
 //BA.debugLineNum = 200;BA.debugLine="O2_Sum = O2_Sum + ECU.O2";
_o2_sum = _o2_sum+_v7.O2;
 //BA.debugLineNum = 201;BA.debugLine="O2_Count = O2_Count + 1";
_o2_count = _o2_count+1;
 //BA.debugLineNum = 202;BA.debugLine="ECU.O2AVG = O2_Sum/O2_Count";
_v7.O2AVG = _o2_sum/(double)_o2_count;
 //BA.debugLineNum = 203;BA.debugLine="Dim tmp As Int = (UByte(Buffer(9)) * 256) + UBy";
_tmp = (int) ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (9)])*256)+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (8)]));
 //BA.debugLineNum = 204;BA.debugLine="If tmp > 255 And tmp < 65280 Then";
if (_tmp>255 && _tmp<65280) { 
 //BA.debugLineNum = 205;BA.debugLine="ECU.RPM = 29803030 / tmp";
_v7.RPM = (long) (29803030/(double)_tmp);
 }else {
 //BA.debugLineNum = 207;BA.debugLine="ECU.RPM = 0";
_v7.RPM = (long) (0);
 };
 //BA.debugLineNum = 209;BA.debugLine="tmp = (UByte(Buffer(11)) * 256) + UByte(Buffer(";
_tmp = (int) ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (11)])*256)+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (10)]));
 //BA.debugLineNum = 210;BA.debugLine="ECU.INJ = tmp / 1000";
_v7.INJ = _tmp/(double)1000;
 //BA.debugLineNum = 211;BA.debugLine="ECU.TPS = UByte(Buffer(12)) / 2.55";
_v7.TPS = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (12)])/(double)2.55;
 //BA.debugLineNum = 212;BA.debugLine="If ShowTPSVolts Then";
if (_vv7) { 
 //BA.debugLineNum = 213;BA.debugLine="ECU.TPS = (ECU.TPS * 2.55) / 51.2";
_v7.TPS = (_v7.TPS*2.55)/(double)51.2;
 };
 //BA.debugLineNum = 215;BA.debugLine="ECU.SPK = UByte(Buffer(13))";
_v7.SPK = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (13)]);
 //BA.debugLineNum = 216;BA.debugLine="ECU.VAC = ((UByte(Buffer(16)) / 9.13) + 3.1) -";
_v7.VAC = ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (16)])/(double)9.13)+3.1)-_v7.MAP;
 //BA.debugLineNum = 217;BA.debugLine="If ShowVACVolts Then";
if (_vv6) { 
 //BA.debugLineNum = 218;BA.debugLine="ECU.VAC = ((ECU.VAC + 3.1) * 9.13) / 51.2";
_v7.VAC = ((_v7.VAC+3.1)*9.13)/(double)51.2;
 };
 //BA.debugLineNum = 220;BA.debugLine="If BitRead(Buffer(18),7) Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (18)],(int) (7))) { 
 //BA.debugLineNum = 221;BA.debugLine="ECU.O2State = \"RICH\"";
_v7.O2State = "RICH";
 }else {
 //BA.debugLineNum = 223;BA.debugLine="ECU.O2State = \"LEAN\"";
_v7.O2State = "LEAN";
 };
 //BA.debugLineNum = 225;BA.debugLine="If BitRead(Buffer(18),1) Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (18)],(int) (1))) { 
 //BA.debugLineNum = 226;BA.debugLine="ECU.ECUMode = \"DECEL\"";
_v7.ECUMode = "DECEL";
 }else {
 //BA.debugLineNum = 228;BA.debugLine="If BitRead(Buffer(18),6) Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (18)],(int) (6))) { 
 //BA.debugLineNum = 229;BA.debugLine="ECU.ECUMode = \"CLOSE LOOP\"";
_v7.ECUMode = "CLOSE LOOP";
 }else {
 //BA.debugLineNum = 231;BA.debugLine="ECU.ECUMode = \"OPEN LOOP\"";
_v7.ECUMode = "OPEN LOOP";
 };
 };
 //BA.debugLineNum = 234;BA.debugLine="If BitRead(Buffer(21),3) Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (21)],(int) (3))) { 
 //BA.debugLineNum = 235;BA.debugLine="ECU.EGR = \"ON\"";
_v7.EGR = "ON";
 }else {
 //BA.debugLineNum = 237;BA.debugLine="ECU.EGR = \"OFF\"";
_v7.EGR = "OFF";
 };
 //BA.debugLineNum = 239;BA.debugLine="ECU.STFT = ((UByte(Buffer(24)) - 128) / 128) *";
_v7.STFT = ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (24)])-128)/(double)128)*100;
 //BA.debugLineNum = 240;BA.debugLine="ECU.LTFT = ((UByte(Buffer(26)) - 128) / 128) *";
_v7.LTFT = ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (26)])-128)/(double)128)*100;
 //BA.debugLineNum = 241;BA.debugLine="ECU.TOFT = ECU.STFT + ECU.TOFT";
_v7.TOFT = _v7.STFT+_v7.TOFT;
 //BA.debugLineNum = 242;BA.debugLine="CurTime = DateTime.Now";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4 = anywheresoftware.b4a.keywords.Common.DateTime.getNow();
 //BA.debugLineNum = 243;BA.debugLine="If (CurTime - LastTime) > ECULogInterval Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv5)>_vv2) { 
 //BA.debugLineNum = 244;BA.debugLine="LastTime = CurTime";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4;
 //BA.debugLineNum = 245;BA.debugLine="Utility.SaveToLog";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvvv2(processBA);
 };
 }else {
 //BA.debugLineNum = 248;BA.debugLine="ECU.MAP = (UByte(Buffer(3)) / 9.13) + 3.1";
_v7.MAP = (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (3)])/(double)9.13)+3.1;
 //BA.debugLineNum = 249;BA.debugLine="If ShowMAPVolts Then";
if (_vv5) { 
 //BA.debugLineNum = 250;BA.debugLine="ECU.MAP = ((ECU.MAP + 3.1) * 9.13) / 51.2   '";
_v7.MAP = ((_v7.MAP+3.1)*9.13)/(double)51.2;
 };
 //BA.debugLineNum = 252;BA.debugLine="ECU.CTS = UByte(Buffer(4))";
_v7.CTS = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (4)]);
 //BA.debugLineNum = 253;BA.debugLine="ECU.IAT = UByte(Buffer(5))";
_v7.IAT = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (5)]);
 //BA.debugLineNum = 254;BA.debugLine="ECU.VOLT = UByte(Buffer(6)) / 16.24 'xxx";
_v7.VOLT = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (6)])/(double)16.24;
 //BA.debugLineNum = 255;BA.debugLine="ECU.O2 = UByte(Buffer(7)) * 4.34";
_v7.O2 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (7)])*4.34;
 //BA.debugLineNum = 256;BA.debugLine="O2_Sum = O2_Sum + ECU.O2";
_o2_sum = _o2_sum+_v7.O2;
 //BA.debugLineNum = 257;BA.debugLine="O2_Count = O2_Count + 1";
_o2_count = _o2_count+1;
 //BA.debugLineNum = 258;BA.debugLine="ECU.O2AVG = O2_Sum/O2_Count";
_v7.O2AVG = _o2_sum/(double)_o2_count;
 //BA.debugLineNum = 259;BA.debugLine="Dim tmp As Int = (UByte(Buffer(9)) * 256) + UBy";
_tmp = (int) ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (9)])*256)+_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (8)]));
 //BA.debugLineNum = 260;BA.debugLine="If tmp > 255 And tmp < 65280 Then";
if (_tmp>255 && _tmp<65280) { 
 //BA.debugLineNum = 261;BA.debugLine="ECU.RPM = 20000000 / tmp";
_v7.RPM = (long) (20000000/(double)_tmp);
 }else {
 //BA.debugLineNum = 263;BA.debugLine="ECU.RPM = 0";
_v7.RPM = (long) (0);
 };
 //BA.debugLineNum = 265;BA.debugLine="ECU.INJ = Buffer(19) * 0.128 'xxx";
_v7.INJ = _buffer[(int) (19)]*0.128;
 //BA.debugLineNum = 266;BA.debugLine="ECU.TPS = UByte(Buffer(12)) / 2.55";
_v7.TPS = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (12)])/(double)2.55;
 //BA.debugLineNum = 267;BA.debugLine="If ShowTPSVolts Then";
if (_vv7) { 
 //BA.debugLineNum = 268;BA.debugLine="ECU.TPS = (ECU.TPS * 2.55) / 51.2";
_v7.TPS = (_v7.TPS*2.55)/(double)51.2;
 };
 //BA.debugLineNum = 270;BA.debugLine="ECU.SPK = UByte(Buffer(13))";
_v7.SPK = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (13)]);
 //BA.debugLineNum = 271;BA.debugLine="ECU.VAC = ((UByte(Buffer(16)) / 9.13) + 3.1) -";
_v7.VAC = ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (16)])/(double)9.13)+3.1)-_v7.MAP;
 //BA.debugLineNum = 272;BA.debugLine="If ShowVACVolts Then";
if (_vv6) { 
 //BA.debugLineNum = 273;BA.debugLine="ECU.VAC = ((ECU.VAC + 3.1) * 9.13) / 51.2";
_v7.VAC = ((_v7.VAC+3.1)*9.13)/(double)51.2;
 };
 //BA.debugLineNum = 275;BA.debugLine="If BitRead(Buffer(18),7) Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (18)],(int) (7))) { 
 //BA.debugLineNum = 276;BA.debugLine="ECU.O2State = \"RICH\"";
_v7.O2State = "RICH";
 }else {
 //BA.debugLineNum = 278;BA.debugLine="ECU.O2State = \"LEAN\"";
_v7.O2State = "LEAN";
 };
 //BA.debugLineNum = 280;BA.debugLine="If BitRead(Buffer(18),1) Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (18)],(int) (1))) { 
 //BA.debugLineNum = 281;BA.debugLine="ECU.ECUMode = \"DECEL\"";
_v7.ECUMode = "DECEL";
 }else {
 //BA.debugLineNum = 283;BA.debugLine="If BitRead(Buffer(18),6) Then";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (18)],(int) (6))) { 
 //BA.debugLineNum = 284;BA.debugLine="ECU.ECUMode = \"CLOSE LOOP\"";
_v7.ECUMode = "CLOSE LOOP";
 }else {
 //BA.debugLineNum = 286;BA.debugLine="ECU.ECUMode = \"OPEN LOOP\"";
_v7.ECUMode = "OPEN LOOP";
 };
 };
 //BA.debugLineNum = 289;BA.debugLine="If BitRead(Buffer(18),3) Then  'xxx";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (18)],(int) (3))) { 
 //BA.debugLineNum = 290;BA.debugLine="ECU.EGR = \"ON\"";
_v7.EGR = "ON";
 }else {
 //BA.debugLineNum = 292;BA.debugLine="ECU.EGR = \"OFF\"";
_v7.EGR = "OFF";
 };
 //BA.debugLineNum = 294;BA.debugLine="ECU.THROT = \"PAR\"";
_v7.THROT = "PAR";
 //BA.debugLineNum = 295;BA.debugLine="If(Not(BitRead(Buffer(21),1)) And BitRead(Buffe";
if ((anywheresoftware.b4a.keywords.Common.Not(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (21)],(int) (1))) && _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (21)],(int) (3)))) { 
 //BA.debugLineNum = 296;BA.debugLine="ECU.THROT = \"CLO\"";
_v7.THROT = "CLO";
 };
 //BA.debugLineNum = 298;BA.debugLine="If(BitRead(Buffer(21),1)) And Not(BitRead(Buffe";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (21)],(int) (1))) && anywheresoftware.b4a.keywords.Common.Not(_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(_buffer[(int) (21)],(int) (3)))) { 
 //BA.debugLineNum = 299;BA.debugLine="ECU.THROT = \"WOT\"";
_v7.THROT = "WOT";
 };
 //BA.debugLineNum = 301;BA.debugLine="ECU.STFT = ((UByte(Buffer(24)) - 128) / 128) *";
_v7.STFT = ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (24)])-128)/(double)128)*100;
 //BA.debugLineNum = 302;BA.debugLine="ECU.LTFT = ((UByte(Buffer(26)) - 128) / 128) *";
_v7.LTFT = ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(_buffer[(int) (26)])-128)/(double)128)*100;
 //BA.debugLineNum = 303;BA.debugLine="ECU.TOFT = ECU.STFT + ECU.TOFT";
_v7.TOFT = _v7.STFT+_v7.TOFT;
 //BA.debugLineNum = 304;BA.debugLine="CurTime = DateTime.Now";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4 = anywheresoftware.b4a.keywords.Common.DateTime.getNow();
 //BA.debugLineNum = 305;BA.debugLine="If (CurTime - LastTime) > ECULogInterval Then";
if ((_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4-_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv5)>_vv2) { 
 //BA.debugLineNum = 306;BA.debugLine="LastTime = CurTime";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4;
 //BA.debugLineNum = 307;BA.debugLine="Utility.SaveToLog";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvvv2(processBA);
 //BA.debugLineNum = 308;BA.debugLine="If LogRawBytes Then";
if (_vv4) { 
 //BA.debugLineNum = 309;BA.debugLine="Utility.SaveRawToLog";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvv0(processBA);
 };
 };
 };
 } 
       catch (Exception e134) {
			processBA.setLastException(e134); };
 //BA.debugLineNum = 316;BA.debugLine="CallSub(Main, \"UpdateInterface\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.getObject()),"UpdateInterface");
 //BA.debugLineNum = 317;BA.debugLine="End Sub";
return "";
}
public static String  _ast_terminated() throws Exception{
 //BA.debugLineNum = 320;BA.debugLine="Private Sub Ast_Terminated";
 //BA.debugLineNum = 321;BA.debugLine="Utility.WriteLog(\"BT Stream Terminated\")";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvvv3(processBA,"BT Stream Terminated");
 //BA.debugLineNum = 322;BA.debugLine="BluConnected = False";
_vv0 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 323;BA.debugLine="CallSub(Main, \"ShowStatus\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.getObject()),"ShowStatus");
 //BA.debugLineNum = 324;BA.debugLine="End Sub";
return "";
}
public static boolean  _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3(byte _b,int _index) throws Exception{
byte _t = (byte)0;
 //BA.debugLineNum = 171;BA.debugLine="Sub BitRead(b As Byte, index As Int) As Boolean";
 //BA.debugLineNum = 172;BA.debugLine="Dim t As Byte = Bit.ShiftLeft(1, index)";
_t = (byte) (anywheresoftware.b4a.keywords.Common.Bit.ShiftLeft((int) (1),_index));
 //BA.debugLineNum = 173;BA.debugLine="Return Bit.And(b, t) = t";
if (true) return anywheresoftware.b4a.keywords.Common.Bit.And((int) (_b),(int) (_t))==_t;
 //BA.debugLineNum = 174;BA.debugLine="End Sub";
return false;
}
public static String  _connect() throws Exception{
 //BA.debugLineNum = 105;BA.debugLine="Public Sub Connect";
 //BA.debugLineNum = 106;BA.debugLine="Utility.WriteLog(\"Connecting...\")";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvvv3(processBA,"Connecting...");
 //BA.debugLineNum = 107;BA.debugLine="admin.StartDiscovery";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv0.StartDiscovery();
 //BA.debugLineNum = 108;BA.debugLine="BluConnecting = True";
_vvv1 = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 109;BA.debugLine="CallSub(Main, \"ShowStatus\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.getObject()),"ShowStatus");
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return "";
}
public static String  _disconnect() throws Exception{
 //BA.debugLineNum = 112;BA.debugLine="Public Sub DisConnect";
 //BA.debugLineNum = 113;BA.debugLine="Utility.WriteLog(\"DisConnect\")";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvvv3(processBA,"DisConnect");
 //BA.debugLineNum = 114;BA.debugLine="serial.Disconnect";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Disconnect();
 //BA.debugLineNum = 115;BA.debugLine="admin.CancelDiscovery";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv0.CancelDiscovery();
 //BA.debugLineNum = 116;BA.debugLine="BluConnected = False";
_vv0 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 117;BA.debugLine="BluConnecting = False";
_vvv1 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 118;BA.debugLine="CallSub(Main, \"ShowStatus\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.getObject()),"ShowStatus");
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Dim pw As PhoneWakeState";
_v5 = new anywheresoftware.b4a.phone.Phone.PhoneWakeState();
 //BA.debugLineNum = 10;BA.debugLine="Public ECUEnabled As Boolean";
_v6 = false;
 //BA.debugLineNum = 11;BA.debugLine="Type ECUType (MAP As Double,CTS As Double,IAT As";
;
 //BA.debugLineNum = 17;BA.debugLine="Public ECU As ECUType";
_v7 = new cmarsoft.recu.starter._ecutype();
 //BA.debugLineNum = 18;BA.debugLine="Public Buffer_4Cyl As Boolean = True";
_buffer_4cyl = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 19;BA.debugLine="Public O2_Sum As Double";
_o2_sum = 0;
 //BA.debugLineNum = 20;BA.debugLine="Public O2_Count As Double";
_o2_count = 0;
 //BA.debugLineNum = 21;BA.debugLine="Public Exception As String";
_v0 = "";
 //BA.debugLineNum = 22;BA.debugLine="Private CurTime, LastTime As Long";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4 = 0L;
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = 0L;
 //BA.debugLineNum = 23;BA.debugLine="Public DemoMode As Boolean";
_vv1 = false;
 //BA.debugLineNum = 26;BA.debugLine="Public ECULogInterval As Int    'how fast to poll";
_vv2 = 0;
 //BA.debugLineNum = 27;BA.debugLine="Public EmailAddress As String   'where to send em";
_vv3 = "";
 //BA.debugLineNum = 28;BA.debugLine="Public LogRawBytes As Boolean   'add raw byte arr";
_vv4 = false;
 //BA.debugLineNum = 29;BA.debugLine="Public ShowMAPVolts As Boolean  'show MAP value i";
_vv5 = false;
 //BA.debugLineNum = 30;BA.debugLine="Public ShowVACVolts As Boolean  'show VAC value i";
_vv6 = false;
 //BA.debugLineNum = 31;BA.debugLine="Public ShowTPSVolts As Boolean  'show TPS value i";
_vv7 = false;
 //BA.debugLineNum = 34;BA.debugLine="Private serial As Serial";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1 = new anywheresoftware.b4a.objects.Serial();
 //BA.debugLineNum = 35;BA.debugLine="Private admin As BluetoothAdmin";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv0 = new anywheresoftware.b4a.objects.Serial.BluetoothAdmin();
 //BA.debugLineNum = 36;BA.debugLine="Private astream As AsyncStreams";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv6 = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 37;BA.debugLine="Public BluConnected As Boolean";
_vv0 = false;
 //BA.debugLineNum = 38;BA.debugLine="Public BluConnecting As Boolean";
_vvv1 = false;
 //BA.debugLineNum = 39;BA.debugLine="Public BluEnabled As Boolean";
_vvv2 = false;
 //BA.debugLineNum = 40;BA.debugLine="Public BluEnabling As Boolean";
_vvv3 = false;
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public static String  _sendmessage(byte[] _msg) throws Exception{
 //BA.debugLineNum = 167;BA.debugLine="Public Sub SendMessage(msg() As Byte)";
 //BA.debugLineNum = 168;BA.debugLine="astream.Write(msg)";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv6.Write(_msg);
 //BA.debugLineNum = 169;BA.debugLine="End Sub";
return "";
}
public static String  _serial_connected(boolean _success) throws Exception{
 //BA.debugLineNum = 154;BA.debugLine="Private Sub Serial_Connected (Success As Boolean)";
 //BA.debugLineNum = 155;BA.debugLine="If Success Then";
if (_success) { 
 //BA.debugLineNum = 156;BA.debugLine="If astream.IsInitialized Then astream.Close";
if (_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv6.IsInitialized()) { 
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv6.Close();};
 //BA.debugLineNum = 157;BA.debugLine="astream.Initialize(serial.InputStream, serial.Ou";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv6.Initialize(processBA,_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getInputStream(),_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.getOutputStream(),"Ast");
 //BA.debugLineNum = 158;BA.debugLine="Utility.WriteLog(\"BT Serial Connected\")";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvvv3(processBA,"BT Serial Connected");
 //BA.debugLineNum = 159;BA.debugLine="BluConnected = True";
_vv0 = anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 161;BA.debugLine="Utility.WriteLog(\"BT Serial NOT Connected - \" &";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvvv3(processBA,"BT Serial NOT Connected - "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA)));
 };
 //BA.debugLineNum = 163;BA.debugLine="BluConnecting = False";
_vvv1 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 164;BA.debugLine="CallSub(Main, \"ShowStatus\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2.getObject()),"ShowStatus");
 //BA.debugLineNum = 165;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 46;BA.debugLine="LastTime = DateTime.Now";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = anywheresoftware.b4a.keywords.Common.DateTime.getNow();
 //BA.debugLineNum = 47;BA.debugLine="ECULogInterval = 250";
_vv2 = (int) (250);
 //BA.debugLineNum = 48;BA.debugLine="EmailAddress = \"you@mail.com\"";
_vv3 = "you@mail.com";
 //BA.debugLineNum = 49;BA.debugLine="Utility.LoadSettings";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv4._vvv5(processBA);
 //BA.debugLineNum = 50;BA.debugLine="serial.Initialize(\"serial\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv1.Initialize("serial");
 //BA.debugLineNum = 51;BA.debugLine="admin.Initialize(\"admin\")";
_vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv0.Initialize(processBA,"admin");
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 88;BA.debugLine="pw.ReleaseKeepAlive";
_v5.ReleaseKeepAlive();
 //BA.debugLineNum = 89;BA.debugLine="ECUEnabled = False";
_v6 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 55;BA.debugLine="ECUEnabled = False";
_v6 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 56;BA.debugLine="ECU.CTS = 0";
_v7.CTS = 0;
 //BA.debugLineNum = 57;BA.debugLine="ECU.ECUMode = \"???\"";
_v7.ECUMode = "???";
 //BA.debugLineNum = 58;BA.debugLine="ECU.EGR = \"???\"";
_v7.EGR = "???";
 //BA.debugLineNum = 59;BA.debugLine="ECU.IAT = 0";
_v7.IAT = 0;
 //BA.debugLineNum = 60;BA.debugLine="ECU.INJ = 0";
_v7.INJ = 0;
 //BA.debugLineNum = 61;BA.debugLine="ECU.LTFT = 0";
_v7.LTFT = 0;
 //BA.debugLineNum = 62;BA.debugLine="ECU.MAP = 0";
_v7.MAP = 0;
 //BA.debugLineNum = 63;BA.debugLine="ECU.O2 = 0";
_v7.O2 = 0;
 //BA.debugLineNum = 64;BA.debugLine="ECU.O2AVG = 0";
_v7.O2AVG = 0;
 //BA.debugLineNum = 65;BA.debugLine="ECU.O2State = \"???\"";
_v7.O2State = "???";
 //BA.debugLineNum = 66;BA.debugLine="ECU.PROG = \"?\"";
_v7.PROG = "?";
 //BA.debugLineNum = 67;BA.debugLine="ECU.RPM = 0";
_v7.RPM = (long) (0);
 //BA.debugLineNum = 68;BA.debugLine="ECU.SPK = 0";
_v7.SPK = (int) (0);
 //BA.debugLineNum = 69;BA.debugLine="ECU.STFT = 0";
_v7.STFT = 0;
 //BA.debugLineNum = 70;BA.debugLine="ECU.TOFT = 0";
_v7.TOFT = 0;
 //BA.debugLineNum = 71;BA.debugLine="ECU.TPS = 0";
_v7.TPS = 0;
 //BA.debugLineNum = 72;BA.debugLine="ECU.VAC = 0";
_v7.VAC = 0;
 //BA.debugLineNum = 73;BA.debugLine="ECU.VOLT = 0";
_v7.VOLT = 0;
 //BA.debugLineNum = 74;BA.debugLine="ECU.THROT = \"???\"";
_v7.THROT = "???";
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return "";
}
public static String  _service_taskremoved() throws Exception{
 //BA.debugLineNum = 77;BA.debugLine="Sub Service_TaskRemoved";
 //BA.debugLineNum = 79;BA.debugLine="StopService(Me)";
anywheresoftware.b4a.keywords.Common.StopService(processBA,starter.getObject());
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return "";
}
public static int  _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2(byte _b) throws Exception{
 //BA.debugLineNum = 176;BA.debugLine="Sub UByte(b As Byte) As Int";
 //BA.debugLineNum = 177;BA.debugLine="Return Bit.And(b, 0xFF)";
if (true) return anywheresoftware.b4a.keywords.Common.Bit.And((int) (_b),(int) (0xff));
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return 0;
}
}
