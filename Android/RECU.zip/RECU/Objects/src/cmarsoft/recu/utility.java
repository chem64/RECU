package cmarsoft.recu;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class utility {
private static utility mostCurrent = new utility();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public cmarsoft.recu.main _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv2 = null;
public cmarsoft.recu.starter _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3 = null;
public cmarsoft.recu.chart _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv5 = null;
public cmarsoft.recu.setup _vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv6 = null;
public static String  _vvv4(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
String _tmp = "";
 //BA.debugLineNum = 9;BA.debugLine="Sub InitLog";
 //BA.debugLineNum = 10;BA.debugLine="Try";
try { //BA.debugLineNum = 11;BA.debugLine="Dim tw As TextWriter";
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();
 //BA.debugLineNum = 12;BA.debugLine="tw.Initialize(File.OpenOutput(File.DirInternal,";
_tw.Initialize((java.io.OutputStream)(anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"recu.csv",anywheresoftware.b4a.keywords.Common.False).getObject()));
 //BA.debugLineNum = 13;BA.debugLine="Dim tmp As String = \"DATE\"";
_tmp = "DATE";
 //BA.debugLineNum = 14;BA.debugLine="tmp = tmp & \",\" & \"TIME\"";
_tmp = _tmp+","+"TIME";
 //BA.debugLineNum = 15;BA.debugLine="tmp = tmp & \",\" & \"LOOP\"";
_tmp = _tmp+","+"LOOP";
 //BA.debugLineNum = 16;BA.debugLine="tmp = tmp & \",\" & \"FUEL\"";
_tmp = _tmp+","+"FUEL";
 //BA.debugLineNum = 17;BA.debugLine="tmp = tmp & \",\" & \"MAP\"";
_tmp = _tmp+","+"MAP";
 //BA.debugLineNum = 18;BA.debugLine="tmp = tmp & \",\" & \"VAC\"";
_tmp = _tmp+","+"VAC";
 //BA.debugLineNum = 19;BA.debugLine="tmp = tmp & \",\" & \"CTS\"";
_tmp = _tmp+","+"CTS";
 //BA.debugLineNum = 20;BA.debugLine="tmp = tmp & \",\" & \"IAT\"";
_tmp = _tmp+","+"IAT";
 //BA.debugLineNum = 21;BA.debugLine="tmp = tmp & \",\" & \"O2\"";
_tmp = _tmp+","+"O2";
 //BA.debugLineNum = 22;BA.debugLine="tmp = tmp & \",\" & \"O2AVG\"";
_tmp = _tmp+","+"O2AVG";
 //BA.debugLineNum = 23;BA.debugLine="tmp = tmp & \",\" & \"INJ\"";
_tmp = _tmp+","+"INJ";
 //BA.debugLineNum = 24;BA.debugLine="tmp = tmp & \",\" & \"TPS\"";
_tmp = _tmp+","+"TPS";
 //BA.debugLineNum = 25;BA.debugLine="tmp = tmp & \",\" & \"RPM\"";
_tmp = _tmp+","+"RPM";
 //BA.debugLineNum = 26;BA.debugLine="tmp = tmp & \",\" & \"STFT\"";
_tmp = _tmp+","+"STFT";
 //BA.debugLineNum = 27;BA.debugLine="tmp = tmp & \",\" & \"LTFT\"";
_tmp = _tmp+","+"LTFT";
 //BA.debugLineNum = 28;BA.debugLine="tmp = tmp & \",\" & \"SPK\"";
_tmp = _tmp+","+"SPK";
 //BA.debugLineNum = 29;BA.debugLine="tmp = tmp & \",\" & \"VOLT\"";
_tmp = _tmp+","+"VOLT";
 //BA.debugLineNum = 30;BA.debugLine="tmp = tmp & \",\" & \"EGR\"";
_tmp = _tmp+","+"EGR";
 //BA.debugLineNum = 31;BA.debugLine="tmp = tmp & \",\" & \"THROT\"";
_tmp = _tmp+","+"THROT";
 //BA.debugLineNum = 32;BA.debugLine="tw.WriteLine(tmp)";
_tw.WriteLine(_tmp);
 //BA.debugLineNum = 33;BA.debugLine="tw.Close";
_tw.Close();
 } 
       catch (Exception e26) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e26); //BA.debugLineNum = 35;BA.debugLine="Starter.Exception = LastException.Message";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v0 = anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage();
 };
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public static String  _vvv5(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.collections.Map _locmap = null;
 //BA.debugLineNum = 167;BA.debugLine="Sub LoadSettings";
 //BA.debugLineNum = 168;BA.debugLine="Dim locMap As Map";
_locmap = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 169;BA.debugLine="Try";
try { //BA.debugLineNum = 170;BA.debugLine="If File.Exists(File.DirInternal, \"RECU.set\") = T";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"RECU.set")==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 171;BA.debugLine="locMap = File.ReadMap(File.DirInternal,\"RECU.se";
_locmap = anywheresoftware.b4a.keywords.Common.File.ReadMap(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"RECU.set");
 //BA.debugLineNum = 172;BA.debugLine="Starter.ECULogInterval = locMap.Get(\"ECUInterva";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv2 = (int)(BA.ObjectToNumber(_locmap.Get((Object)("ECUInterval"))));
 //BA.debugLineNum = 173;BA.debugLine="If Starter.ECULogInterval < 250 Then Starter.EC";
if (mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv2<250) { 
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv2 = (int) (250);};
 //BA.debugLineNum = 174;BA.debugLine="Starter.EmailAddress = locMap.Get(\"EmailAddress";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv3 = BA.ObjectToString(_locmap.Get((Object)("EmailAddress")));
 //BA.debugLineNum = 175;BA.debugLine="Starter.ShowMAPVolts = locMap.Get(\"ShowMAPVolts";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv5 = BA.ObjectToBoolean(_locmap.Get((Object)("ShowMAPVolts")));
 //BA.debugLineNum = 176;BA.debugLine="Starter.ShowVACVolts = locMap.Get(\"ShowVACVolts";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv6 = BA.ObjectToBoolean(_locmap.Get((Object)("ShowVACVolts")));
 //BA.debugLineNum = 177;BA.debugLine="Starter.ShowTPSVolts = locMap.Get(\"ShowTPSVolts";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv7 = BA.ObjectToBoolean(_locmap.Get((Object)("ShowTPSVolts")));
 //BA.debugLineNum = 178;BA.debugLine="Starter.LogRawBytes = locMap.Get(\"LogRawBytes\")";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv4 = BA.ObjectToBoolean(_locmap.Get((Object)("LogRawBytes")));
 }else {
 //BA.debugLineNum = 180;BA.debugLine="Starter.ECULogInterval = 250";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv2 = (int) (250);
 //BA.debugLineNum = 181;BA.debugLine="Starter.EmailAddress = \"you@mail.com\"";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv3 = "you@mail.com";
 //BA.debugLineNum = 182;BA.debugLine="Starter.ShowMAPVolts = False";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv5 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 183;BA.debugLine="Starter.ShowTPSVolts = False";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv7 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 184;BA.debugLine="Starter.ShowVACVolts = False";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv6 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 185;BA.debugLine="Starter.LogRawBytes = False";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv4 = anywheresoftware.b4a.keywords.Common.False;
 };
 } 
       catch (Exception e21) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e21); //BA.debugLineNum = 188;BA.debugLine="Starter.Exception = LastException.Message";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v0 = anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage();
 };
 //BA.debugLineNum = 190;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
public static String  _vvv6(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.streams.File.TextReaderWrapper _tr = null;
String _tmp = "";
 //BA.debugLineNum = 140;BA.debugLine="Sub ReadFromLog As String";
 //BA.debugLineNum = 141;BA.debugLine="Try";
try { //BA.debugLineNum = 142;BA.debugLine="Dim tr As TextReader";
_tr = new anywheresoftware.b4a.objects.streams.File.TextReaderWrapper();
 //BA.debugLineNum = 143;BA.debugLine="tr.Initialize(File.OpenInput(File.DirInternal, \"";
_tr.Initialize((java.io.InputStream)(anywheresoftware.b4a.keywords.Common.File.OpenInput(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"recu.csv").getObject()));
 //BA.debugLineNum = 144;BA.debugLine="Dim tmp As String = tr.ReadAll";
_tmp = _tr.ReadAll();
 //BA.debugLineNum = 145;BA.debugLine="Return tmp";
if (true) return _tmp;
 } 
       catch (Exception e7) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e7); //BA.debugLineNum = 147;BA.debugLine="Return \"Error: \" & LastException.Message";
if (true) return "Error: "+anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage();
 };
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return "";
}
public static String  _vvv7(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
long _nowticks = 0L;
String _logtime = "";
String _tmp = "";
 //BA.debugLineNum = 105;BA.debugLine="Sub SaveErrorToLog";
 //BA.debugLineNum = 106;BA.debugLine="Try";
try { //BA.debugLineNum = 107;BA.debugLine="Dim tw As TextWriter";
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();
 //BA.debugLineNum = 108;BA.debugLine="tw.Initialize(File.OpenOutput(File.DirInternal,";
_tw.Initialize((java.io.OutputStream)(anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"recu.csv",anywheresoftware.b4a.keywords.Common.True).getObject()));
 //BA.debugLineNum = 109;BA.debugLine="DateTime.DateFormat = \"MM/dd/yy\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("MM/dd/yy");
 //BA.debugLineNum = 110;BA.debugLine="DateTime.TimeFormat = \"HH:mm:ss.SSS\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("HH:mm:ss.SSS");
 //BA.debugLineNum = 111;BA.debugLine="Dim nowTicks As Long = DateTime.Now";
_nowticks = anywheresoftware.b4a.keywords.Common.DateTime.getNow();
 //BA.debugLineNum = 112;BA.debugLine="Dim logTime As String = DateTime.Date(nowTicks)";
_logtime = anywheresoftware.b4a.keywords.Common.DateTime.Date(_nowticks)+" "+anywheresoftware.b4a.keywords.Common.DateTime.Time(_nowticks);
 //BA.debugLineNum = 113;BA.debugLine="Dim tmp As String = logTime";
_tmp = _logtime;
 //BA.debugLineNum = 114;BA.debugLine="tmp = tmp & \",\" & Starter.Exception";
_tmp = _tmp+","+mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v0;
 //BA.debugLineNum = 115;BA.debugLine="tw.WriteLine(tmp)";
_tw.WriteLine(_tmp);
 //BA.debugLineNum = 116;BA.debugLine="Starter.Exception = \"\"";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v0 = "";
 //BA.debugLineNum = 117;BA.debugLine="tw.Close";
_tw.Close();
 } 
       catch (Exception e14) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e14); //BA.debugLineNum = 119;BA.debugLine="Starter.Exception = LastException.Message";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v0 = anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage();
 };
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return "";
}
public static String  _vvv0(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
long _nowticks = 0L;
String _logtime = "";
String _tmp = "";
 //BA.debugLineNum = 72;BA.debugLine="Sub SaveRawToLog";
 //BA.debugLineNum = 73;BA.debugLine="Try";
try { //BA.debugLineNum = 74;BA.debugLine="Dim tw As TextWriter";
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();
 //BA.debugLineNum = 75;BA.debugLine="tw.Initialize(File.OpenOutput(File.DirInternal,";
_tw.Initialize((java.io.OutputStream)(anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"recu.csv",anywheresoftware.b4a.keywords.Common.True).getObject()));
 //BA.debugLineNum = 76;BA.debugLine="DateTime.DateFormat = \"MM/dd/yy\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("MM/dd/yy");
 //BA.debugLineNum = 77;BA.debugLine="DateTime.TimeFormat = \"HH:mm:ss.SSS\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("HH:mm:ss.SSS");
 //BA.debugLineNum = 78;BA.debugLine="Dim nowTicks As Long = DateTime.Now";
_nowticks = anywheresoftware.b4a.keywords.Common.DateTime.getNow();
 //BA.debugLineNum = 79;BA.debugLine="Dim logTime As String = DateTime.Date(nowTicks)";
_logtime = anywheresoftware.b4a.keywords.Common.DateTime.Date(_nowticks)+","+anywheresoftware.b4a.keywords.Common.DateTime.Time(_nowticks);
 //BA.debugLineNum = 80;BA.debugLine="Dim tmp As String = logTime";
_tmp = _logtime;
 //BA.debugLineNum = 81;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.ECUMode";
_tmp = _tmp+","+mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.ECUMode;
 //BA.debugLineNum = 82;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.O2State";
_tmp = _tmp+","+mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.O2State;
 //BA.debugLineNum = 83;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.MAP,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.MAP,(int) (1),(int) (1));
 //BA.debugLineNum = 84;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.VAC,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.VAC,(int) (1),(int) (1));
 //BA.debugLineNum = 85;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.CTS,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.CTS,(int) (1),(int) (1));
 //BA.debugLineNum = 86;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.IAT,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.IAT,(int) (1),(int) (1));
 //BA.debugLineNum = 87;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.O2,1,";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.O2,(int) (1),(int) (0));
 //BA.debugLineNum = 88;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.O2AVG";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.O2AVG,(int) (1),(int) (1));
 //BA.debugLineNum = 89;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.INJ,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.INJ,(int) (1),(int) (1));
 //BA.debugLineNum = 90;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.TPS,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.TPS,(int) (1),(int) (1));
 //BA.debugLineNum = 91;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.RPM";
_tmp = _tmp+","+BA.NumberToString(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.RPM);
 //BA.debugLineNum = 92;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.STFT,";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.STFT,(int) (1),(int) (1));
 //BA.debugLineNum = 93;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.LTFT,";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.LTFT,(int) (1),(int) (1));
 //BA.debugLineNum = 94;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.SPK";
_tmp = _tmp+","+BA.NumberToString(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.SPK);
 //BA.debugLineNum = 95;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.VOLT,";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.VOLT,(int) (1),(int) (1));
 //BA.debugLineNum = 96;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.EGR";
_tmp = _tmp+","+mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.EGR;
 //BA.debugLineNum = 97;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.THROT";
_tmp = _tmp+","+mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.THROT;
 //BA.debugLineNum = 98;BA.debugLine="tw.WriteLine(tmp)";
_tw.WriteLine(_tmp);
 //BA.debugLineNum = 99;BA.debugLine="tw.Close";
_tw.Close();
 } 
       catch (Exception e29) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e29); //BA.debugLineNum = 101;BA.debugLine="Starter.Exception = LastException.Message";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v0 = anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage();
 };
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
return "";
}
public static String  _vvvv1(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.collections.Map _locmap = null;
 //BA.debugLineNum = 151;BA.debugLine="Sub SaveSettings";
 //BA.debugLineNum = 152;BA.debugLine="Dim locMap As Map";
_locmap = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 153;BA.debugLine="Try";
try { //BA.debugLineNum = 154;BA.debugLine="locMap.Initialize";
_locmap.Initialize();
 //BA.debugLineNum = 155;BA.debugLine="locMap.Put(\"ECUInterval\",Starter.ECULogInterval)";
_locmap.Put((Object)("ECUInterval"),(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv2));
 //BA.debugLineNum = 156;BA.debugLine="locMap.Put(\"EmailAddress\",Starter.EmailAddress)";
_locmap.Put((Object)("EmailAddress"),(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv3));
 //BA.debugLineNum = 157;BA.debugLine="locMap.Put(\"ShowMAPVolts\",Starter.ShowMAPVolts)";
_locmap.Put((Object)("ShowMAPVolts"),(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv5));
 //BA.debugLineNum = 158;BA.debugLine="locMap.Put(\"ShowVACVolts\",Starter.ShowVACVolts)";
_locmap.Put((Object)("ShowVACVolts"),(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv6));
 //BA.debugLineNum = 159;BA.debugLine="locMap.Put(\"ShowTPSVolts\",Starter.ShowTPSVolts)";
_locmap.Put((Object)("ShowTPSVolts"),(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv7));
 //BA.debugLineNum = 160;BA.debugLine="locMap.Put(\"LogRawBytes\",Starter.LogRawBytes)";
_locmap.Put((Object)("LogRawBytes"),(Object)(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._vv4));
 //BA.debugLineNum = 161;BA.debugLine="File.WriteMap(File.DirInternal, \"RECU.set\", locM";
anywheresoftware.b4a.keywords.Common.File.WriteMap(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"RECU.set",_locmap);
 } 
       catch (Exception e12) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e12); //BA.debugLineNum = 163;BA.debugLine="Starter.Exception = LastException.Message";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v0 = anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage();
 };
 //BA.debugLineNum = 165;BA.debugLine="End Sub";
return "";
}
public static String  _vvvv2(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
long _nowticks = 0L;
String _logtime = "";
String _tmp = "";
 //BA.debugLineNum = 39;BA.debugLine="Sub SaveToLog";
 //BA.debugLineNum = 40;BA.debugLine="Try";
try { //BA.debugLineNum = 41;BA.debugLine="Dim tw As TextWriter";
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();
 //BA.debugLineNum = 42;BA.debugLine="tw.Initialize(File.OpenOutput(File.DirInternal,";
_tw.Initialize((java.io.OutputStream)(anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"recu.csv",anywheresoftware.b4a.keywords.Common.True).getObject()));
 //BA.debugLineNum = 43;BA.debugLine="DateTime.DateFormat = \"MM/dd/yy\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("MM/dd/yy");
 //BA.debugLineNum = 44;BA.debugLine="DateTime.TimeFormat = \"HH:mm:ss.SSS\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("HH:mm:ss.SSS");
 //BA.debugLineNum = 45;BA.debugLine="Dim nowTicks As Long = DateTime.Now";
_nowticks = anywheresoftware.b4a.keywords.Common.DateTime.getNow();
 //BA.debugLineNum = 46;BA.debugLine="Dim logTime As String = DateTime.Date(nowTicks)";
_logtime = anywheresoftware.b4a.keywords.Common.DateTime.Date(_nowticks)+","+anywheresoftware.b4a.keywords.Common.DateTime.Time(_nowticks);
 //BA.debugLineNum = 47;BA.debugLine="Dim tmp As String = logTime";
_tmp = _logtime;
 //BA.debugLineNum = 48;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.ECUMode";
_tmp = _tmp+","+mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.ECUMode;
 //BA.debugLineNum = 49;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.O2State";
_tmp = _tmp+","+mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.O2State;
 //BA.debugLineNum = 50;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.MAP,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.MAP,(int) (1),(int) (1));
 //BA.debugLineNum = 51;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.VAC,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.VAC,(int) (1),(int) (1));
 //BA.debugLineNum = 52;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.CTS,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.CTS,(int) (1),(int) (1));
 //BA.debugLineNum = 53;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.IAT,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.IAT,(int) (1),(int) (1));
 //BA.debugLineNum = 54;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.O2,1,";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.O2,(int) (1),(int) (0));
 //BA.debugLineNum = 55;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.O2AVG";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.O2AVG,(int) (1),(int) (1));
 //BA.debugLineNum = 56;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.INJ,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.INJ,(int) (1),(int) (1));
 //BA.debugLineNum = 57;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.TPS,1";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.TPS,(int) (1),(int) (1));
 //BA.debugLineNum = 58;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.RPM";
_tmp = _tmp+","+BA.NumberToString(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.RPM);
 //BA.debugLineNum = 59;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.STFT,";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.STFT,(int) (1),(int) (1));
 //BA.debugLineNum = 60;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.LTFT,";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.LTFT,(int) (1),(int) (1));
 //BA.debugLineNum = 61;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.SPK";
_tmp = _tmp+","+BA.NumberToString(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.SPK);
 //BA.debugLineNum = 62;BA.debugLine="tmp = tmp & \",\" & NumberFormat(Starter.ECU.VOLT,";
_tmp = _tmp+","+anywheresoftware.b4a.keywords.Common.NumberFormat(mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.VOLT,(int) (1),(int) (1));
 //BA.debugLineNum = 63;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.EGR";
_tmp = _tmp+","+mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.EGR;
 //BA.debugLineNum = 64;BA.debugLine="tmp = tmp & \",\" & Starter.ECU.THROT";
_tmp = _tmp+","+mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v7.THROT;
 //BA.debugLineNum = 65;BA.debugLine="tw.WriteLine(tmp)";
_tw.WriteLine(_tmp);
 //BA.debugLineNum = 66;BA.debugLine="tw.Close";
_tw.Close();
 } 
       catch (Exception e29) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e29); //BA.debugLineNum = 68;BA.debugLine="Starter.Exception = LastException.Message";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v0 = anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage();
 };
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public static String  _vvvv3(anywheresoftware.b4a.BA _ba,String _msg) throws Exception{
anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
long _nowticks = 0L;
String _logtime = "";
String _tmp = "";
 //BA.debugLineNum = 123;BA.debugLine="Sub WriteLog(msg As String)";
 //BA.debugLineNum = 124;BA.debugLine="Try";
try { //BA.debugLineNum = 125;BA.debugLine="Dim tw As TextWriter";
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();
 //BA.debugLineNum = 126;BA.debugLine="tw.Initialize(File.OpenOutput(File.DirInternal,";
_tw.Initialize((java.io.OutputStream)(anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"recu.csv",anywheresoftware.b4a.keywords.Common.True).getObject()));
 //BA.debugLineNum = 127;BA.debugLine="DateTime.DateFormat = \"MM/dd/yy\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("MM/dd/yy");
 //BA.debugLineNum = 128;BA.debugLine="DateTime.TimeFormat = \"HH:mm:ss.SSS\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("HH:mm:ss.SSS");
 //BA.debugLineNum = 129;BA.debugLine="Dim nowTicks As Long = DateTime.Now";
_nowticks = anywheresoftware.b4a.keywords.Common.DateTime.getNow();
 //BA.debugLineNum = 130;BA.debugLine="Dim logTime As String = DateTime.Date(nowTicks)";
_logtime = anywheresoftware.b4a.keywords.Common.DateTime.Date(_nowticks)+" "+anywheresoftware.b4a.keywords.Common.DateTime.Time(_nowticks);
 //BA.debugLineNum = 131;BA.debugLine="Dim tmp As String = logTime";
_tmp = _logtime;
 //BA.debugLineNum = 132;BA.debugLine="tmp = tmp & \",\" & msg";
_tmp = _tmp+","+_msg;
 //BA.debugLineNum = 133;BA.debugLine="tw.WriteLine(tmp)";
_tw.WriteLine(_tmp);
 //BA.debugLineNum = 134;BA.debugLine="tw.Close";
_tw.Close();
 } 
       catch (Exception e13) {
			(_ba.processBA == null ? _ba : _ba.processBA).setLastException(e13); //BA.debugLineNum = 136;BA.debugLine="Starter.Exception = LastException.Message";
mostCurrent._vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv3._v0 = anywheresoftware.b4a.keywords.Common.LastException(_ba).getMessage();
 };
 //BA.debugLineNum = 138;BA.debugLine="End Sub";
return "";
}
}
