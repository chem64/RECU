package cmarsoft.recu.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_setup{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("label1").vw.setWidth((int)((40d / 100 * width)));
views.get("label1").vw.setHeight((int)((5d / 100 * height)));
views.get("spninterval").vw.setWidth((int)((40d / 100 * width)));
views.get("spninterval").vw.setHeight((int)((5d / 100 * height)));
views.get("label13").vw.setWidth((int)((40d / 100 * width)));
views.get("label13").vw.setHeight((int)((5d / 100 * height)));
views.get("edtemail").vw.setWidth((int)((94d / 100 * width)));
views.get("edtemail").vw.setHeight((int)((10d / 100 * height)));

}
}