package cmarsoft.recu.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_main{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 3;BA.debugLine="AutoScaleAll"[Main/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 4;BA.debugLine="pnlHeader.Top = 0"[Main/General script]
views.get("pnlheader").vw.setTop((int)(0d));
//BA.debugLineNum = 5;BA.debugLine="pnlHeader.Height = 19%y"[Main/General script]
views.get("pnlheader").vw.setHeight((int)((19d / 100 * height)));
//BA.debugLineNum = 6;BA.debugLine="btnRun.Width = 20%x"[Main/General script]
views.get("btnrun").vw.setWidth((int)((20d / 100 * width)));
//BA.debugLineNum = 7;BA.debugLine="btnEmail.Width = btnRun.Width"[Main/General script]
views.get("btnemail").vw.setWidth((int)((views.get("btnrun").vw.getWidth())));
//BA.debugLineNum = 8;BA.debugLine="btnGraph.Width = btnRun.Width"[Main/General script]
views.get("btngraph").vw.setWidth((int)((views.get("btnrun").vw.getWidth())));
//BA.debugLineNum = 9;BA.debugLine="btnSetup.Width = btnRun.Width"[Main/General script]
views.get("btnsetup").vw.setWidth((int)((views.get("btnrun").vw.getWidth())));
//BA.debugLineNum = 10;BA.debugLine="btnRun.Left = 4%x"[Main/General script]
views.get("btnrun").vw.setLeft((int)((4d / 100 * width)));
//BA.debugLineNum = 11;BA.debugLine="btnEmail.Left = 28%x"[Main/General script]
views.get("btnemail").vw.setLeft((int)((28d / 100 * width)));
//BA.debugLineNum = 12;BA.debugLine="btnGraph.Left = 52%x"[Main/General script]
views.get("btngraph").vw.setLeft((int)((52d / 100 * width)));
//BA.debugLineNum = 13;BA.debugLine="btnSetup.Left = 76%x"[Main/General script]
views.get("btnsetup").vw.setLeft((int)((76d / 100 * width)));
//BA.debugLineNum = 14;BA.debugLine="pnlState.Top = pnlHeader.Bottom"[Main/General script]
views.get("pnlstate").vw.setTop((int)((views.get("pnlheader").vw.getTop() + views.get("pnlheader").vw.getHeight())));
//BA.debugLineNum = 15;BA.debugLine="pnlState.Height = 6%y"[Main/General script]
views.get("pnlstate").vw.setHeight((int)((6d / 100 * height)));
//BA.debugLineNum = 16;BA.debugLine="pnlA.Top = pnlState.Bottom"[Main/General script]
views.get("pnla").vw.setTop((int)((views.get("pnlstate").vw.getTop() + views.get("pnlstate").vw.getHeight())));
//BA.debugLineNum = 17;BA.debugLine="pnlA.Height = 10%y"[Main/General script]
views.get("pnla").vw.setHeight((int)((10d / 100 * height)));
//BA.debugLineNum = 18;BA.debugLine="pnlB.Top = pnlA.Bottom"[Main/General script]
views.get("pnlb").vw.setTop((int)((views.get("pnla").vw.getTop() + views.get("pnla").vw.getHeight())));
//BA.debugLineNum = 19;BA.debugLine="pnlB.Height = 10%y"[Main/General script]
views.get("pnlb").vw.setHeight((int)((10d / 100 * height)));
//BA.debugLineNum = 20;BA.debugLine="pnlC.Top = pnlB.Bottom"[Main/General script]
views.get("pnlc").vw.setTop((int)((views.get("pnlb").vw.getTop() + views.get("pnlb").vw.getHeight())));
//BA.debugLineNum = 21;BA.debugLine="pnlC.Height = 10%y"[Main/General script]
views.get("pnlc").vw.setHeight((int)((10d / 100 * height)));
//BA.debugLineNum = 22;BA.debugLine="pnlD.Top = pnlC.Bottom"[Main/General script]
views.get("pnld").vw.setTop((int)((views.get("pnlc").vw.getTop() + views.get("pnlc").vw.getHeight())));
//BA.debugLineNum = 23;BA.debugLine="pnlD.Height = 10%y"[Main/General script]
views.get("pnld").vw.setHeight((int)((10d / 100 * height)));
//BA.debugLineNum = 24;BA.debugLine="pnlE.Top = pnlD.Bottom"[Main/General script]
views.get("pnle").vw.setTop((int)((views.get("pnld").vw.getTop() + views.get("pnld").vw.getHeight())));
//BA.debugLineNum = 25;BA.debugLine="pnlE.Height = 10%y"[Main/General script]
views.get("pnle").vw.setHeight((int)((10d / 100 * height)));
//BA.debugLineNum = 26;BA.debugLine="pnlF.Top = pnlE.Bottom"[Main/General script]
views.get("pnlf").vw.setTop((int)((views.get("pnle").vw.getTop() + views.get("pnle").vw.getHeight())));
//BA.debugLineNum = 27;BA.debugLine="pnlF.Height = 10%y"[Main/General script]
views.get("pnlf").vw.setHeight((int)((10d / 100 * height)));
//BA.debugLineNum = 28;BA.debugLine="pnlG.Top = pnlF.Bottom"[Main/General script]
views.get("pnlg").vw.setTop((int)((views.get("pnlf").vw.getTop() + views.get("pnlf").vw.getHeight())));
//BA.debugLineNum = 29;BA.debugLine="pnlG.Height = 10%y"[Main/General script]
views.get("pnlg").vw.setHeight((int)((10d / 100 * height)));
//BA.debugLineNum = 30;BA.debugLine="lblECUMode.Width = 50%x"[Main/General script]
views.get("lblecumode").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 31;BA.debugLine="lblO2State.Width = 50%x"[Main/General script]
views.get("lblo2state").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 32;BA.debugLine="lblMAP.Width = 50%x"[Main/General script]
views.get("lblmap").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 33;BA.debugLine="lblVAC.Width = 50%x"[Main/General script]
views.get("lblvac").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 34;BA.debugLine="lblCTS.Width = 50%x"[Main/General script]
views.get("lblcts").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 35;BA.debugLine="lblIAT.Width = 50%x"[Main/General script]
views.get("lbliat").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 36;BA.debugLine="lblO2.Width = 50%x"[Main/General script]
views.get("lblo2").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 37;BA.debugLine="lblO2Avg.Width = 50%x"[Main/General script]
views.get("lblo2avg").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 38;BA.debugLine="lblTPS.Width = 50%x"[Main/General script]
views.get("lbltps").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 39;BA.debugLine="lblRPM.Width = 50%x"[Main/General script]
views.get("lblrpm").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 40;BA.debugLine="lblSTFT.Width = 50%x"[Main/General script]
views.get("lblstft").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 41;BA.debugLine="lblLTFT.Width = 50%x"[Main/General script]
views.get("lblltft").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 42;BA.debugLine="lblINJ.Width = 50%x"[Main/General script]
views.get("lblinj").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 43;BA.debugLine="lblSPK.Width = 50%x"[Main/General script]
views.get("lblspk").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 44;BA.debugLine="lblVOLT.Width = 50%x"[Main/General script]
views.get("lblvolt").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 45;BA.debugLine="lblEGR.Width = 50%x"[Main/General script]
views.get("lblegr").vw.setWidth((int)((50d / 100 * width)));

}
}