
#ifndef b4r_main_h
#define b4r_main_h

class b4r_main {
public:

static void initializeProcessGlobals();
static void _appstart();
static void _bt_statechanged(bool _connected);
static void _btstream_error();
static void _btstream_newdata(B4R::Array* _buffer);
static void _ecustream_error();
static void _ecustream_newdata(B4R::Array* _buffer);
static void _process_globals();
static B4R::B4RStream* _serialnative2;
static B4R::AsyncStreams* _ecustream;
static B4R::ESP32Bluetooth* _bt;
static B4R::AsyncStreams* _btstream;
static B4R::Array* _framebuffer;
static Byte _frame_size;
static Int _bufferposition;
static bool _framecompleteflag;
static bool _received0xff;
static bool _bufferfilling;
static Byte _lastbyte;
static Byte _buffererror;
static Int _badframes;
static B4R::Pin* _pin2;
static bool _receivedataframe(Byte _data);
};

#endif