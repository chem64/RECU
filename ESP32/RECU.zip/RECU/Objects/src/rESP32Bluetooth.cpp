#include "B4RDefines.h"
namespace B4R {
	
	ESP32Bluetooth::ESP32Bluetooth() {
		stream.wrappedStream = &client;
	}
	bool ESP32Bluetooth::Initialize(B4RString* DeviceName, SubVoidBool StateChangedSub) {
		String s(DeviceName->data);
		this->StateChangedSub = StateChangedSub;
		FunctionUnion fu;
		fu.PollerFunction = checkForData;
		pnode.functionUnion = fu;
		pnode.tag = this;
		if (pnode.next == NULL) {
			pollers.add(&pnode);
		}
		this->lastState = false;
		return client.begin(s);
	}
	B4RStream* ESP32Bluetooth::getStream() {
		return &stream;
	}
	bool ESP32Bluetooth::getConnected() {
		return client.hasClient();
	}
	void ESP32Bluetooth::Close() {
		client.end();
		if (pnode.next != NULL)
			pollers.remove(&pnode);
	}
	//static
	void ESP32Bluetooth::checkForData(void* b) {
		ESP32Bluetooth* me = (ESP32Bluetooth*) b;
		if (me->lastState != me->getConnected()) {
			me->lastState = me->getConnected();
			me->StateChangedSub(me->lastState);
		}
	}
}