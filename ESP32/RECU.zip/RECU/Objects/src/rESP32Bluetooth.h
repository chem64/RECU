#pragma once
#include "B4RDefines.h"
//~version: 1.00
//~dependson:<BluetoothSerial.h>
//~Event: StateChanged (Connected As Boolean)
namespace B4R {
	//~shortname: ESP32Bluetooth
	class ESP32Bluetooth {
		private:
			B4RStream stream;
			SubVoidBool StateChangedSub;
			bool lastState;
			static void checkForData(void* b);
			PollerNode pnode;
		public:
			//~hide
			BluetoothSerial client;
			//~hide
			ESP32Bluetooth();
			//Initializes the object and starts listening for connections.
			bool Initialize(B4RString* DeviceName, SubVoidBool StateChangedSub);
			//Gets the Bluetooth stream. Should be used together with AsyncStreams.
			B4RStream* getStream();
			//Tests whether the client is connected.
			bool getConnected();
			//Closes the connection.
			void Close();
	};
}