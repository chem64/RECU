#include "B4RDefines.h"

B4R::B4RStream* b4r_main::_serialnative2;
B4R::AsyncStreams* b4r_main::_ecustream;
B4R::ESP32Bluetooth* b4r_main::_bt;
B4R::AsyncStreams* b4r_main::_btstream;
B4R::Array* b4r_main::_framebuffer;
Byte b4r_main::_frame_size;
Int b4r_main::_bufferposition;
bool b4r_main::_framecompleteflag;
bool b4r_main::_received0xff;
bool b4r_main::_bufferfilling;
Byte b4r_main::_lastbyte;
Byte b4r_main::_buffererror;
Int b4r_main::_badframes;
B4R::Pin* b4r_main::_pin2;
static B4R::B4RStream be_gann1_3;
static B4R::AsyncStreams be_gann2_3;
static B4R::ESP32Bluetooth be_gann3_3;
static B4R::AsyncStreams be_gann4_3;
static Byte be_gann5_4e1[40];
static B4R::Array be_gann5_4e2;
static B4R::Pin be_gann14_3;


 void SerialNative2(B4R::Object* unused)
{
::Serial2.begin(62500, SERIAL_8N1, 18, 21); 
b4r_main::_serialnative2->wrappedStream = &::Serial2;
}
void b4r_main::_appstart(){
const UInt cp = B4R::StackMemory::cp;
B4R::B4RString be_ann17_4;
 //BA.debugLineNum = 24;BA.debugLine="Private Sub AppStart";
 //BA.debugLineNum = 25;BA.debugLine="BT.Initialize(\"RECU\", \"BT_StateChanged\")";
b4r_main::_bt->Initialize(be_ann17_4.wrap("RECU"),_bt_statechanged);
 //BA.debugLineNum = 26;BA.debugLine="BTstream.Initialize(BT.Stream, \"BTstream_NewData\"";
b4r_main::_btstream->Initialize(b4r_main::_bt->getStream(),_btstream_newdata,_btstream_error);
 //BA.debugLineNum = 27;BA.debugLine="RunNative(\"SerialNative2\", Null)";
Common_RunNative(SerialNative2,Common_Null);
 //BA.debugLineNum = 28;BA.debugLine="ECUstream.Initialize(SerialNative2, \"ECUstream_Ne";
b4r_main::_ecustream->Initialize(b4r_main::_serialnative2,_ecustream_newdata,_ecustream_error);
 //BA.debugLineNum = 29;BA.debugLine="pin2.Initialize(2, pin2.MODE_OUTPUT)";
b4r_main::_pin2->Initialize((Byte) (2),Pin_MODE_OUTPUT);
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_bt_statechanged(bool _connected){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 40;BA.debugLine="Sub BT_StateChanged (Connected As Boolean)";
 //BA.debugLineNum = 41;BA.debugLine="pin2.DigitalWrite(Connected)";
b4r_main::_pin2->DigitalWrite(_connected);
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_btstream_error(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 117;BA.debugLine="Sub BTstream_Error";
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_btstream_newdata(B4R::Array* _buffer){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 44;BA.debugLine="Sub BTstream_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 45;BA.debugLine="If Buffer(0) = 99 Then 'Send 4 CYL TEST FRAME";
if (((Byte*)_buffer->getData((UInt) (0)))[B4R::Array::staticIndex]==99) { 
 //BA.debugLineNum = 46;BA.debugLine="frameBuffer(0) = 32";
((Byte*)b4r_main::_framebuffer->getData((UInt) (0)))[B4R::Array::staticIndex] = (Byte) (32);
 //BA.debugLineNum = 47;BA.debugLine="frameBuffer(1) = 98";
((Byte*)b4r_main::_framebuffer->getData((UInt) (1)))[B4R::Array::staticIndex] = (Byte) (98);
 //BA.debugLineNum = 48;BA.debugLine="frameBuffer(2) = 88";
((Byte*)b4r_main::_framebuffer->getData((UInt) (2)))[B4R::Array::staticIndex] = (Byte) (88);
 //BA.debugLineNum = 49;BA.debugLine="frameBuffer(3) = 76";
((Byte*)b4r_main::_framebuffer->getData((UInt) (3)))[B4R::Array::staticIndex] = (Byte) (76);
 //BA.debugLineNum = 50;BA.debugLine="frameBuffer(4) = 141";
((Byte*)b4r_main::_framebuffer->getData((UInt) (4)))[B4R::Array::staticIndex] = (Byte) (141);
 //BA.debugLineNum = 51;BA.debugLine="frameBuffer(5) = 142";
((Byte*)b4r_main::_framebuffer->getData((UInt) (5)))[B4R::Array::staticIndex] = (Byte) (142);
 //BA.debugLineNum = 52;BA.debugLine="frameBuffer(6) = 197";
((Byte*)b4r_main::_framebuffer->getData((UInt) (6)))[B4R::Array::staticIndex] = (Byte) (197);
 //BA.debugLineNum = 53;BA.debugLine="frameBuffer(7) = 229";
((Byte*)b4r_main::_framebuffer->getData((UInt) (7)))[B4R::Array::staticIndex] = (Byte) (229);
 //BA.debugLineNum = 54;BA.debugLine="frameBuffer(8) = 56";
((Byte*)b4r_main::_framebuffer->getData((UInt) (8)))[B4R::Array::staticIndex] = (Byte) (56);
 //BA.debugLineNum = 55;BA.debugLine="frameBuffer(9) = 161";
((Byte*)b4r_main::_framebuffer->getData((UInt) (9)))[B4R::Array::staticIndex] = (Byte) (161);
 //BA.debugLineNum = 56;BA.debugLine="frameBuffer(10) = 170";
((Byte*)b4r_main::_framebuffer->getData((UInt) (10)))[B4R::Array::staticIndex] = (Byte) (170);
 //BA.debugLineNum = 57;BA.debugLine="frameBuffer(11) = 8";
((Byte*)b4r_main::_framebuffer->getData((UInt) (11)))[B4R::Array::staticIndex] = (Byte) (8);
 //BA.debugLineNum = 58;BA.debugLine="frameBuffer(12) = 14";
((Byte*)b4r_main::_framebuffer->getData((UInt) (12)))[B4R::Array::staticIndex] = (Byte) (14);
 //BA.debugLineNum = 59;BA.debugLine="frameBuffer(13) = 10";
((Byte*)b4r_main::_framebuffer->getData((UInt) (13)))[B4R::Array::staticIndex] = (Byte) (10);
 //BA.debugLineNum = 60;BA.debugLine="frameBuffer(14) = 0";
((Byte*)b4r_main::_framebuffer->getData((UInt) (14)))[B4R::Array::staticIndex] = (Byte) (0);
 //BA.debugLineNum = 61;BA.debugLine="frameBuffer(15) = 126";
((Byte*)b4r_main::_framebuffer->getData((UInt) (15)))[B4R::Array::staticIndex] = (Byte) (126);
 //BA.debugLineNum = 62;BA.debugLine="frameBuffer(16) = 225";
((Byte*)b4r_main::_framebuffer->getData((UInt) (16)))[B4R::Array::staticIndex] = (Byte) (225);
 //BA.debugLineNum = 63;BA.debugLine="frameBuffer(17) = 25";
((Byte*)b4r_main::_framebuffer->getData((UInt) (17)))[B4R::Array::staticIndex] = (Byte) (25);
 //BA.debugLineNum = 64;BA.debugLine="frameBuffer(18) = 192";
((Byte*)b4r_main::_framebuffer->getData((UInt) (18)))[B4R::Array::staticIndex] = (Byte) (192);
 //BA.debugLineNum = 65;BA.debugLine="frameBuffer(19) = 0";
((Byte*)b4r_main::_framebuffer->getData((UInt) (19)))[B4R::Array::staticIndex] = (Byte) (0);
 //BA.debugLineNum = 66;BA.debugLine="frameBuffer(20) = 0";
((Byte*)b4r_main::_framebuffer->getData((UInt) (20)))[B4R::Array::staticIndex] = (Byte) (0);
 //BA.debugLineNum = 67;BA.debugLine="frameBuffer(21) = 58";
((Byte*)b4r_main::_framebuffer->getData((UInt) (21)))[B4R::Array::staticIndex] = (Byte) (58);
 //BA.debugLineNum = 68;BA.debugLine="frameBuffer(22) = 1";
((Byte*)b4r_main::_framebuffer->getData((UInt) (22)))[B4R::Array::staticIndex] = (Byte) (1);
 //BA.debugLineNum = 69;BA.debugLine="frameBuffer(23) = 3";
((Byte*)b4r_main::_framebuffer->getData((UInt) (23)))[B4R::Array::staticIndex] = (Byte) (3);
 //BA.debugLineNum = 70;BA.debugLine="frameBuffer(24) = 181";
((Byte*)b4r_main::_framebuffer->getData((UInt) (24)))[B4R::Array::staticIndex] = (Byte) (181);
 //BA.debugLineNum = 71;BA.debugLine="frameBuffer(25) = 91";
((Byte*)b4r_main::_framebuffer->getData((UInt) (25)))[B4R::Array::staticIndex] = (Byte) (91);
 //BA.debugLineNum = 72;BA.debugLine="frameBuffer(26) = 128";
((Byte*)b4r_main::_framebuffer->getData((UInt) (26)))[B4R::Array::staticIndex] = (Byte) (128);
 //BA.debugLineNum = 73;BA.debugLine="frameBuffer(27) = 6";
((Byte*)b4r_main::_framebuffer->getData((UInt) (27)))[B4R::Array::staticIndex] = (Byte) (6);
 //BA.debugLineNum = 74;BA.debugLine="frameBuffer(28) = 128";
((Byte*)b4r_main::_framebuffer->getData((UInt) (28)))[B4R::Array::staticIndex] = (Byte) (128);
 //BA.debugLineNum = 75;BA.debugLine="If BT.Connected Then";
if (b4r_main::_bt->getConnected()) { 
 //BA.debugLineNum = 76;BA.debugLine="BTstream.Write(frameBuffer)";
b4r_main::_btstream->Write(b4r_main::_framebuffer);
 };
 };
 //BA.debugLineNum = 79;BA.debugLine="If Buffer(0) = 98 Then 'Send 6 CYL TEST FRAME";
if (((Byte*)_buffer->getData((UInt) (0)))[B4R::Array::staticIndex]==98) { 
 //BA.debugLineNum = 80;BA.debugLine="frameBuffer(0) = 177";
((Byte*)b4r_main::_framebuffer->getData((UInt) (0)))[B4R::Array::staticIndex] = (Byte) (177);
 //BA.debugLineNum = 81;BA.debugLine="frameBuffer(1) = 20";
((Byte*)b4r_main::_framebuffer->getData((UInt) (1)))[B4R::Array::staticIndex] = (Byte) (20);
 //BA.debugLineNum = 82;BA.debugLine="frameBuffer(2) = 63";
((Byte*)b4r_main::_framebuffer->getData((UInt) (2)))[B4R::Array::staticIndex] = (Byte) (63);
 //BA.debugLineNum = 83;BA.debugLine="frameBuffer(3) = 118";
((Byte*)b4r_main::_framebuffer->getData((UInt) (3)))[B4R::Array::staticIndex] = (Byte) (118);
 //BA.debugLineNum = 84;BA.debugLine="frameBuffer(4) = 110";
((Byte*)b4r_main::_framebuffer->getData((UInt) (4)))[B4R::Array::staticIndex] = (Byte) (110);
 //BA.debugLineNum = 85;BA.debugLine="frameBuffer(5) = 106";
((Byte*)b4r_main::_framebuffer->getData((UInt) (5)))[B4R::Array::staticIndex] = (Byte) (106);
 //BA.debugLineNum = 86;BA.debugLine="frameBuffer(6) = 222";
((Byte*)b4r_main::_framebuffer->getData((UInt) (6)))[B4R::Array::staticIndex] = (Byte) (222);
 //BA.debugLineNum = 87;BA.debugLine="frameBuffer(7) = 255";
((Byte*)b4r_main::_framebuffer->getData((UInt) (7)))[B4R::Array::staticIndex] = (Byte) (255);
 //BA.debugLineNum = 88;BA.debugLine="frameBuffer(8) = 90";
((Byte*)b4r_main::_framebuffer->getData((UInt) (8)))[B4R::Array::staticIndex] = (Byte) (90);
 //BA.debugLineNum = 89;BA.debugLine="frameBuffer(9) = 92";
((Byte*)b4r_main::_framebuffer->getData((UInt) (9)))[B4R::Array::staticIndex] = (Byte) (92);
 //BA.debugLineNum = 90;BA.debugLine="frameBuffer(10) = 253";
((Byte*)b4r_main::_framebuffer->getData((UInt) (10)))[B4R::Array::staticIndex] = (Byte) (253);
 //BA.debugLineNum = 91;BA.debugLine="frameBuffer(11) = 254";
((Byte*)b4r_main::_framebuffer->getData((UInt) (11)))[B4R::Array::staticIndex] = (Byte) (254);
 //BA.debugLineNum = 92;BA.debugLine="frameBuffer(12) = 40";
((Byte*)b4r_main::_framebuffer->getData((UInt) (12)))[B4R::Array::staticIndex] = (Byte) (40);
 //BA.debugLineNum = 93;BA.debugLine="frameBuffer(13) = 15";
((Byte*)b4r_main::_framebuffer->getData((UInt) (13)))[B4R::Array::staticIndex] = (Byte) (15);
 //BA.debugLineNum = 94;BA.debugLine="frameBuffer(14) = 0";
((Byte*)b4r_main::_framebuffer->getData((UInt) (14)))[B4R::Array::staticIndex] = (Byte) (0);
 //BA.debugLineNum = 95;BA.debugLine="frameBuffer(15) = 110";
((Byte*)b4r_main::_framebuffer->getData((UInt) (15)))[B4R::Array::staticIndex] = (Byte) (110);
 //BA.debugLineNum = 96;BA.debugLine="frameBuffer(16) = 248";
((Byte*)b4r_main::_framebuffer->getData((UInt) (16)))[B4R::Array::staticIndex] = (Byte) (248);
 //BA.debugLineNum = 97;BA.debugLine="frameBuffer(17) = 0";
((Byte*)b4r_main::_framebuffer->getData((UInt) (17)))[B4R::Array::staticIndex] = (Byte) (0);
 //BA.debugLineNum = 98;BA.debugLine="frameBuffer(18) = 16";
((Byte*)b4r_main::_framebuffer->getData((UInt) (18)))[B4R::Array::staticIndex] = (Byte) (16);
 //BA.debugLineNum = 99;BA.debugLine="frameBuffer(19) = 100";
((Byte*)b4r_main::_framebuffer->getData((UInt) (19)))[B4R::Array::staticIndex] = (Byte) (100);
 //BA.debugLineNum = 100;BA.debugLine="frameBuffer(20) = 0";
((Byte*)b4r_main::_framebuffer->getData((UInt) (20)))[B4R::Array::staticIndex] = (Byte) (0);
 //BA.debugLineNum = 101;BA.debugLine="frameBuffer(21) = 72";
((Byte*)b4r_main::_framebuffer->getData((UInt) (21)))[B4R::Array::staticIndex] = (Byte) (72);
 //BA.debugLineNum = 102;BA.debugLine="frameBuffer(22) = 15";
((Byte*)b4r_main::_framebuffer->getData((UInt) (22)))[B4R::Array::staticIndex] = (Byte) (15);
 //BA.debugLineNum = 103;BA.debugLine="frameBuffer(23) = 39";
((Byte*)b4r_main::_framebuffer->getData((UInt) (23)))[B4R::Array::staticIndex] = (Byte) (39);
 //BA.debugLineNum = 104;BA.debugLine="frameBuffer(24) = 128";
((Byte*)b4r_main::_framebuffer->getData((UInt) (24)))[B4R::Array::staticIndex] = (Byte) (128);
 //BA.debugLineNum = 105;BA.debugLine="frameBuffer(25) = 116";
((Byte*)b4r_main::_framebuffer->getData((UInt) (25)))[B4R::Array::staticIndex] = (Byte) (116);
 //BA.debugLineNum = 106;BA.debugLine="frameBuffer(26) = 160";
((Byte*)b4r_main::_framebuffer->getData((UInt) (26)))[B4R::Array::staticIndex] = (Byte) (160);
 //BA.debugLineNum = 107;BA.debugLine="frameBuffer(27) = 0";
((Byte*)b4r_main::_framebuffer->getData((UInt) (27)))[B4R::Array::staticIndex] = (Byte) (0);
 //BA.debugLineNum = 108;BA.debugLine="frameBuffer(28) = 0";
((Byte*)b4r_main::_framebuffer->getData((UInt) (28)))[B4R::Array::staticIndex] = (Byte) (0);
 //BA.debugLineNum = 109;BA.debugLine="frameBuffer(29) = 10";
((Byte*)b4r_main::_framebuffer->getData((UInt) (29)))[B4R::Array::staticIndex] = (Byte) (10);
 //BA.debugLineNum = 110;BA.debugLine="frameBuffer(30) = 243";
((Byte*)b4r_main::_framebuffer->getData((UInt) (30)))[B4R::Array::staticIndex] = (Byte) (243);
 //BA.debugLineNum = 111;BA.debugLine="If BT.Connected Then";
if (b4r_main::_bt->getConnected()) { 
 //BA.debugLineNum = 112;BA.debugLine="BTstream.Write(frameBuffer)";
b4r_main::_btstream->Write(b4r_main::_framebuffer);
 };
 };
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_ecustream_error(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 144;BA.debugLine="Sub ECUstream_Error";
 //BA.debugLineNum = 145;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_ecustream_newdata(B4R::Array* _buffer){
const UInt cp = B4R::StackMemory::cp;
Byte _byte_read = 0;
 //BA.debugLineNum = 121;BA.debugLine="Sub ECUstream_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 123;BA.debugLine="Dim byte_read As Byte";
_byte_read = 0;
 //BA.debugLineNum = 126;BA.debugLine="For Each byte_read As Byte In Buffer";
const B4R::Array* group2 = _buffer;
const int groupLen2 = group2->length;
for (int index2 = 0;index2 < groupLen2 ;index2++){
_byte_read = ((Byte*)group2->data)[index2];
 //BA.debugLineNum = 127;BA.debugLine="ReceiveDataFrame(byte_read)";
_receivedataframe(_byte_read);
 //BA.debugLineNum = 128;BA.debugLine="If frameCompleteFlag Then";
if (b4r_main::_framecompleteflag) { 
 //BA.debugLineNum = 129;BA.debugLine="If bufferError = 0 Then";
if (b4r_main::_buffererror==0) { 
 //BA.debugLineNum = 133;BA.debugLine="If BT.Connected Then";
if (b4r_main::_bt->getConnected()) { 
 //BA.debugLineNum = 134;BA.debugLine="BTstream.Write(frameBuffer)";
b4r_main::_btstream->Write(b4r_main::_framebuffer);
 };
 }else {
 //BA.debugLineNum = 137;BA.debugLine="badFrames = badFrames + 1";
b4r_main::_badframes = (Int) (b4r_main::_badframes+1);
 };
 //BA.debugLineNum = 139;BA.debugLine="frameCompleteFlag = False";
b4r_main::_framecompleteflag = Common_False;
 };
 }
;
 //BA.debugLineNum = 142;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}

void b4r_main::initializeProcessGlobals() {
     B4R::StackMemory::buffer = (byte*)malloc(STACK_BUFFER_SIZE);
     b4r_main::_process_globals();

   
}
void b4r_main::_process_globals(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 7;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private SerialNative2 As Stream";
b4r_main::_serialnative2 = &be_gann1_3;
 //BA.debugLineNum = 9;BA.debugLine="Public ECUstream As AsyncStreams";
b4r_main::_ecustream = &be_gann2_3;
 //BA.debugLineNum = 10;BA.debugLine="Private BT As ESP32Bluetooth";
b4r_main::_bt = &be_gann3_3;
 //BA.debugLineNum = 11;BA.debugLine="Public BTstream As AsyncStreams";
b4r_main::_btstream = &be_gann4_3;
 //BA.debugLineNum = 12;BA.debugLine="Public frameBuffer(40) As Byte";
b4r_main::_framebuffer =be_gann5_4e2.wrap(be_gann5_4e1,40);
 //BA.debugLineNum = 13;BA.debugLine="Dim FRAME_SIZE As Byte = 30 '28    	'ECU Frame si";
b4r_main::_frame_size = (Byte) (30);
 //BA.debugLineNum = 14;BA.debugLine="Dim bufferPosition As Int = 0    	'Current recept";
b4r_main::_bufferposition = 0;
 //BA.debugLineNum = 15;BA.debugLine="Dim frameCompleteFlag As Boolean = False    'Set";
b4r_main::_framecompleteflag = Common_False;
 //BA.debugLineNum = 16;BA.debugLine="Dim Received0xFF As Boolean = False         'Set";
b4r_main::_received0xff = Common_False;
 //BA.debugLineNum = 17;BA.debugLine="Dim bufferFilling As Boolean = False        'Indi";
b4r_main::_bufferfilling = Common_False;
 //BA.debugLineNum = 18;BA.debugLine="Dim lastByte As Byte = 0            	'Tracks last";
b4r_main::_lastbyte = (Byte) (0);
 //BA.debugLineNum = 19;BA.debugLine="Dim bufferError As Byte = 0          'Indicates a";
b4r_main::_buffererror = (Byte) (0);
 //BA.debugLineNum = 20;BA.debugLine="Dim badFrames As Int = 0            'Indicates nu";
b4r_main::_badframes = 0;
 //BA.debugLineNum = 21;BA.debugLine="Private pin2 As Pin	'Blue LED pin";
b4r_main::_pin2 = &be_gann14_3;
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
}
bool b4r_main::_receivedataframe(Byte _data){
const UInt cp = B4R::StackMemory::cp;
bool _storebyteflag = false;
bool _receivedflag = false;
Byte _bytedata = 0;
 //BA.debugLineNum = 156;BA.debugLine="Sub ReceiveDataFrame(data As Byte) As Boolean";
 //BA.debugLineNum = 158;BA.debugLine="Dim storeByteFlag As Boolean = False  'Indicates";
_storebyteflag = Common_False;
 //BA.debugLineNum = 159;BA.debugLine="Dim receivedFlag As Boolean = False";
_receivedflag = Common_False;
 //BA.debugLineNum = 160;BA.debugLine="Dim byteData As Byte";
_bytedata = 0;
 //BA.debugLineNum = 162;BA.debugLine="If (frameCompleteFlag) Then     'Unread frame wai";
if ((b4r_main::_framecompleteflag)) { 
 //BA.debugLineNum = 163;BA.debugLine="Return False";
B4R::StackMemory::cp = cp;
bool res5 = Common_False;
if (true) return res5;
 };
 //BA.debugLineNum = 165;BA.debugLine="byteData = data";
_bytedata = _data;
 //BA.debugLineNum = 167;BA.debugLine="If Not(bufferFilling) Then          'Waiting on 0";
if (Common_Not(b4r_main::_bufferfilling)) { 
 //BA.debugLineNum = 168;BA.debugLine="If (byteData = 0) And (lastByte = 255) Then   'I";
if ((_bytedata==0) && (b4r_main::_lastbyte==255)) { 
 //BA.debugLineNum = 169;BA.debugLine="bufferFilling = True   'Indicate filling in pro";
b4r_main::_bufferfilling = Common_True;
 //BA.debugLineNum = 170;BA.debugLine="bufferPosition = 0     'Reset frame fill positi";
b4r_main::_bufferposition = 0;
 //BA.debugLineNum = 171;BA.debugLine="bufferError = 0      'reset error";
b4r_main::_buffererror = (Byte) (0);
 //BA.debugLineNum = 172;BA.debugLine="lastByte = 0         'reset For Next frame star";
b4r_main::_lastbyte = (Byte) (0);
 //BA.debugLineNum = 173;BA.debugLine="Received0xFF = False 'Reset double 0xFF data in";
b4r_main::_received0xff = Common_False;
 }else {
 //BA.debugLineNum = 175;BA.debugLine="lastByte = byteData   'Not start of frame, so k";
b4r_main::_lastbyte = _bytedata;
 };
 }else {
 //BA.debugLineNum = 179;BA.debugLine="If(Received0xFF) Then";
if ((b4r_main::_received0xff)) { 
 //BA.debugLineNum = 181;BA.debugLine="If byteData = 255 Then";
if (_bytedata==255) { 
 //BA.debugLineNum = 185;BA.debugLine="receivedFlag = True";
_receivedflag = Common_True;
 };
 //BA.debugLineNum = 187;BA.debugLine="If byteData = 0 Then";
if (_bytedata==0) { 
 //BA.debugLineNum = 189;BA.debugLine="bufferError = 2       'Indicate Short Count On";
b4r_main::_buffererror = (Byte) (2);
 //BA.debugLineNum = 190;BA.debugLine="bufferPosition = bufferPosition - 1      'Back";
b4r_main::_bufferposition = (Int) (b4r_main::_bufferposition-1);
 //BA.debugLineNum = 191;BA.debugLine="bufferFilling = False  'Stop Filling";
b4r_main::_bufferfilling = Common_False;
 //BA.debugLineNum = 192;BA.debugLine="frameCompleteFlag = True";
b4r_main::_framecompleteflag = Common_True;
 //BA.debugLineNum = 193;BA.debugLine="receivedFlag = True";
_receivedflag = Common_True;
 };
 //BA.debugLineNum = 195;BA.debugLine="If Not(receivedFlag) Then bufferFilling = False";
if (Common_Not(_receivedflag)) { 
b4r_main::_bufferfilling = Common_False;};
 //BA.debugLineNum = 196;BA.debugLine="Received0xFF = False  'Reset the flag";
b4r_main::_received0xff = Common_False;
 }else {
 //BA.debugLineNum = 198;BA.debugLine="storeByteFlag = True   'Prior byte was Not 0xFF";
_storebyteflag = Common_True;
 //BA.debugLineNum = 199;BA.debugLine="If byteData = 255 Then";
if (_bytedata==255) { 
 //BA.debugLineNum = 200;BA.debugLine="Received0xFF = True";
b4r_main::_received0xff = Common_True;
 };
 };
 };
 //BA.debugLineNum = 207;BA.debugLine="If (storeByteFlag) Then";
if ((_storebyteflag)) { 
 //BA.debugLineNum = 209;BA.debugLine="frameBuffer(bufferPosition) = byteData  'Store t";
((Byte*)b4r_main::_framebuffer->getData((UInt) (b4r_main::_bufferposition)))[B4R::Array::staticIndex] = _bytedata;
 //BA.debugLineNum = 210;BA.debugLine="bufferPosition = bufferPosition + 1";
b4r_main::_bufferposition = (Int) (b4r_main::_bufferposition+1);
 //BA.debugLineNum = 211;BA.debugLine="If(bufferPosition >= FRAME_SIZE) Then  'Full fra";
if ((b4r_main::_bufferposition>=b4r_main::_frame_size)) { 
 //BA.debugLineNum = 212;BA.debugLine="bufferFilling = False  'Stop Filling";
b4r_main::_bufferfilling = Common_False;
 //BA.debugLineNum = 213;BA.debugLine="frameCompleteFlag = True";
b4r_main::_framecompleteflag = Common_True;
 };
 };
 //BA.debugLineNum = 216;BA.debugLine="Return True";
B4R::StackMemory::cp = cp;
bool res47 = Common_True;
if (true) return res47;
 //BA.debugLineNum = 217;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
return false;
}
