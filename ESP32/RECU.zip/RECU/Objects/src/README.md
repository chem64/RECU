#rRandomAccessFile

Similar to the other B4X RandomAccessFile libraries.

Further information: https://www.b4x.com/search?product=B4R&query=AsyncStreams

B4R: https://www.b4x.com/b4r.html